
from app.elastic_client import get_es

def reserve(cards, user):
    es = get_es()

    for c in cards:
        es.update(
            index="card_inventory",
            id=c["card_id"],
            body={
                "doc":{
                    "reserved":True,
                    "reserved_by":user
                }
            }
        )

    return cards
