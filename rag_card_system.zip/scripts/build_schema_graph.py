
from elasticsearch import Elasticsearch, helpers
from sentence_transformers import SentenceTransformer

es = Elasticsearch("http://localhost:9200")
model = SentenceTransformer("all-MiniLM-L6-v2")

SOURCE_INDEX = "card_inventory"
RAG_INDEX = "rag_knowledge"

def extract_schema():
    mapping = es.indices.get_mapping(index=SOURCE_INDEX)
    props = mapping[SOURCE_INDEX]["mappings"]["properties"]

    docs = []

    for field, meta in props.items():
        dtype = meta["type"]
        docs.append(f"{field} is a field in credit card dataset with datatype {dtype}")

    return docs

def index_docs(docs):

    actions = []

    for d in docs:
        embedding = model.encode(d).tolist()

        actions.append({
            "_index":RAG_INDEX,
            "_source":{
                "text":d,
                "embedding":embedding
            }
        })

    helpers.bulk(es,actions)

if __name__=="__main__":
    schema_docs = extract_schema()
    index_docs(schema_docs)
    print("Knowledge generated automatically")
