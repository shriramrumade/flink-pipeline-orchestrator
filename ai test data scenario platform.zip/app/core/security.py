"""
Minimal API-key auth + correlation-ID generation for the API Gateway layer.
Swap `verify_api_key` for OAuth2/JWT in Phase 7 (Enterprise hardening).
"""
import uuid

from fastapi import Header, HTTPException, status

from app.core.config import get_settings

CORRELATION_ID_HEADER = "X-Correlation-ID"


def verify_api_key(x_api_key: str = Header(default="")) -> None:
    settings = get_settings()
    if x_api_key != settings.api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key",
        )


def get_correlation_id(x_correlation_id: str | None = Header(default=None)) -> str:
    return x_correlation_id or str(uuid.uuid4())
