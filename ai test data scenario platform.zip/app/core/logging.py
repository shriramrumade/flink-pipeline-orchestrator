"""
Structured JSON logging with correlation-ID support so every log line can be
tied back to a request (feeds OpenTelemetry traces per section 4/14).
"""
import logging
import sys
from pythonjsonlogger import jsonlogger

from app.core.config import get_settings

_CORRELATION_ID_FIELD = "correlation_id"


def configure_logging() -> None:
    settings = get_settings()
    handler = logging.StreamHandler(sys.stdout)
    formatter = jsonlogger.JsonFormatter(
        "%(asctime)s %(levelname)s %(name)s %(message)s "
        f"%({_CORRELATION_ID_FIELD})s"
    )
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(settings.log_level.upper())


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
