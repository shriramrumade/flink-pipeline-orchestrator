"""
Central application configuration.
Loaded once via `get_settings()` (cached singleton) and injected wherever needed.
Matches doc section 16 (Technology Choices) and section 13 (Security Boundary).
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_env: str = "local"
    log_level: str = "INFO"
    api_key: str = "change-me"

    # Elasticsearch (authoritative search source - section 16)
    elasticsearch_url: str = "http://localhost:9200"
    elasticsearch_index: str = "test_cards"
    elasticsearch_user: str | None = None
    elasticsearch_password: str | None = None

    # Self-hosted Llama (intent interpretation only - section 13)
    llama_base_url: str = "http://localhost:11434"
    llama_model: str = "llama3.1:8b-instruct"
    llama_timeout_seconds: int = 30

    # Confidence thresholds (section 12)
    exact_match_threshold: float = 0.85
    recommendation_threshold: float = 0.6

    # Ranking weights (section 11) - deterministic, tunable via evaluation dataset
    weight_constraint_match: float = 0.40
    weight_es_relevance: float = 0.25
    weight_semantic_similarity: float = 0.20
    weight_historical_success: float = 0.10
    weight_freshness: float = 0.05


@lru_cache
def get_settings() -> Settings:
    return Settings()
