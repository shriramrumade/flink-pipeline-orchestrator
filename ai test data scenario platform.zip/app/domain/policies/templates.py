"""
Approved synthesis templates (doc section 9): creation is never performed
solely because the LLM suggested it — only from a template in this
allow-list, filled deterministically from normalized criteria. Extend this
list as new product families are onboarded; never let an agent invent one.
"""
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class CardTemplate:
    template_id: str
    issuer: str
    product_family: str
    default_attributes: dict[str, Any] = field(default_factory=dict)


TEMPLATES: list[CardTemplate] = [
    CardTemplate(
        template_id="chase_sapphire_travel_v1",
        issuer="Chase",
        product_family="Sapphire",
        default_attributes={
            "issuer": "Chase",
            "product_family": "Sapphire",
            "travel_rewards": True,
            "annual_fee": 95.0,
            "available_credit": 5000.0,
            "status": "active",
        },
    ),
    CardTemplate(
        template_id="generic_no_annual_fee_v1",
        issuer="Generic Bank",
        product_family="Standard",
        default_attributes={
            "issuer": "Generic Bank",
            "product_family": "Standard",
            "travel_rewards": False,
            "annual_fee": 0.0,
            "available_credit": 2000.0,
            "status": "active",
        },
    ),
]


def find_template(issuer: str | None, product_family: str | None) -> CardTemplate | None:
    """Best-effort deterministic template match; falls back to the generic
    template so synthesis always has a safe, approved starting point."""
    for template in TEMPLATES:
        if issuer and template.issuer == issuer and product_family and template.product_family == product_family:
            return template
    for template in TEMPLATES:
        if issuer and template.issuer == issuer:
            return template
    return next((t for t in TEMPLATES if t.template_id == "generic_no_annual_fee_v1"), None)
