"""
Approved-transformation / approved-template policy checks (doc sections 9,
13, 20 — "No state-changing action without explicit approval" and
"Creation is never performed solely because the LLM suggested it").
"""
from typing import Any

# Conservative allow-list of fields a Conditioning Plan may change, and the
# constraint names (as produced by app.domain.rules.constraints) that map to
# each field. Expand deliberately — this is the safety boundary for Phase 5.
ALLOWED_CONDITIONING_FIELDS: dict[str, str] = {
    "available_credit_min": "available_credit",
    "available_credit_max": "available_credit",
    "card_status": "status",
}


def is_transformation_allowed(constraint_name: str) -> bool:
    return constraint_name in ALLOWED_CONDITIONING_FIELDS


def target_field_for_constraint(constraint_name: str) -> str | None:
    return ALLOWED_CONDITIONING_FIELDS.get(constraint_name)


def is_field_transformation_allowed(field: str, from_value: Any, to_value: Any) -> bool:
    """Kept for direct field-level checks (e.g. from an executor)."""
    return field in set(ALLOWED_CONDITIONING_FIELDS.values())
