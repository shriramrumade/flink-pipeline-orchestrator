"""
Deterministic constraint evaluation. Hard constraints are gates, never scores
(doc section 11: "Hard constraints are gates, not merely score contributions").
"""
from app.domain.models.contracts import NormalizedCriteria, SearchCandidate


def hard_constraints_satisfied(criteria: NormalizedCriteria, candidate: SearchCandidate) -> tuple[bool, list[str], list[str]]:
    """
    Returns (all_satisfied, satisfied_list, failed_list) evaluated against the
    candidate's raw_record. Only fields explicitly set on criteria are checked.
    """
    record = candidate.raw_record
    satisfied: list[str] = []
    failed: list[str] = []

    def check(name: str, ok: bool) -> None:
        (satisfied if ok else failed).append(name)

    if criteria.issuer is not None:
        check("issuer", record.get("issuer") == criteria.issuer)

    if criteria.product_family is not None:
        check("product_family", record.get("product_family") == criteria.product_family)

    if criteria.travel_rewards is not None:
        check("travel_rewards", record.get("travel_rewards") == criteria.travel_rewards)

    if criteria.annual_fee_max is not None:
        check("annual_fee_max", record.get("annual_fee", float("inf")) <= criteria.annual_fee_max)

    if criteria.annual_fee_min is not None:
        check("annual_fee_min", record.get("annual_fee", float("-inf")) >= criteria.annual_fee_min)

    if criteria.available_credit_min is not None:
        check("available_credit_min", record.get("available_credit", float("-inf")) >= criteria.available_credit_min)

    if criteria.available_credit_max is not None:
        check("available_credit_max", record.get("available_credit", float("inf")) <= criteria.available_credit_max)

    if criteria.card_status is not None:
        check("card_status", record.get("status") == criteria.card_status)

    return (len(failed) == 0, satisfied, failed)
