"""
Core data contracts (doc section 15).
These are the shared vocabulary between agents, services, and the API layer.
No sensitive raw card data is ever embedded in normalized_criteria sent to the LLM
(see section 13, Security and Sensitive Data Boundary).
"""
from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class ActionType(str, Enum):
    RETURN_MATCH = "return_match"
    RECOMMEND = "recommend"
    CLARIFY = "clarify"
    CONDITION = "condition"
    SYNTHESIZE = "synthesize"
    UNFULFILLABLE = "unfulfillable"


class ConfidenceTier(str, Enum):
    EXACT = "exact"
    STRONG_RECOMMENDATION = "strong_recommendation"
    CONDITIONABLE = "conditionable"
    SYNTHESIZABLE = "synthesizable"
    UNFULFILLABLE = "unfulfillable"


class NormalizedCriteria(BaseModel):
    """Structured, non-sensitive output of the Intent Agent (section 7)."""
    issuer: Optional[str] = None
    product_family: Optional[str] = None
    travel_rewards: Optional[bool] = None
    annual_fee_max: Optional[float] = None
    annual_fee_min: Optional[float] = None
    available_credit_min: Optional[float] = None
    available_credit_max: Optional[float] = None
    card_status: Optional[str] = None
    extra_filters: dict[str, Any] = Field(default_factory=dict)


class ScenarioRequest(BaseModel):
    request_id: str
    natural_language: str
    normalized_criteria: Optional[NormalizedCriteria] = None
    hard_constraints: list[str] = Field(default_factory=list)
    soft_constraints: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class SearchCandidate(BaseModel):
    record_id: str
    source: str = "elasticsearch"
    match_features: dict[str, Any] = Field(default_factory=dict)
    lexical_score: float = 0.0
    semantic_score: float = 0.0
    raw_record: dict[str, Any] = Field(default_factory=dict)


class Recommendation(BaseModel):
    record_id: Optional[str] = None
    confidence: float
    confidence_tier: ConfidenceTier
    satisfied_constraints: list[str] = Field(default_factory=list)
    failed_constraints: list[str] = Field(default_factory=list)
    reasons: list[str] = Field(default_factory=list)


class ConditioningPlan(BaseModel):
    source_record_id: str
    transformations: list[dict[str, Any]]
    expected_postconditions: dict[str, Any]


class SynthesisPlan(BaseModel):
    template_id: str
    attributes: dict[str, Any]
    expected_postconditions: dict[str, Any]


class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


class ApprovalRequest(BaseModel):
    approval_id: str
    action_type: ActionType
    target: str
    plan_summary: str
    risk: str = "low"
    expires_at: Optional[datetime] = None
    status: ApprovalStatus = ApprovalStatus.PENDING


class ScenarioOutcome(BaseModel):
    request: ScenarioRequest
    selected_action: ActionType
    result: dict[str, Any] = Field(default_factory=dict)
    validation_passed: Optional[bool] = None
    user_feedback: Optional[str] = None
