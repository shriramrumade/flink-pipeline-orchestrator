"""
Conditioning Executor (Phase 5): the only component allowed to apply a
ConditioningPlan against Elasticsearch, and only after Approval Service has
recorded an APPROVED decision (checked by the orchestrator before this is
ever invoked — see section 20: "No state-changing action without explicit
approval").
"""
from app.domain.models.contracts import ConditioningPlan
from app.services.elasticsearch.client import ElasticsearchService, get_elasticsearch_service


class ConditioningExecutor:
    def __init__(self, es_service: ElasticsearchService | None = None) -> None:
        self._es = es_service or get_elasticsearch_service()

    async def execute(self, plan: ConditioningPlan) -> dict:
        partial_doc = {t["field"]: t["to_value"] for t in plan.transformations}
        return await self._es.update_record(plan.source_record_id, partial_doc)
