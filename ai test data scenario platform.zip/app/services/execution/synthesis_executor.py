"""
Synthesis Executor (Phase 6): the only component allowed to create a new
record, and only from an approved SynthesisPlan built from a controlled
template (section 9), and only after explicit approval.
"""
import uuid

from app.domain.models.contracts import SynthesisPlan
from app.services.elasticsearch.client import ElasticsearchService, get_elasticsearch_service


class SynthesisExecutor:
    def __init__(self, es_service: ElasticsearchService | None = None) -> None:
        self._es = es_service or get_elasticsearch_service()

    async def execute(self, plan: SynthesisPlan) -> dict:
        new_record_id = f"synth-{uuid.uuid4()}"
        return await self._es.index_document(new_record_id, plan.attributes)
