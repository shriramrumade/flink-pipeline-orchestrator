"""
Adapter for the self-hosted Llama deployment (doc section 13).
CRITICAL: only ever send the tester's natural-language text and receive back
normalized, non-sensitive structured criteria. Never send raw card records,
account identifiers, or PII to this client, and never give it ES write access.
"""
import json

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from app.core.config import get_settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class LlamaClient:
    def __init__(self) -> None:
        settings = get_settings()
        self._base_url = settings.llama_base_url
        self._model = settings.llama_model
        self._timeout = settings.llama_timeout_seconds

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
    async def generate_text(self, system_prompt: str, user_prompt: str) -> str:
        """
        Same transport as generate_json but returns free-form text - used by
        the Explanation Agent, which needs a sentence, not structured JSON.
        """
        payload = {
            "model": self._model,
            "prompt": user_prompt,
            "system": system_prompt,
            "stream": False,
        }
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(f"{self._base_url}/api/generate", json=payload)
            response.raise_for_status()
            body = response.json()
        return body.get("response", "").strip()

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
    async def generate_json(self, system_prompt: str, user_prompt: str) -> dict:
        """
        Calls a local Ollama-compatible /api/generate endpoint and parses the
        response as strict JSON. Swap this method's transport if the
        self-hosted deployment uses a different serving stack (vLLM, TGI, etc).
        """
        payload = {
            "model": self._model,
            "prompt": user_prompt,
            "system": system_prompt,
            "format": "json",
            "stream": False,
        }
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(f"{self._base_url}/api/generate", json=payload)
            response.raise_for_status()
            body = response.json()

        raw_text = body.get("response", "{}")
        try:
            return json.loads(raw_text)
        except json.JSONDecodeError:
            logger.error("llama_json_parse_failed", extra={"raw_text": raw_text})
            return {}


_client: LlamaClient | None = None


def get_llama_client() -> LlamaClient:
    global _client
    if _client is None:
        _client = LlamaClient()
    return _client
