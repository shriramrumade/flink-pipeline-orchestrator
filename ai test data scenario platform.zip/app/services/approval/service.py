"""
Approval Service (doc section 4 / API surface section 17). In-memory store for
Phase 1+2; swap for the `approvals` repository + PostgreSQL in Phase 5.
Enforces: "No state-changing action without explicit approval" (section 20).
"""
import uuid
from datetime import datetime, timedelta

from app.domain.models.contracts import ActionType, ApprovalRequest, ApprovalStatus

_APPROVALS: dict[str, ApprovalRequest] = {}


class ApprovalService:
    def create_request(self, action_type: ActionType, target: str, plan_summary: str, risk: str = "low", ttl_minutes: int = 60) -> ApprovalRequest:
        approval = ApprovalRequest(
            approval_id=str(uuid.uuid4()),
            action_type=action_type,
            target=target,
            plan_summary=plan_summary,
            risk=risk,
            expires_at=datetime.utcnow() + timedelta(minutes=ttl_minutes),
            status=ApprovalStatus.PENDING,
        )
        _APPROVALS[approval.approval_id] = approval
        return approval

    def get(self, approval_id: str) -> ApprovalRequest | None:
        return _APPROVALS.get(approval_id)

    def decide(self, approval_id: str, approved: bool) -> ApprovalRequest | None:
        approval = _APPROVALS.get(approval_id)
        if approval is None:
            return None
        if approval.expires_at and approval.expires_at < datetime.utcnow():
            approval.status = ApprovalStatus.EXPIRED
            return approval
        approval.status = ApprovalStatus.APPROVED if approved else ApprovalStatus.REJECTED
        return approval


_service: ApprovalService | None = None


def get_approval_service() -> ApprovalService:
    global _service
    if _service is None:
        _service = ApprovalService()
    return _service
