"""
Vector store adapter for Scenario Memory (doc section 10, Phase 4).

This implementation is a self-contained, dependency-free stand-in for a real
vector database: it turns normalized_criteria into a fixed-length embedding
via deterministic feature hashing, and does cosine-similarity search in
memory. It preserves the real interface (`similar_scenarios`,
`upsert_scenario`) so swapping in Pinecone/pgvector/Elasticsearch-kNN later
is a drop-in change with no callers touched.

Per section 10: only the *normalized* scenario is embedded — never raw,
sensitive card records.
"""
import hashlib
import math
from dataclasses import dataclass, field
from typing import Any

_EMBEDDING_DIM = 64


def embed_normalized_criteria(criteria: dict[str, Any]) -> list[float]:
    """Deterministic feature-hashing embedding. Each (field, value) pair is
    hashed into a bucket in a fixed-length vector; unset fields contribute
    nothing. Deterministic and dependency-free so Phase 1-4 don't require a
    live embedding model, while keeping semantically similar criteria
    (same field/value pairs) close in vector space."""
    vector = [0.0] * _EMBEDDING_DIM
    for key, value in sorted(criteria.items()):
        if value is None:
            continue
        token = f"{key}={value}"
        digest = hashlib.sha256(token.encode("utf-8")).hexdigest()
        bucket = int(digest, 16) % _EMBEDDING_DIM
        sign = 1.0 if int(digest[:2], 16) % 2 == 0 else -1.0
        vector[bucket] += sign

    norm = math.sqrt(sum(v * v for v in vector)) or 1.0
    return [v / norm for v in vector]


def cosine_similarity(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    return max(0.0, min(1.0, dot))  # both vectors are already unit-normalized


@dataclass
class ScenarioMemoryEntry:
    scenario_id: str
    embedding: list[float]
    metadata: dict[str, Any] = field(default_factory=dict)


class VectorStoreService:
    def __init__(self) -> None:
        self._store: dict[str, ScenarioMemoryEntry] = {}

    async def similar_scenarios(self, normalized_criteria: dict[str, Any], top_k: int = 5, min_similarity: float = 0.55) -> list[dict[str, Any]]:
        if not self._store:
            return []

        query_vector = embed_normalized_criteria(normalized_criteria)
        scored = []
        for entry in self._store.values():
            similarity = cosine_similarity(query_vector, entry.embedding)
            if similarity >= min_similarity:
                scored.append({"similarity": similarity, **entry.metadata})

        scored.sort(key=lambda e: e["similarity"], reverse=True)
        return scored[:top_k]

    async def upsert_scenario(self, scenario_id: str, normalized_criteria: dict[str, Any], metadata: dict[str, Any]) -> None:
        embedding = embed_normalized_criteria(normalized_criteria)
        self._store[scenario_id] = ScenarioMemoryEntry(
            scenario_id=scenario_id,
            embedding=embedding,
            metadata={"scenario_id": scenario_id, **metadata},
        )

    def size(self) -> int:
        return len(self._store)


_service: VectorStoreService | None = None


def get_vector_store_service() -> VectorStoreService:
    global _service
    if _service is None:
        _service = VectorStoreService()
    return _service
