"""
Deterministic bag-of-words text embedding, used specifically for
retrieval-augmented few-shot prompting (RAG for the Intent Agent).

Distinct from embed_normalized_criteria() in client.py: that one embeds
*structured* criteria (used for Scenario Memory / ranking). This one embeds
*raw natural language* so we can find similar past tester requests before
any criteria exist yet - which is exactly the retrieval step a real RAG
pipeline needs before generation.

Dependency-free by design (no sentence-transformers / OpenAI embeddings
required to run this repo offline). Swap for a real embedding model call
in production - the interface (`embed_text`, `cosine_similarity`) stays
the same.
"""
import hashlib
import math
import re

_EMBEDDING_DIM = 128
_TOKEN_RE = re.compile(r"[a-z0-9]+")

_STOPWORDS = {
    "a", "an", "the", "is", "are", "with", "and", "or", "of", "to", "for",
    "in", "on", "i", "me", "need", "want", "find", "give", "please",
}


def _tokenize(text: str) -> list[str]:
    tokens = _TOKEN_RE.findall(text.lower())
    return [t for t in tokens if t not in _STOPWORDS]


def embed_text(text: str) -> list[float]:
    """Hashing-trick bag-of-words embedding: each token hashes into a bucket
    in a fixed-length vector, magnitude reflects term frequency."""
    vector = [0.0] * _EMBEDDING_DIM
    tokens = _tokenize(text)
    if not tokens:
        return vector

    for token in tokens:
        digest = hashlib.sha256(token.encode("utf-8")).hexdigest()
        bucket = int(digest, 16) % _EMBEDDING_DIM
        sign = 1.0 if int(digest[:2], 16) % 2 == 0 else -1.0
        vector[bucket] += sign

    norm = math.sqrt(sum(v * v for v in vector)) or 1.0
    return [v / norm for v in vector]


def cosine_similarity(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    return max(-1.0, min(1.0, dot))
