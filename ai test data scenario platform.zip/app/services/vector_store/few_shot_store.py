"""
Few-Shot Example Store (RAG for the Intent Agent).

Every time the Intent Agent successfully parses a request into non-empty
criteria, that (natural_language -> normalized_criteria) pair is stored here.
On the *next* request, the most similar past examples are retrieved by text
similarity and injected into the LLM prompt as few-shot examples - this is
the retrieve-then-generate loop that makes it genuine RAG, as opposed to the
Scenario Memory vector store (retrieval feeds ranking math, never a prompt).

Only ever stores/returns normalized_criteria - never raw card data, account
identifiers, or PII (same boundary as section 13).
"""
from dataclasses import dataclass, field
from typing import Any

from app.services.vector_store.text_embedding import cosine_similarity, embed_text

_MAX_EXAMPLES = 500  # simple cap so the in-memory store doesn't grow unbounded


@dataclass
class FewShotExample:
    natural_language: str
    normalized_criteria: dict[str, Any]
    embedding: list[float] = field(default_factory=list)


class FewShotExampleStore:
    def __init__(self) -> None:
        self._examples: list[FewShotExample] = []

    def add_example(self, natural_language: str, normalized_criteria: dict[str, Any]) -> None:
        # Skip near-empty parses - they make poor few-shot examples and would
        # just teach the model to return nothing.
        if not any(v is not None for v in normalized_criteria.values()):
            return

        embedding = embed_text(natural_language)
        self._examples.append(FewShotExample(natural_language, normalized_criteria, embedding))
        if len(self._examples) > _MAX_EXAMPLES:
            self._examples.pop(0)

    def retrieve_similar(self, natural_language: str, top_k: int = 3, min_similarity: float = 0.15) -> list[FewShotExample]:
        if not self._examples:
            return []

        query_embedding = embed_text(natural_language)
        scored = [
            (cosine_similarity(query_embedding, ex.embedding), ex)
            for ex in self._examples
        ]
        scored = [pair for pair in scored if pair[0] >= min_similarity]
        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [ex for _, ex in scored[:top_k]]

    def size(self) -> int:
        return len(self._examples)


_store: FewShotExampleStore | None = None


def get_few_shot_store() -> FewShotExampleStore:
    global _store
    if _store is None:
        _store = FewShotExampleStore()
    return _store
