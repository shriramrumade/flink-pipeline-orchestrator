"""
Elasticsearch adapter (doc section 16): the authoritative search source for
card/test-data. Supports BM25 + structured filters; a `knn` clause can be
added once embeddings are populated (Phase 4, Scenario Memory).
"""
from typing import Any

from elasticsearch import AsyncElasticsearch

from app.core.config import get_settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class ElasticsearchService:
    def __init__(self) -> None:
        settings = get_settings()
        auth = None
        if settings.elasticsearch_user and settings.elasticsearch_password:
            auth = (settings.elasticsearch_user, settings.elasticsearch_password)

        self._client = AsyncElasticsearch(settings.elasticsearch_url, basic_auth=auth)
        self._index = settings.elasticsearch_index

    async def search(self, query_dsl: dict[str, Any], size: int = 25) -> list[dict[str, Any]]:
        response = await self._client.search(index=self._index, body=query_dsl, size=size)
        hits = response.get("hits", {}).get("hits", [])
        results = []
        for hit in hits:
            record = hit.get("_source", {})
            record["_id"] = hit.get("_id")
            record["_score"] = hit.get("_score", 0.0)
            results.append(record)
        return results

    async def update_record(self, record_id: str, partial_doc: dict[str, Any]) -> dict[str, Any]:
        """
        Applies a partial update to an existing record. Only ever called by
        the Conditioning Executor after an approved ConditioningPlan — never
        directly by an agent (section 13: the LLM must not be granted direct
        Elasticsearch write access; this client method is not exposed to it).
        """
        await self._client.update(index=self._index, id=record_id, doc=partial_doc)
        result = await self._client.get(index=self._index, id=record_id)
        record = result.get("_source", {})
        record["_id"] = result.get("_id")
        return record

    async def index_document(self, record_id: str, doc: dict[str, Any]) -> dict[str, Any]:
        """
        Creates a brand-new record. Only ever called by the Synthesis
        Executor after an approved SynthesisPlan built from a controlled
        template (section 9).
        """
        await self._client.index(index=self._index, id=record_id, document=doc)
        doc_with_id = dict(doc)
        doc_with_id["_id"] = record_id
        return doc_with_id

    async def health(self) -> bool:
        try:
            info = await self._client.info()
            return bool(info)
        except Exception as exc:  # noqa: BLE001
            logger.warning("elasticsearch_health_check_failed", extra={"error": str(exc)})
            return False

    async def close(self) -> None:
        await self._client.close()


_service: ElasticsearchService | None = None


def get_elasticsearch_service() -> ElasticsearchService:
    global _service
    if _service is None:
        _service = ElasticsearchService()
    return _service
