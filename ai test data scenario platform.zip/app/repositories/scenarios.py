"""In-memory scenario store for Phase 1+2 (swap for PostgreSQL in Phase 7)."""
from app.domain.models.contracts import ScenarioOutcome

_SCENARIOS: dict[str, ScenarioOutcome] = {}


class ScenariosRepository:
    def save(self, request_id: str, outcome: ScenarioOutcome) -> None:
        _SCENARIOS[request_id] = outcome

    def get(self, request_id: str) -> ScenarioOutcome | None:
        return _SCENARIOS.get(request_id)

    def attach_feedback(self, request_id: str, feedback: str) -> ScenarioOutcome | None:
        outcome = _SCENARIOS.get(request_id)
        if outcome is None:
            return None
        outcome.user_feedback = feedback
        _SCENARIOS[request_id] = outcome
        return outcome
