"""Read-side accessor kept thin; Search Agent talks to Elasticsearch directly
for Phase 2. This repository exists as the seam for a future caching layer
or a secondary datastore, per the package structure in section 14."""
from app.services.elasticsearch.client import ElasticsearchService, get_elasticsearch_service


class CardsRepository:
    def __init__(self, es_service: ElasticsearchService | None = None) -> None:
        self._es = es_service or get_elasticsearch_service()

    async def get_by_id(self, record_id: str) -> dict | None:
        # Phase 5+: implement via ES `get` API when conditioning needs the
        # full current record.
        return None
