"""Persistence seam for approvals; app.services.approval.service currently
holds state in-memory for Phase 1+2 and will delegate here in Phase 7."""
