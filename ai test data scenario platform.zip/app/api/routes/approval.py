"""
POST /v1/scenarios/{id}/approve-conditioning
POST /v1/scenarios/{id}/approve-synthesis
GET  /v1/approvals/{id}
(doc section 17). Approving here actually triggers the corresponding
executor via the Orchestrator and returns the validated result - this is the
one and only path that can change data, per section 20.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.core.security import verify_api_key
from app.orchestrator.workflow import Orchestrator, OrchestratorError, get_orchestrator
from app.services.approval.service import ApprovalService, get_approval_service

router = APIRouter(tags=["approvals"])


class ApprovalDecision(BaseModel):
    approval_id: str
    approved: bool


@router.post("/v1/scenarios/{scenario_id}/approve-conditioning", dependencies=[Depends(verify_api_key)])
async def approve_conditioning(
    scenario_id: str,
    decision: ApprovalDecision,
    orchestrator: Orchestrator = Depends(get_orchestrator),
) -> dict:
    try:
        return await orchestrator.execute_conditioning(scenario_id, decision.approval_id, decision.approved)
    except OrchestratorError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/v1/scenarios/{scenario_id}/approve-synthesis", dependencies=[Depends(verify_api_key)])
async def approve_synthesis(
    scenario_id: str,
    decision: ApprovalDecision,
    orchestrator: Orchestrator = Depends(get_orchestrator),
) -> dict:
    try:
        return await orchestrator.execute_synthesis(scenario_id, decision.approval_id, decision.approved)
    except OrchestratorError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/v1/approvals/{approval_id}", dependencies=[Depends(verify_api_key)])
async def get_approval(approval_id: str, approvals: ApprovalService = Depends(get_approval_service)) -> dict:
    approval = approvals.get(approval_id)
    if approval is None:
        raise HTTPException(status_code=404, detail="Approval not found")
    return approval.model_dump()
