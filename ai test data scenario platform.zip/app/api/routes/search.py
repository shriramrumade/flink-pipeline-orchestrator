"""POST /v1/scenarios/search (doc section 17)."""
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from app.core.security import get_correlation_id, verify_api_key
from app.orchestrator.workflow import Orchestrator, get_orchestrator

router = APIRouter(prefix="/v1/scenarios", tags=["search"])


class SearchRequest(BaseModel):
    natural_language: str = Field(..., min_length=1, examples=[
        "Find a Chase Sapphire card with travel rewards, annual fee below 600, "
        "and available credit above 5,000."
    ])


@router.post("/search", dependencies=[Depends(verify_api_key)])
async def search_scenarios(
    payload: SearchRequest,
    correlation_id: str = Depends(get_correlation_id),
    orchestrator: Orchestrator = Depends(get_orchestrator),
) -> dict:
    return await orchestrator.run_search_flow(payload.natural_language, correlation_id)
