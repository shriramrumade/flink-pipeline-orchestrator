"""GET /v1/scenarios/{id} (doc section 17)."""
from fastapi import APIRouter, Depends, HTTPException

from app.core.security import verify_api_key
from app.repositories.scenarios import ScenariosRepository

router = APIRouter(prefix="/v1/scenarios", tags=["scenarios"])


@router.get("/{scenario_id}", dependencies=[Depends(verify_api_key)])
async def get_scenario(scenario_id: str) -> dict:
    repo = ScenariosRepository()
    outcome = repo.get(scenario_id)
    if outcome is None:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return outcome.model_dump()
