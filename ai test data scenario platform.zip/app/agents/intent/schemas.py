from pydantic import BaseModel


class IntentAgentOutput(BaseModel):
    issuer: str | None = None
    product_family: str | None = None
    travel_rewards: bool | None = None
    annual_fee_max: float | None = None
    annual_fee_min: float | None = None
    available_credit_min: float | None = None
    available_credit_max: float | None = None
    card_status: str | None = None
    hard_constraints: list[str] = []
    soft_constraints: list[str] = []
