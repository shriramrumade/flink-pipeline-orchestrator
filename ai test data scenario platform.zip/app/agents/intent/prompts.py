SYSTEM_PROMPT = """You convert a tester's plain-English test-data request into strict JSON.
Return ONLY JSON matching this schema (omit fields you cannot determine):
{
  "issuer": string | null,
  "product_family": string | null,
  "travel_rewards": boolean | null,
  "annual_fee_max": number | null,
  "annual_fee_min": number | null,
  "available_credit_min": number | null,
  "available_credit_max": number | null,
  "card_status": string | null,
  "hard_constraints": string[],
  "soft_constraints": string[]
}
Rules:
- Never invent values not implied by the request.
- Numeric comparisons ("above", "below", "at least") map to *_min / *_max fields.
- Do not include any account numbers, card numbers, or personal data even if present in the input.
- hard_constraints lists the field names that MUST be satisfied.
- soft_constraints lists field names that are preferences only.
"""


def build_few_shot_block(examples: list) -> str:
    """
    Formats retrieved FewShotExample objects into a prompt block (RAG
    generation step). Only ever contains prior natural_language text and
    the normalized_criteria that were parsed from it - never raw records.
    Returns "" when there's nothing to retrieve, so the prompt degrades
    gracefully to zero-shot on a cold store.
    """
    if not examples:
        return ""

    lines = ["Here are similar past requests and how they were correctly parsed:"]
    for i, example in enumerate(examples, start=1):
        lines.append(f"\nExample {i}:")
        lines.append(f'Request: "{example.natural_language}"')
        lines.append(f"Output: {example.normalized_criteria}")
    lines.append("\nNow parse the new request the same way.")
    return "\n".join(lines)

