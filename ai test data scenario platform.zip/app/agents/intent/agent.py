"""
Intent Agent (doc section 5 / section 7): the only component that calls the
LLM for structured parsing. Converts plain English into strict, non-sensitive
structured criteria. It never sees or returns raw database records.

RAG addition: before calling the LLM, retrieves the most similar
successfully-parsed past requests from the FewShotExampleStore and injects
them into the prompt as few-shot examples. This is retrieval feeding
*generation* - the LLM's next output is conditioned on retrieved context -
which is what makes this the genuine RAG component in the platform (as
opposed to the Scenario Memory vector store, whose retrieval only feeds
deterministic ranking math, never a prompt).

The example store is only ever populated with (natural_language,
normalized_criteria) pairs - never raw records or PII, preserving the same
sensitive-data boundary as everywhere else the LLM is involved.
"""
from app.agents.intent.prompts import SYSTEM_PROMPT, build_few_shot_block
from app.agents.intent.schemas import IntentAgentOutput
from app.core.logging import get_logger
from app.domain.models.contracts import NormalizedCriteria
from app.services.llama.client import LlamaClient, get_llama_client
from app.services.vector_store.few_shot_store import FewShotExampleStore, get_few_shot_store

logger = get_logger(__name__)


class IntentAgent:
    def __init__(
        self,
        llama_client: LlamaClient | None = None,
        few_shot_store: FewShotExampleStore | None = None,
        few_shot_top_k: int = 3,
    ) -> None:
        self._llama = llama_client or get_llama_client()
        self._few_shot_store = few_shot_store or get_few_shot_store()
        self._few_shot_top_k = few_shot_top_k

    async def interpret(self, natural_language: str) -> tuple[NormalizedCriteria, list[str], list[str]]:
        # --- Retrieve ---
        examples = self._few_shot_store.retrieve_similar(natural_language, top_k=self._few_shot_top_k)
        few_shot_block = build_few_shot_block(examples)
        logger.info(
            "intent_agent_retrieval",
            extra={"examples_retrieved": len(examples), "store_size": self._few_shot_store.size()},
        )

        # --- Augment + Generate ---
        user_prompt = f"{few_shot_block}\n\nRequest: \"{natural_language}\"" if few_shot_block else natural_language
        raw = await self._llama.generate_json(SYSTEM_PROMPT, user_prompt)

        try:
            parsed = IntentAgentOutput.model_validate(raw)
        except Exception:  # noqa: BLE001
            logger.warning("intent_agent_parse_fallback", extra={"raw": raw})
            parsed = IntentAgentOutput()

        criteria = NormalizedCriteria(
            issuer=parsed.issuer,
            product_family=parsed.product_family,
            travel_rewards=parsed.travel_rewards,
            annual_fee_max=parsed.annual_fee_max,
            annual_fee_min=parsed.annual_fee_min,
            available_credit_min=parsed.available_credit_min,
            available_credit_max=parsed.available_credit_max,
            card_status=parsed.card_status,
        )

        # --- Store this example for future retrieval (self-improving loop) ---
        self._few_shot_store.add_example(natural_language, criteria.model_dump())

        return criteria, parsed.hard_constraints, parsed.soft_constraints
