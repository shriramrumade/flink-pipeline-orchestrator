"""
Gap Analysis Agent (Phase 5+ target). Explains which constraints prevent a
match and what could be relaxed or transformed. Deterministic - built from
the failed_constraints list already computed by the Ranking Agent.
"""
from app.agents.ranking.agent import RankedCandidate


class GapAnalysisAgent:
    def explain(self, ranked: list[RankedCandidate]) -> dict:
        if not ranked:
            return {"message": "No candidates retrieved.", "failed_constraints": []}
        best = ranked[0]
        return {
            "message": "Closest candidate fails the following hard constraints.",
            "record_id": best.candidate.record_id,
            "failed_constraints": best.failed,
        }
