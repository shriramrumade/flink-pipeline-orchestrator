"""
Learning Agent (doc section 10 / Phase 4): captures outcomes and updates
Scenario Memory. Stores evidence (normalized scenario, action, validation
result), not unrestricted model memory (section 20). A historical success
must never override current hard constraints (section 10) - the Ranking
Agent only ever uses this as one weighted signal, never a gate.
"""
from app.domain.models.contracts import ScenarioOutcome
from app.services.vector_store.client import VectorStoreService, get_vector_store_service


class LearningAgent:
    def __init__(self, vector_store: VectorStoreService | None = None) -> None:
        self._vector_store = vector_store or get_vector_store_service()

    async def record_outcome(self, outcome: ScenarioOutcome) -> None:
        if outcome.request.normalized_criteria is None:
            return

        record_id = outcome.result.get("_id") or outcome.result.get("record_id")
        await self._vector_store.upsert_scenario(
            scenario_id=outcome.request.request_id,
            normalized_criteria=outcome.request.normalized_criteria.model_dump(),
            metadata={
                "record_id": record_id,
                "action": outcome.selected_action.value,
                "validation_passed": outcome.validation_passed,
            },
        )
