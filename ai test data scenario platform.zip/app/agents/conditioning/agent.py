"""
Conditioning Agent (doc section 5 / Phase 5): maps a requirement to an
approved, deterministic transformation plan. Every field it proposes to
change must pass app.domain.policies.policy — it never invents a
transformation, and it never executes anything itself (execution happens
only after explicit approval, via the Conditioning Executor).
"""
from app.domain.models.contracts import ConditioningPlan, NormalizedCriteria
from app.domain.policies.policy import is_transformation_allowed, target_field_for_constraint


class ConditioningAgent:
    def propose_plan(
        self,
        source_record_id: str,
        criteria: NormalizedCriteria,
        failed_constraints: list[str],
    ) -> ConditioningPlan | None:
        transformations: list[dict] = []
        postconditions: dict = {}

        for constraint_name in failed_constraints:
            if not is_transformation_allowed(constraint_name):
                # Any single disallowed failed constraint means conditioning
                # cannot fully satisfy the requirement; bail out rather than
                # propose a partial, misleading plan.
                return None

            field = target_field_for_constraint(constraint_name)
            new_value = self._target_value_for(constraint_name, criteria)
            if field is None or new_value is None:
                return None

            transformations.append({"field": field, "to_value": new_value, "reason": constraint_name})
            postconditions[field] = new_value

        if not transformations:
            return None

        return ConditioningPlan(
            source_record_id=source_record_id,
            transformations=transformations,
            expected_postconditions=postconditions,
        )

    @staticmethod
    def _target_value_for(constraint_name: str, criteria: NormalizedCriteria):
        mapping = {
            "available_credit_min": criteria.available_credit_min,
            "available_credit_max": criteria.available_credit_max,
            "card_status": criteria.card_status,
        }
        return mapping.get(constraint_name)
