"""
Search Agent (doc section 5): retrieves candidate records from Elasticsearch.
Purely deterministic - no LLM involvement, per section 3 architecture.
"""
from app.domain.models.contracts import SearchCandidate
from app.services.elasticsearch.client import ElasticsearchService, get_elasticsearch_service


class SearchAgent:
    def __init__(self, es_service: ElasticsearchService | None = None) -> None:
        self._es = es_service or get_elasticsearch_service()

    async def retrieve(self, query_dsl: dict, size: int = 25) -> list[SearchCandidate]:
        records = await self._es.search(query_dsl, size=size)
        candidates = []
        for record in records:
            candidates.append(
                SearchCandidate(
                    record_id=record.get("_id", "unknown"),
                    source="elasticsearch",
                    lexical_score=float(record.get("_score", 0.0)),
                    semantic_score=0.0,  # populated once vector retrieval (Phase 4) is wired in
                    raw_record=record,
                )
            )
        return candidates
