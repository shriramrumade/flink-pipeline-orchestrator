"""
Synthesis Agent (doc section 5 / Phase 6): builds a new-card creation plan
from approved templates only — never invents authoritative attributes
(section 2 non-goal, section 9). Fills a matched template deterministically
from normalized criteria; anything the criteria don't specify falls back to
the template's approved defaults.
"""
from app.domain.models.contracts import NormalizedCriteria, SynthesisPlan
from app.domain.policies.templates import find_template


class SynthesisAgent:
    def propose_plan(self, criteria: NormalizedCriteria) -> SynthesisPlan | None:
        template = find_template(criteria.issuer, criteria.product_family)
        if template is None:
            return None

        attributes = dict(template.default_attributes)

        # Overlay explicit tester-specified criteria on top of template
        # defaults, but only for fields the template already governs -
        # synthesis never introduces attributes outside the approved shape.
        if criteria.issuer is not None:
            attributes["issuer"] = criteria.issuer
        if criteria.product_family is not None:
            attributes["product_family"] = criteria.product_family
        if criteria.travel_rewards is not None:
            attributes["travel_rewards"] = criteria.travel_rewards
        if criteria.annual_fee_max is not None:
            attributes["annual_fee"] = min(attributes.get("annual_fee", criteria.annual_fee_max), criteria.annual_fee_max)
        if criteria.available_credit_min is not None:
            attributes["available_credit"] = max(attributes.get("available_credit", 0.0), criteria.available_credit_min)
        if criteria.card_status is not None:
            attributes["status"] = criteria.card_status

        return SynthesisPlan(
            template_id=template.template_id,
            attributes=attributes,
            expected_postconditions=attributes,
        )
