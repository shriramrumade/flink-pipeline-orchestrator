"""
Query Planner Agent (doc section 5): pure Python, deterministic. Builds
Elasticsearch DSL (structured filters + BM25) from normalized criteria.
kNN/vector clauses can be added here once Scenario Memory (Phase 4) is live.
"""
from typing import Any

from app.domain.models.contracts import NormalizedCriteria


class QueryPlannerAgent:
    def build_query(self, criteria: NormalizedCriteria, free_text: str) -> dict[str, Any]:
        must: list[dict[str, Any]] = []
        filters: list[dict[str, Any]] = []

        if free_text:
            must.append({"match": {"description": {"query": free_text, "boost": 1.0}}})

        if criteria.issuer:
            filters.append({"term": {"issuer.keyword": criteria.issuer}})
        if criteria.product_family:
            filters.append({"term": {"product_family.keyword": criteria.product_family}})
        if criteria.travel_rewards is not None:
            filters.append({"term": {"travel_rewards": criteria.travel_rewards}})
        if criteria.card_status:
            filters.append({"term": {"status.keyword": criteria.card_status}})

        if criteria.annual_fee_max is not None or criteria.annual_fee_min is not None:
            range_clause: dict[str, Any] = {}
            if criteria.annual_fee_max is not None:
                range_clause["lte"] = criteria.annual_fee_max
            if criteria.annual_fee_min is not None:
                range_clause["gte"] = criteria.annual_fee_min
            filters.append({"range": {"annual_fee": range_clause}})

        if criteria.available_credit_min is not None or criteria.available_credit_max is not None:
            range_clause = {}
            if criteria.available_credit_min is not None:
                range_clause["gte"] = criteria.available_credit_min
            if criteria.available_credit_max is not None:
                range_clause["lte"] = criteria.available_credit_max
            filters.append({"range": {"available_credit": range_clause}})

        if not must:
            must.append({"match_all": {}})

        return {"query": {"bool": {"must": must, "filter": filters}}}
