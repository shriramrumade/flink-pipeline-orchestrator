"""
Ranking Agent (doc section 5 / section 11): scores candidates without relying
on LLM judgment. Hard constraints are gates; the weighted score only applies
to candidates that pass all hard constraints (or is used to rank *why*
something failed, for Gap Analysis).

Conceptual weights (section 11), pulled from settings so they're tunable via
the evaluation dataset without a code change:
  40% hard/soft constraint match, 25% ES relevance, 20% semantic similarity,
  10% historical success, 5% freshness/data quality.
"""
from app.core.config import get_settings
from app.domain.models.contracts import NormalizedCriteria, SearchCandidate
from app.domain.rules.constraints import hard_constraints_satisfied
from app.services.vector_store.client import VectorStoreService, get_vector_store_service


class RankedCandidate:
    def __init__(self, candidate: SearchCandidate, score: float, satisfied: list[str], failed: list[str]):
        self.candidate = candidate
        self.score = score
        self.satisfied = satisfied
        self.failed = failed


class RankingAgent:
    def __init__(self, vector_store: VectorStoreService | None = None) -> None:
        self._settings = get_settings()
        self._vector_store = vector_store or get_vector_store_service()

    @staticmethod
    def _normalize(value: float, max_value: float) -> float:
        if max_value <= 0:
            return 0.0
        return max(0.0, min(1.0, value / max_value))

    async def rank(self, criteria: NormalizedCriteria, candidates: list[SearchCandidate]) -> list[RankedCandidate]:
        if not candidates:
            return []

        max_lexical = max((c.lexical_score for c in candidates), default=0.0) or 1.0
        historical = await self._vector_store.similar_scenarios(criteria.model_dump())
        historical_ids = {h.get("record_id") for h in historical}

        ranked: list[RankedCandidate] = []
        for candidate in candidates:
            hard_ok, satisfied, failed = hard_constraints_satisfied(criteria, candidate)
            constraint_score = 1.0 if hard_ok else len(satisfied) / max(1, len(satisfied) + len(failed))
            es_score = self._normalize(candidate.lexical_score, max_lexical)
            semantic_score = candidate.semantic_score  # already 0..1 once Phase 4 populates it
            historical_score = 1.0 if candidate.record_id in historical_ids else 0.0
            freshness_score = 1.0  # placeholder until data-quality signal exists

            weighted = (
                self._settings.weight_constraint_match * constraint_score
                + self._settings.weight_es_relevance * es_score
                + self._settings.weight_semantic_similarity * semantic_score
                + self._settings.weight_historical_success * historical_score
                + self._settings.weight_freshness * freshness_score
            )

            # Hard-constraint gate: failing candidates are capped below the
            # exact-match threshold regardless of weighted score (section 11).
            final_score = weighted if hard_ok else min(weighted, self._settings.recommendation_threshold - 0.01)

            ranked.append(RankedCandidate(candidate, final_score, satisfied, failed))

        ranked.sort(key=lambda r: r.score, reverse=True)
        return ranked
