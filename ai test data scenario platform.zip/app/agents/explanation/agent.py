"""
Explanation Agent (RAG use case #2). Retrieves the already-computed,
deterministic Gap Analysis output (which candidate, which constraints
failed, what plan is proposed) and feeds it to the LLM as context to
generate a short natural-language explanation for the tester.

This is genuine RAG: retrieved structured data becomes grounding context for
an LLM *generation* step. It is deliberately kept out of the decision path -
the Decision Agent has already chosen the action before this agent ever
runs, so a bad or missing LLM explanation can never change what the system
does, only how it's described to the tester.

Sensitive-data boundary (section 13): the sanitizer below strips anything
that isn't a small, explicitly-allowed set of non-identifying fields before
it goes anywhere near the prompt - no record IDs beyond a generic
"the closest candidate", no card numbers, no account identifiers.
"""
from typing import Any

from app.core.logging import get_logger
from app.agents.explanation.prompts import SYSTEM_PROMPT
from app.domain.models.contracts import NormalizedCriteria
from app.services.llama.client import LlamaClient, get_llama_client

logger = get_logger(__name__)

_ALLOWED_RECORD_FIELDS = {"issuer", "product_family", "travel_rewards", "annual_fee", "available_credit", "status"}


def _sanitize_record(raw_record: dict[str, Any]) -> dict[str, Any]:
    """Strips everything except a small allow-list of non-identifying
    fields. card_number_last4, internal record IDs, timestamps, etc. never
    reach this point."""
    return {k: v for k, v in raw_record.items() if k in _ALLOWED_RECORD_FIELDS}


class ExplanationAgent:
    def __init__(self, llama_client: LlamaClient | None = None) -> None:
        self._llama = llama_client or get_llama_client()

    async def explain_gap(
        self,
        criteria: NormalizedCriteria,
        gap_analysis: dict[str, Any],
        candidate_summary: dict[str, Any] | None = None,
        proposed_plan_kind: str | None = None,  # "condition" | "synthesize" | None
    ) -> str:
        # --- Retrieve (already computed deterministically upstream) ---
        sanitized_record = _sanitize_record(candidate_summary) if candidate_summary else {}
        context = {
            "requested_criteria": {k: v for k, v in criteria.model_dump().items() if v is not None},
            "failed_constraints": gap_analysis.get("failed_constraints", []),
            "closest_candidate_summary": sanitized_record,
            "proposed_next_step": proposed_plan_kind,
        }

        # --- Augment + Generate ---
        user_prompt = (
            "Explain this test-data search outcome to the tester using only "
            f"these facts:\n{context}"
        )

        try:
            text = await self._llama.generate_text(SYSTEM_PROMPT, user_prompt)
        except Exception:  # noqa: BLE001
            logger.warning("explanation_agent_generation_failed", extra={"context": context})
            text = ""

        if not text:
            # Deterministic fallback so the API never depends on the LLM
            # being reachable for a correct decision - only for a nicer
            # message.
            text = self._fallback_message(gap_analysis, proposed_plan_kind)

        return text

    @staticmethod
    def _fallback_message(gap_analysis: dict[str, Any], proposed_plan_kind: str | None) -> str:
        failed = ", ".join(gap_analysis.get("failed_constraints", [])) or "some constraints"
        base = f"No exact match was found; the closest candidate fails: {failed}."
        if proposed_plan_kind == "condition":
            return base + " A conditioning plan is available and requires your approval to run."
        if proposed_plan_kind == "synthesize":
            return base + " A synthesis plan from an approved template is available and requires your approval."
        return base
