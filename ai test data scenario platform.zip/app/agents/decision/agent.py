"""
Decision Agent (doc section 5 / section 12): chooses exact match,
recommendation, conditioning, synthesis, clarification or failure - purely
via deterministic thresholds, never LLM judgment.
"""
from app.agents.ranking.agent import RankedCandidate
from app.core.config import get_settings
from app.domain.models.contracts import ActionType, ConfidenceTier, Recommendation


class DecisionAgent:
    def __init__(self) -> None:
        self._settings = get_settings()

    def decide(self, ranked: list[RankedCandidate]) -> tuple[ActionType, Recommendation | None]:
        if not ranked:
            return ActionType.CLARIFY, None

        best = ranked[0]

        if not best.failed and best.score >= self._settings.exact_match_threshold:
            rec = Recommendation(
                record_id=best.candidate.record_id,
                confidence=best.score,
                confidence_tier=ConfidenceTier.EXACT,
                satisfied_constraints=best.satisfied,
                failed_constraints=best.failed,
                reasons=["All hard constraints satisfied above exact-match threshold."],
            )
            return ActionType.RETURN_MATCH, rec

        if best.score >= self._settings.recommendation_threshold:
            rec = Recommendation(
                record_id=best.candidate.record_id,
                confidence=best.score,
                confidence_tier=ConfidenceTier.STRONG_RECOMMENDATION,
                satisfied_constraints=best.satisfied,
                failed_constraints=best.failed,
                reasons=["Most constraints satisfied; below exact-match threshold."],
            )
            return ActionType.RECOMMEND, rec

        # Below recommendation threshold: Gap Analysis / Conditioning /
        # Synthesis agents take over (Phase 5/6). Phase 1+2 surfaces this as
        # a structured "unfulfillable-for-now" recommendation.
        rec = Recommendation(
            record_id=best.candidate.record_id,
            confidence=best.score,
            confidence_tier=ConfidenceTier.CONDITIONABLE,
            satisfied_constraints=best.satisfied,
            failed_constraints=best.failed,
            reasons=["No confident match; candidate returned for gap analysis."],
        )
        return ActionType.CONDITION, rec
