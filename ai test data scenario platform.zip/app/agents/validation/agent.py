"""
Validation Agent (Phase 5/6 target). Verifies the resulting record satisfies
the original scenario after any conditioning/synthesis execution.
"""
from app.domain.models.contracts import NormalizedCriteria, SearchCandidate
from app.domain.rules.constraints import hard_constraints_satisfied


class ValidationAgent:
    def validate(self, criteria: NormalizedCriteria, resulting_record: dict) -> bool:
        candidate = SearchCandidate(record_id=resulting_record.get("_id", "unknown"), raw_record=resulting_record)
        ok, _, _ = hard_constraints_satisfied(criteria, candidate)
        return ok
