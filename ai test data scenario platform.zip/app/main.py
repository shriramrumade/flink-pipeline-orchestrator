"""
FastAPI entrypoint (doc section 4: API Gateway). Wires routers, logging, and
health/feedback endpoints from the API surface in section 17.
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from pydantic import BaseModel

from app.api.routes import approval, scenarios, search
from app.core.logging import configure_logging, get_logger
from app.repositories.scenarios import ScenariosRepository
from app.services.elasticsearch.client import get_elasticsearch_service

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging()
    logger.info("app_startup")
    yield
    es = get_elasticsearch_service()
    await es.close()
    logger.info("app_shutdown")


app = FastAPI(
    title="AI Test Data Scenario Platform",
    description="FastAPI + Self-hosted Llama + Elasticsearch + Vector DB",
    version="0.1.0",
    lifespan=lifespan,
)

app.include_router(search.router)
app.include_router(scenarios.router)
app.include_router(approval.router)


class FeedbackRequest(BaseModel):
    request_id: str
    outcome: str
    notes: str | None = None


@app.post("/v1/feedback", tags=["feedback"])
async def submit_feedback(payload: FeedbackRequest) -> dict:
    """
    Persists tester feedback against the stored ScenarioOutcome. In Phase 7
    this publishes to Kafka instead of writing synchronously, so multiple
    consumers (analytics, re-ranking, alerting) can react independently -
    the repository write here is the durable source of truth either way.
    """
    logger.info("feedback_received", extra={"request_id": payload.request_id, "outcome": payload.outcome})
    repo = ScenariosRepository()
    updated = repo.attach_feedback(payload.request_id, payload.outcome + (f": {payload.notes}" if payload.notes else ""))
    if updated is None:
        return {"status": "not_found"}
    return {"status": "recorded"}


@app.get("/v1/health", tags=["health"])
async def health() -> dict:
    es = get_elasticsearch_service()
    es_ok = await es.health()
    return {"status": "ok" if es_ok else "degraded", "elasticsearch": es_ok}
