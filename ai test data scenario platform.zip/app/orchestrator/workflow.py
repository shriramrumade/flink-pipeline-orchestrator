"""
Orchestrator (doc section 3 / section 6): controls the workflow and routes
between specialized agents. Implements the full end-to-end decision flow
from section 6, steps 1-13:

  1-8:  intent -> query plan -> search -> rank -> decide (run_search_flow)
  9-10: gap analysis -> approval -> conditioning execution + validation
  11-12: synthesis fallback -> approval -> synthesis execution + validation
  13:   store outcome in Scenario Memory (Learning Agent)

Every state-changing branch (conditioning, synthesis) is gated behind an
explicit ApprovalRequest that must be APPROVED before an executor runs
(section 20).
"""
import uuid

from app.agents.conditioning.agent import ConditioningAgent
from app.agents.decision.agent import DecisionAgent
from app.agents.explanation.agent import ExplanationAgent
from app.agents.gap_analysis.agent import GapAnalysisAgent
from app.agents.intent.agent import IntentAgent
from app.agents.learning.agent import LearningAgent
from app.agents.query_planner.agent import QueryPlannerAgent
from app.agents.ranking.agent import RankingAgent
from app.agents.search.agent import SearchAgent
from app.agents.synthesis.agent import SynthesisAgent
from app.agents.validation.agent import ValidationAgent
from app.core.logging import get_logger
from app.domain.models.contracts import ActionType, ApprovalStatus, ScenarioOutcome, ScenarioRequest
from app.orchestrator.session_store import SessionStore, get_session_store
from app.orchestrator.state import WorkflowState
from app.repositories.scenarios import ScenariosRepository
from app.services.approval.service import ApprovalService, get_approval_service
from app.services.execution.conditioning_executor import ConditioningExecutor
from app.services.execution.synthesis_executor import SynthesisExecutor

logger = get_logger(__name__)


class OrchestratorError(Exception):
    pass


class Orchestrator:
    def __init__(
        self,
        intent_agent: IntentAgent | None = None,
        query_planner: QueryPlannerAgent | None = None,
        search_agent: SearchAgent | None = None,
        ranking_agent: RankingAgent | None = None,
        decision_agent: DecisionAgent | None = None,
        gap_analysis_agent: GapAnalysisAgent | None = None,
        conditioning_agent: ConditioningAgent | None = None,
        synthesis_agent: SynthesisAgent | None = None,
        validation_agent: ValidationAgent | None = None,
        learning_agent: LearningAgent | None = None,
        explanation_agent: ExplanationAgent | None = None,
        conditioning_executor: ConditioningExecutor | None = None,
        synthesis_executor: SynthesisExecutor | None = None,
        approval_service: ApprovalService | None = None,
        session_store: SessionStore | None = None,
        scenarios_repository: ScenariosRepository | None = None,
    ) -> None:
        self._intent = intent_agent or IntentAgent()
        self._query_planner = query_planner or QueryPlannerAgent()
        self._search = search_agent or SearchAgent()
        self._ranking = ranking_agent or RankingAgent()
        self._decision = decision_agent or DecisionAgent()
        self._gap_analysis = gap_analysis_agent or GapAnalysisAgent()
        self._conditioning = conditioning_agent or ConditioningAgent()
        self._synthesis = synthesis_agent or SynthesisAgent()
        self._validation = validation_agent or ValidationAgent()
        self._learning = learning_agent or LearningAgent()
        self._explanation = explanation_agent or ExplanationAgent()
        self._conditioning_executor = conditioning_executor or ConditioningExecutor()
        self._synthesis_executor = synthesis_executor or SynthesisExecutor()
        self._approvals = approval_service or get_approval_service()
        self._sessions = session_store or get_session_store()
        self._scenarios = scenarios_repository or ScenariosRepository()

    # ---- Steps 1-8: search, rank, decide ---------------------------------

    async def run_search_flow(self, natural_language: str, correlation_id: str | None = None) -> dict:
        request_id = str(uuid.uuid4())
        state = WorkflowState(
            request_id=request_id,
            natural_language=natural_language,
            correlation_id=correlation_id or str(uuid.uuid4()),
        )

        criteria, hard, soft = await self._intent.interpret(natural_language)
        state.normalized_criteria = criteria
        state.hard_constraints = hard
        state.soft_constraints = soft
        state.log_step("intent_interpreted")

        query_dsl = self._query_planner.build_query(criteria, natural_language)
        state.log_step("query_planned")

        candidates = await self._search.retrieve(query_dsl)
        state.log_step(f"search_retrieved:{len(candidates)}")

        ranked = await self._ranking.rank(criteria, candidates)
        state.log_step("ranked")

        action, recommendation = self._decision.decide(ranked)
        state.action = action.value
        state.log_step(f"decision:{action.value}")

        response: dict = {
            "request_id": request_id,
            "correlation_id": state.correlation_id,
            "action": action.value,
            "normalized_criteria": criteria.model_dump(),
            "hard_constraints": hard,
            "soft_constraints": soft,
            "recommendation": recommendation.model_dump() if recommendation else None,
            "trace": state.trace,
        }

        if action == ActionType.RETURN_MATCH and recommendation and recommendation.record_id:
            await self._store_outcome(state, action, {"_id": recommendation.record_id}, validation_passed=True)

        if action in (ActionType.CONDITION, ActionType.SYNTHESIZE) and ranked:
            best = ranked[0]
            state.best_candidate_record_id = best.candidate.record_id
            state.failed_constraints = best.failed

            gap = self._gap_analysis.explain(ranked)
            response["gap_analysis"] = gap

            plan = self._conditioning.propose_plan(best.candidate.record_id, criteria, best.failed)
            if plan is not None:
                approval = self._approvals.create_request(
                    action_type=ActionType.CONDITION,
                    target=request_id,
                    plan_summary=f"Condition {plan.source_record_id}: {plan.transformations}",
                )
                response["conditioning_plan"] = plan.model_dump()
                response["approval_id"] = approval.approval_id
                response["message"] = await self._explanation.explain_gap(
                    criteria, gap, best.candidate.raw_record, proposed_plan_kind="condition"
                )
                response["message"] += (
                    f" Approve via POST /v1/scenarios/{request_id}/approve-conditioning "
                    f"with approval_id={approval.approval_id}."
                )
            else:
                synth_plan = self._synthesis.propose_plan(criteria)
                if synth_plan is not None:
                    approval = self._approvals.create_request(
                        action_type=ActionType.SYNTHESIZE,
                        target=request_id,
                        plan_summary=f"Synthesize from template {synth_plan.template_id}",
                    )
                    response["synthesis_plan"] = synth_plan.model_dump()
                    response["approval_id"] = approval.approval_id
                    response["message"] = await self._explanation.explain_gap(
                        criteria, gap, best.candidate.raw_record, proposed_plan_kind="synthesize"
                    )
                    response["message"] += (
                        f" Approve via POST /v1/scenarios/{request_id}/approve-synthesis "
                        f"with approval_id={approval.approval_id}."
                    )
                else:
                    response["action"] = ActionType.UNFULFILLABLE.value
                    response["message"] = await self._explanation.explain_gap(criteria, gap, best.candidate.raw_record, proposed_plan_kind=None)

        if action == ActionType.CLARIFY:
            response["message"] = "No candidates could be retrieved; please refine the request."

        self._sessions.save(state)
        logger.info("search_flow_complete", extra={"correlation_id": state.correlation_id, "action": response["action"]})
        return response

    # ---- Steps 9-10: conditioning approval + execution --------------------

    async def execute_conditioning(self, request_id: str, approval_id: str, approved: bool) -> dict:
        state = self._require_session(request_id)
        approval = self._approvals.decide(approval_id, approved)
        if approval is None:
            raise OrchestratorError("Approval not found")
        if approval.status != ApprovalStatus.APPROVED:
            return {"status": approval.status.value, "message": "Conditioning not executed."}

        if state.normalized_criteria is None or state.best_candidate_record_id is None:
            raise OrchestratorError("No conditionable candidate in session")

        plan = self._conditioning.propose_plan(
            state.best_candidate_record_id, state.normalized_criteria, state.failed_constraints
        )
        if plan is None:
            raise OrchestratorError("No approved transformation covers the failed constraints")

        result_record = await self._conditioning_executor.execute(plan)
        state.log_step("conditioning_executed")

        validation_passed = self._validation.validate(state.normalized_criteria, result_record)
        state.log_step(f"validated:{validation_passed}")

        await self._store_outcome(state, ActionType.CONDITION, result_record, validation_passed)

        return {
            "status": "executed",
            "validation_passed": validation_passed,
            "result_record": result_record,
            "trace": state.trace,
        }

    # ---- Steps 11-12: synthesis approval + execution -----------------------

    async def execute_synthesis(self, request_id: str, approval_id: str, approved: bool) -> dict:
        state = self._require_session(request_id)
        approval = self._approvals.decide(approval_id, approved)
        if approval is None:
            raise OrchestratorError("Approval not found")
        if approval.status != ApprovalStatus.APPROVED:
            return {"status": approval.status.value, "message": "Synthesis not executed."}

        if state.normalized_criteria is None:
            raise OrchestratorError("No normalized criteria in session")

        plan = self._synthesis.propose_plan(state.normalized_criteria)
        if plan is None:
            raise OrchestratorError("No approved template covers this scenario")

        result_record = await self._synthesis_executor.execute(plan)
        state.log_step("synthesis_executed")

        validation_passed = self._validation.validate(state.normalized_criteria, result_record)
        state.log_step(f"validated:{validation_passed}")

        await self._store_outcome(state, ActionType.SYNTHESIZE, result_record, validation_passed)

        return {
            "status": "executed",
            "validation_passed": validation_passed,
            "result_record": result_record,
            "trace": state.trace,
        }

    # ---- Step 13: persist + learn ------------------------------------------

    async def _store_outcome(self, state: WorkflowState, action: ActionType, result: dict, validation_passed: bool | None) -> None:
        scenario_request = ScenarioRequest(
            request_id=state.request_id,
            natural_language=state.natural_language,
            normalized_criteria=state.normalized_criteria,
            hard_constraints=state.hard_constraints,
            soft_constraints=state.soft_constraints,
        )
        outcome = ScenarioOutcome(
            request=scenario_request,
            selected_action=action,
            result=result,
            validation_passed=validation_passed,
        )
        self._scenarios.save(state.request_id, outcome)
        await self._learning.record_outcome(outcome)
        state.log_step("outcome_stored")

    def _require_session(self, request_id: str) -> WorkflowState:
        state = self._sessions.get(request_id)
        if state is None:
            raise OrchestratorError("Unknown or expired request_id; re-run search")
        return state


_orchestrator: Orchestrator | None = None


def get_orchestrator() -> Orchestrator:
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = Orchestrator()
    return _orchestrator
