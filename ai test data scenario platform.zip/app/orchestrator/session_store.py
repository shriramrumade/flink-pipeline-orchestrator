"""
Holds in-flight WorkflowState between the initial /search call and a later
/approve-conditioning or /approve-synthesis call. In-memory for Phase 1-6;
swap for Redis (already in the tech-choices list, section 16) once multiple
API instances need to share state.
"""
from app.orchestrator.state import WorkflowState

_SESSIONS: dict[str, WorkflowState] = {}


class SessionStore:
    def save(self, state: WorkflowState) -> None:
        _SESSIONS[state.request_id] = state

    def get(self, request_id: str) -> WorkflowState | None:
        return _SESSIONS.get(request_id)


_store: SessionStore | None = None


def get_session_store() -> SessionStore:
    global _store
    if _store is None:
        _store = SessionStore()
    return _store
