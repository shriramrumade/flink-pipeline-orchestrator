"""Lightweight per-request workflow state passed between orchestrator steps."""
from dataclasses import dataclass, field
from typing import Any

from app.domain.models.contracts import NormalizedCriteria


@dataclass
class WorkflowState:
    request_id: str
    natural_language: str
    correlation_id: str
    normalized_criteria: NormalizedCriteria | None = None
    hard_constraints: list[str] = field(default_factory=list)
    soft_constraints: list[str] = field(default_factory=list)
    trace: list[str] = field(default_factory=list)
    best_candidate_record_id: str | None = None
    failed_constraints: list[str] = field(default_factory=list)
    action: str | None = None

    def log_step(self, step: str) -> None:
        self.trace.append(step)
