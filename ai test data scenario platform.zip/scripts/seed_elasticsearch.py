"""
Seeds Elasticsearch with test-card records for the AI Test Data Scenario
Platform. Two things get created:

1. The index, with a mapping that matches exactly what the platform's agents
   query against (see app/agents/query_planner/agent.py: issuer.keyword,
   product_family.keyword, status.keyword, annual_fee/available_credit
   ranges, and a free-text `description` field for BM25).

2. Documents:
   - A small set of hand-authored "golden" records with fixed IDs
     (card-1001, card-1002, ...) that match evaluation/datasets/golden_dataset.json,
     so the evaluation harness has real data to hit.
   - N synthetic records generated deterministically (seeded RNG) so runs are
     reproducible, spanning a spread of issuers/fees/credit so ranking and
     conditioning have realistic near-misses to work with.

No third-party data-gen library required (dependency-free by design). Uses
the same `elasticsearch` client already in requirements.txt.

Usage:
    python scripts/seed_elasticsearch.py --count 200
    python scripts/seed_elasticsearch.py --count 200 --recreate
    python scripts/seed_elasticsearch.py --url http://localhost:9200 --index test_cards
"""
import argparse
import asyncio
import json
import random
import uuid
from datetime import datetime, timedelta
from pathlib import Path

from elasticsearch import AsyncElasticsearch
from elasticsearch.helpers import async_bulk

MAPPING_PATH = Path(__file__).parent / "index_mapping.json"

ISSUERS = ["Chase", "Amex", "Citi", "Capital One", "Bank of America", "Wells Fargo", "Discover"]
PRODUCT_FAMILIES = {
    "Chase": ["Sapphire", "Freedom", "Ink Business"],
    "Amex": ["Platinum", "Gold", "Blue Cash"],
    "Citi": ["Double Cash", "Premier", "Simplicity"],
    "Capital One": ["Venture", "Quicksilver", "Savor"],
    "Bank of America": ["Travel Rewards", "Customized Cash", "Premium Rewards"],
    "Wells Fargo": ["Active Cash", "Autograph", "Reflect"],
    "Discover": ["it Cash Back", "it Miles", "it Student"],
}
STATUSES = ["active", "active", "active", "suspended", "closed"]  # weighted toward active

# Hand-authored golden records - IDs referenced directly by
# evaluation/datasets/golden_dataset.json. Keep these in sync if you edit
# the golden dataset's expected_record_ids.
GOLDEN_RECORDS = [
    {
        "_id": "card-1001",
        "issuer": "Chase",
        "product_family": "Sapphire",
        "travel_rewards": True,
        "annual_fee": 95.0,
        "available_credit": 6500.0,
        "credit_limit": 10000.0,
        "status": "active",
        "card_number_last4": "4242",
        "description": "Chase Sapphire travel rewards card, well-qualified test account.",
        "tags": ["golden", "travel"],
    },
    {
        "_id": "card-1002",
        "issuer": "Chase",
        "product_family": "Sapphire",
        "travel_rewards": True,
        "annual_fee": 550.0,
        "available_credit": 5200.0,
        "credit_limit": 15000.0,
        "status": "active",
        "card_number_last4": "8765",
        "description": "Chase Sapphire Reserve, higher annual fee variant.",
        "tags": ["golden", "travel"],
    },
    {
        "_id": "card-1003",
        "issuer": "Chase",
        "product_family": "Sapphire",
        "travel_rewards": True,
        "annual_fee": 95.0,
        "available_credit": 1200.0,
        "credit_limit": 10000.0,
        "status": "active",
        "card_number_last4": "1111",
        "description": "Chase Sapphire card with low available credit - useful conditioning-flow fixture.",
        "tags": ["golden", "conditionable"],
    },
]


def _generate_synthetic_record(rng: random.Random) -> dict:
    issuer = rng.choice(ISSUERS)
    product_family = rng.choice(PRODUCT_FAMILIES[issuer])
    travel_rewards = rng.random() < 0.4
    annual_fee = rng.choice([0.0, 0.0, 95.0, 195.0, 250.0, 395.0, 550.0, 695.0])
    available_credit = round(rng.uniform(100, 20000), 2)
    credit_limit = round(available_credit + rng.uniform(0, 10000), 2)
    status = rng.choice(STATUSES)
    created_at = datetime.utcnow() - timedelta(days=rng.randint(0, 900))

    return {
        "_id": f"card-{uuid.uuid4().hex[:10]}",
        "issuer": issuer,
        "product_family": product_family,
        "travel_rewards": travel_rewards,
        "annual_fee": annual_fee,
        "available_credit": available_credit,
        "credit_limit": credit_limit,
        "status": status,
        "card_number_last4": f"{rng.randint(0, 9999):04d}",
        "description": (
            f"{issuer} {product_family} test card"
            f"{' with travel rewards' if travel_rewards else ''}, "
            f"annual fee ${annual_fee:.0f}, status {status}."
        ),
        "tags": ["synthetic"] + (["travel"] if travel_rewards else []),
        "created_at": created_at.isoformat(),
        "updated_at": created_at.isoformat(),
    }


async def seed(url: str, index: str, count: int, recreate: bool, seed_value: int) -> None:
    client = AsyncElasticsearch(url)
    rng = random.Random(seed_value)

    try:
        exists = await client.indices.exists(index=index)
        if exists and recreate:
            print(f"Deleting existing index '{index}'...")
            await client.indices.delete(index=index)
            exists = False

        if not exists:
            mapping = json.loads(MAPPING_PATH.read_text())
            print(f"Creating index '{index}' with mapping from {MAPPING_PATH.name}...")
            await client.indices.create(index=index, body=mapping)
        else:
            print(f"Index '{index}' already exists; reusing it (pass --recreate to reset).")

        records = list(GOLDEN_RECORDS) + [_generate_synthetic_record(rng) for _ in range(count)]

        actions = [
            {
                "_index": index,
                "_id": record["_id"],
                "_source": {k: v for k, v in record.items() if k != "_id"},
            }
            for record in records
        ]

        print(f"Indexing {len(actions)} records ({len(GOLDEN_RECORDS)} golden + {count} synthetic)...")
        success, errors = await async_bulk(client, actions, raise_on_error=False)
        print(f"Indexed: {success} succeeded, {len(errors) if errors else 0} failed.")
        if errors:
            for err in errors[:5]:
                print("  -", err)

        await client.indices.refresh(index=index)
        count_response = await client.count(index=index)
        print(f"Total documents in '{index}': {count_response['count']}")

    finally:
        await client.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Seed Elasticsearch with test-card data.")
    parser.add_argument("--url", default="http://localhost:9200", help="Elasticsearch URL")
    parser.add_argument("--index", default="test_cards", help="Index name (must match ELASTICSEARCH_INDEX in .env)")
    parser.add_argument("--count", type=int, default=100, help="Number of synthetic records to generate")
    parser.add_argument("--recreate", action="store_true", help="Drop and recreate the index first")
    parser.add_argument("--seed", type=int, default=42, help="RNG seed for reproducible synthetic data")
    args = parser.parse_args()

    asyncio.run(seed(args.url, args.index, args.count, args.recreate, args.seed))


if __name__ == "__main__":
    main()
