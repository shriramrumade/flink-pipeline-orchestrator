"""
Exercises the full orchestrator flow with stub Llama/Elasticsearch clients:
search -> decision -> conditioning approval -> execution -> validation ->
learning. No real network/services required.
"""
import pytest

from app.agents.conditioning.agent import ConditioningAgent
from app.agents.decision.agent import DecisionAgent
from app.agents.explanation.agent import ExplanationAgent
from app.agents.gap_analysis.agent import GapAnalysisAgent
from app.agents.intent.agent import IntentAgent
from app.agents.learning.agent import LearningAgent
from app.agents.query_planner.agent import QueryPlannerAgent
from app.agents.ranking.agent import RankingAgent
from app.agents.search.agent import SearchAgent
from app.agents.synthesis.agent import SynthesisAgent
from app.agents.validation.agent import ValidationAgent
from app.domain.models.contracts import NormalizedCriteria
from app.orchestrator.session_store import SessionStore
from app.orchestrator.workflow import Orchestrator
from app.repositories.scenarios import ScenariosRepository
from app.services.approval.service import ApprovalService
from app.services.execution.conditioning_executor import ConditioningExecutor
from app.services.vector_store.client import VectorStoreService


class StubIntentAgent(IntentAgent):
    def __init__(self):  # noqa: super not needed, avoids real Llama client
        pass

    async def interpret(self, natural_language: str):
        criteria = NormalizedCriteria(issuer="Chase", available_credit_min=5000)
        return criteria, ["issuer", "available_credit_min"], []


class StubEsService:
    """Minimal in-memory ES stand-in: one under-qualifying candidate."""

    def __init__(self):
        self._records = {"card-1": {"issuer": "Chase", "available_credit": 1000, "_id": "card-1"}}

    async def search(self, query_dsl, size=25):
        return [dict(r, _score=5.0) for r in self._records.values()]

    async def update_record(self, record_id, partial_doc):
        self._records[record_id].update(partial_doc)
        return self._records[record_id]


class StubSearchAgent(SearchAgent):
    def __init__(self, es):
        self._es = es


class StubExplanationAgent(ExplanationAgent):
    def __init__(self):  # noqa: avoids real LlamaClient construction
        pass

    async def explain_gap(self, criteria, gap_analysis, candidate_summary=None, proposed_plan_kind=None):
        return "Stubbed explanation for test."


@pytest.mark.asyncio
async def test_conditioning_flow_executes_and_validates():
    es = StubEsService()
    orchestrator = Orchestrator(
        intent_agent=StubIntentAgent(),
        query_planner=QueryPlannerAgent(),
        search_agent=StubSearchAgent(es),
        ranking_agent=RankingAgent(vector_store=VectorStoreService()),
        decision_agent=DecisionAgent(),
        gap_analysis_agent=GapAnalysisAgent(),
        conditioning_agent=ConditioningAgent(),
        synthesis_agent=SynthesisAgent(),
        validation_agent=ValidationAgent(),
        learning_agent=LearningAgent(vector_store=VectorStoreService()),
        explanation_agent=StubExplanationAgent(),
        conditioning_executor=ConditioningExecutor(es_service=es),
        approval_service=ApprovalService(),
        session_store=SessionStore(),
        scenarios_repository=ScenariosRepository(),
    )

    search_response = await orchestrator.run_search_flow("Chase card with available credit above 5000")
    assert search_response["action"] == "condition"
    assert "approval_id" in search_response

    result = await orchestrator.execute_conditioning(
        search_response["request_id"], search_response["approval_id"], approved=True
    )

    assert result["status"] == "executed"
    assert result["validation_passed"] is True
    assert result["result_record"]["available_credit"] == 5000
