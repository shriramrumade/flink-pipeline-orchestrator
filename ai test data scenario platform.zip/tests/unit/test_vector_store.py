import pytest

from app.services.vector_store.client import VectorStoreService, embed_normalized_criteria, cosine_similarity


def test_embedding_is_deterministic():
    criteria = {"issuer": "Chase", "available_credit_min": 5000}
    v1 = embed_normalized_criteria(criteria)
    v2 = embed_normalized_criteria(criteria)
    assert v1 == v2


def test_similar_criteria_score_higher_than_dissimilar():
    base = embed_normalized_criteria({"issuer": "Chase", "available_credit_min": 5000})
    similar = embed_normalized_criteria({"issuer": "Chase", "available_credit_min": 5000, "card_status": "active"})
    different = embed_normalized_criteria({"issuer": "Amex", "available_credit_min": 100})

    assert cosine_similarity(base, similar) > cosine_similarity(base, different)


@pytest.mark.asyncio
async def test_upsert_and_query_round_trip():
    store = VectorStoreService()
    criteria = {"issuer": "Chase", "product_family": "Sapphire", "available_credit_min": 5000}
    await store.upsert_scenario("scenario-1", criteria, {"record_id": "card-1001", "action": "return_match"})

    results = await store.similar_scenarios(criteria, top_k=3, min_similarity=0.0)
    assert results
    assert results[0]["record_id"] == "card-1001"
