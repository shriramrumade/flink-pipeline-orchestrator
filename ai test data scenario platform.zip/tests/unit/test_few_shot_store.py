from app.services.vector_store.few_shot_store import FewShotExampleStore


def test_skips_empty_parses():
    store = FewShotExampleStore()
    store.add_example("gibberish request", {"issuer": None, "product_family": None})
    assert store.size() == 0


def test_retrieves_similar_example_by_text():
    store = FewShotExampleStore()
    store.add_example(
        "Find a Chase Sapphire card with travel rewards, annual fee below 600",
        {"issuer": "Chase", "product_family": "Sapphire", "travel_rewards": True, "annual_fee_max": 600},
    )
    store.add_example(
        "I need a Discover card with no annual fee",
        {"issuer": "Discover", "annual_fee_max": 0},
    )

    results = store.retrieve_similar("Looking for a Chase Sapphire travel card", top_k=1)
    assert len(results) == 1
    assert results[0].normalized_criteria["issuer"] == "Chase"


def test_returns_empty_on_cold_store():
    store = FewShotExampleStore()
    assert store.retrieve_similar("anything") == []
