import pytest

from app.agents.explanation.agent import ExplanationAgent, _sanitize_record
from app.domain.models.contracts import NormalizedCriteria


class StubLlamaClient:
    async def generate_text(self, system_prompt, user_prompt):
        return "Stubbed explanation."


class FailingLlamaClient:
    async def generate_text(self, system_prompt, user_prompt):
        raise RuntimeError("llama unreachable")


def test_sanitize_record_strips_sensitive_fields():
    raw = {"issuer": "Chase", "available_credit": 1000, "card_number_last4": "4242", "_id": "card-1"}
    sanitized = _sanitize_record(raw)
    assert "card_number_last4" not in sanitized
    assert "_id" not in sanitized
    assert sanitized["issuer"] == "Chase"


@pytest.mark.asyncio
async def test_uses_llm_output_when_available():
    agent = ExplanationAgent(llama_client=StubLlamaClient())
    criteria = NormalizedCriteria(available_credit_min=5000)
    text = await agent.explain_gap(criteria, {"failed_constraints": ["available_credit_min"]}, {"issuer": "Chase"}, "condition")
    assert text == "Stubbed explanation."


@pytest.mark.asyncio
async def test_falls_back_when_llm_fails():
    agent = ExplanationAgent(llama_client=FailingLlamaClient())
    criteria = NormalizedCriteria(available_credit_min=5000)
    text = await agent.explain_gap(criteria, {"failed_constraints": ["available_credit_min"]}, {"issuer": "Chase"}, "condition")
    assert "available_credit_min" in text
    assert "approval" in text.lower()
