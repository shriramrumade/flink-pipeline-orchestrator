from app.agents.conditioning.agent import ConditioningAgent
from app.domain.models.contracts import NormalizedCriteria


def test_proposes_plan_for_allowed_constraint():
    agent = ConditioningAgent()
    criteria = NormalizedCriteria(available_credit_min=5000)
    plan = agent.propose_plan("card-1", criteria, ["available_credit_min"])

    assert plan is not None
    assert plan.source_record_id == "card-1"
    assert plan.expected_postconditions["available_credit"] == 5000


def test_refuses_plan_for_disallowed_constraint():
    agent = ConditioningAgent()
    criteria = NormalizedCriteria(issuer="Chase")
    plan = agent.propose_plan("card-1", criteria, ["issuer"])

    assert plan is None
