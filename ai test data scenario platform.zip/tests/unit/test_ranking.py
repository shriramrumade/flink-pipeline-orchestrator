import pytest

from app.agents.ranking.agent import RankingAgent
from app.domain.models.contracts import NormalizedCriteria, SearchCandidate


class _StubVectorStore:
    async def similar_scenarios(self, normalized_criteria, top_k=5):
        return []


@pytest.mark.asyncio
async def test_ranking_orders_exact_match_first():
    agent = RankingAgent(vector_store=_StubVectorStore())
    criteria = NormalizedCriteria(available_credit_min=5000)

    good = SearchCandidate(record_id="good", lexical_score=10.0, raw_record={"available_credit": 6000})
    bad = SearchCandidate(record_id="bad", lexical_score=10.0, raw_record={"available_credit": 1000})

    ranked = await agent.rank(criteria, [bad, good])

    assert ranked[0].candidate.record_id == "good"
    assert ranked[0].score > ranked[1].score
