from app.agents.query_planner.agent import QueryPlannerAgent
from app.domain.models.contracts import NormalizedCriteria


def test_query_planner_builds_filters():
    planner = QueryPlannerAgent()
    criteria = NormalizedCriteria(issuer="Chase", annual_fee_max=600, available_credit_min=5000)
    dsl = planner.build_query(criteria, "travel rewards card")

    filters = dsl["query"]["bool"]["filter"]
    assert {"term": {"issuer.keyword": "Chase"}} in filters
    assert any("annual_fee" in f.get("range", {}) for f in filters)
    assert any("available_credit" in f.get("range", {}) for f in filters)
