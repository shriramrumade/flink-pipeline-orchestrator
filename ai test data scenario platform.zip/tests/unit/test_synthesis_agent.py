from app.agents.synthesis.agent import SynthesisAgent
from app.domain.models.contracts import NormalizedCriteria


def test_matches_known_template():
    agent = SynthesisAgent()
    criteria = NormalizedCriteria(issuer="Chase", product_family="Sapphire", available_credit_min=6000)
    plan = agent.propose_plan(criteria)

    assert plan is not None
    assert plan.template_id == "chase_sapphire_travel_v1"
    assert plan.attributes["available_credit"] >= 6000


def test_falls_back_to_generic_template():
    agent = SynthesisAgent()
    criteria = NormalizedCriteria(annual_fee_max=0)
    plan = agent.propose_plan(criteria)

    assert plan is not None
    assert plan.template_id == "generic_no_annual_fee_v1"
