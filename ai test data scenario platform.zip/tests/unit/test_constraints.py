from app.domain.models.contracts import NormalizedCriteria, SearchCandidate
from app.domain.rules.constraints import hard_constraints_satisfied


def test_all_constraints_satisfied():
    criteria = NormalizedCriteria(issuer="Chase", annual_fee_max=600, available_credit_min=5000)
    candidate = SearchCandidate(
        record_id="1",
        raw_record={"issuer": "Chase", "annual_fee": 550, "available_credit": 6000},
    )
    ok, satisfied, failed = hard_constraints_satisfied(criteria, candidate)
    assert ok is True
    assert failed == []
    assert set(satisfied) == {"issuer", "annual_fee_max", "available_credit_min"}


def test_hard_constraint_failure_is_reported():
    criteria = NormalizedCriteria(available_credit_min=5000)
    candidate = SearchCandidate(record_id="2", raw_record={"available_credit": 1000})
    ok, satisfied, failed = hard_constraints_satisfied(criteria, candidate)
    assert ok is False
    assert failed == ["available_credit_min"]
