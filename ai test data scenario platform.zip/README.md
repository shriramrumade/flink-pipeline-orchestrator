# AI Test Data Scenario Platform — Complete Reference Implementation

Fully wired FastAPI service implementing the entire end-to-end decision flow
from doc section 6 (steps 1–13): natural-language search, ranking, exact
match, conditioning, synthesis, validation, and learning — with every
state-changing action gated behind explicit approval (section 20).

## What's implemented end-to-end
- **Foundation**: FastAPI app, config, structured logging, API-key auth (`app/core`)
- **Domain contracts** from section 15 (`app/domain/models/contracts.py`)
- **Deterministic hard-constraint rules** (`app/domain/rules/constraints.py`)
- **Llama adapter** — intent interpretation only, no sensitive data sent (`app/services/llama`)
- **Elasticsearch adapter** — read (search) and gated write (`update_record`, `index_document`) (`app/services/elasticsearch`)
- **Vector Store / Scenario Memory** — deterministic feature-hash embeddings + cosine similarity, dependency-free and swappable for pgvector/Pinecone/ES-kNN (`app/services/vector_store`)
- **Agents**: Intent (RAG few-shot), Query Planner, Search, Ranking, Decision, Gap Analysis, Explanation (RAG), Conditioning, Synthesis, Validation, Learning — all fully implemented, not stubs
- **Approved-transformation policy** and **approved synthesis templates** (`app/domain/policies`) — the safety boundary conditioning/synthesis must pass
- **Executors** that apply approved plans to Elasticsearch (`app/services/execution`)
- **Orchestrator** implementing the complete section-6 flow: search → rank → decide → (conditioning approval → execute → validate) or (synthesis approval → execute → validate) → store outcome → update Scenario Memory
- **Session store** so a scenario's state survives between the initial search call and a later approval call
- **Full API surface** from section 17: search, approve-conditioning, approve-synthesis, get scenario, get approval, feedback (persists to the scenario outcome), health
- **Evaluation harness** (section 18): golden dataset, Recall@K/Precision@K/MRR/exact-match/condition-success/synthesis-success/false-positive/validation-failure metrics, and a runnable `evaluation/run_evaluation.py`
- **Unit + integration tests**, including a full end-to-end orchestrator test (search → approve → execute → validate) using in-memory stubs, no external services required

## Deliberately still a stub (Phase 7, infra-only)
- Persistence is in-memory (scenarios, approvals, session store) — swap for PostgreSQL per section 16 when moving past a single instance
- Feedback is written synchronously — swap for Kafka publish/consume per section 16 at scale
- Auth is a single static API key — swap for OAuth2/JWT
- No Kubernetes manifests (docker-compose only)

These are infrastructure swaps behind existing interfaces, not missing logic —
every agent, policy check, executor, and the full decision flow are real and
tested.

## Run locally

```bash
cp .env.example .env
pip install -r requirements.txt
docker compose up elasticsearch -d   # or point ELASTICSEARCH_URL at an existing cluster
python scripts/seed_elasticsearch.py --count 200 --recreate   # load test data - see "Seeding test data" below
uvicorn app.main:app --reload
```

Point `LLAMA_BASE_URL` in `.env` at your self-hosted Llama deployment
(default assumes an Ollama-compatible `/api/generate` endpoint — swap
`app/services/llama/client.py`'s transport if you're serving via vLLM/TGI).

## Seeding test data

`scripts/seed_elasticsearch.py` creates the index (from `scripts/index_mapping.json`,
which matches exactly what `app/agents/query_planner/agent.py` filters on) and
loads two kinds of documents:

- **Golden records** (`card-1001`, `card-1002`, `card-1003`) with fixed IDs
  that match `evaluation/datasets/golden_dataset.json`, so the evaluation
  harness has real, known-good data to hit.
- **Synthetic records** — deterministically generated (seeded RNG, no
  third-party faker dependency) across issuers, product families, fee tiers,
  and available-credit ranges, so ranking/gap-analysis/conditioning have
  realistic near-misses to work with, not just exact matches.

```bash
# first run / reset
python scripts/seed_elasticsearch.py --count 200 --recreate

# add more data to an existing index without dropping it
python scripts/seed_elasticsearch.py --count 50

# point at a different cluster/index
python scripts/seed_elasticsearch.py --url http://localhost:9200 --index test_cards --count 200
```

To add your own fixed scenarios (e.g. to extend the golden dataset), add
entries to `GOLDEN_RECORDS` in `scripts/seed_elasticsearch.py` with explicit
`_id`s, then reference those IDs in `evaluation/datasets/golden_dataset.json`.

## Where RAG is actually used

Two components are genuine retrieval-augmented generation (retrieval feeds an
LLM *prompt*, not just ranking math):

1. **Intent Agent few-shot retrieval** (`app/services/vector_store/few_shot_store.py`,
   `app/services/vector_store/text_embedding.py`) — before parsing a new
   request, the Intent Agent retrieves the most similar past
   (request → parsed criteria) examples by text similarity and injects them
   into the LLM prompt as few-shot examples. Every successful parse is added
   back to the store, so parsing accuracy improves over time without any
   fine-tuning.
2. **Explanation Agent** (`app/agents/explanation/`) — after the deterministic
   Gap Analysis Agent computes which constraints failed, the Explanation
   Agent retrieves that structured result, sanitizes it down to a small
   allow-list of non-identifying fields, and asks the LLM to turn it into a
   short natural-language explanation for the tester. It sits outside the
   decision path entirely — the action was already chosen before this runs,
   and it has a deterministic fallback message if the LLM is unreachable, so
   an LLM outage degrades wording, never correctness.

Everything else that looks like retrieval — Scenario Memory / the vector
store used by `RankingAgent` — feeds deterministic scoring math, not a
prompt, and is intentionally not RAG (see doc section 13/20: the LLM is kept
out of the loop once structured criteria exist).

## Try it

```bash
# 1. Search
curl -X POST http://localhost:8000/v1/scenarios/search \
  -H "X-API-Key: change-me" -H "Content-Type: application/json" \
  -d '{"natural_language": "Find a Chase Sapphire card with travel rewards, annual fee below 600, and available credit above 5,000."}'
# -> if no exact match, response includes request_id + approval_id + a conditioning_plan or synthesis_plan

# 2. Approve conditioning (or approve-synthesis) using the IDs from step 1
curl -X POST http://localhost:8000/v1/scenarios/<request_id>/approve-conditioning \
  -H "X-API-Key: change-me" -H "Content-Type: application/json" \
  -d '{"approval_id": "<approval_id>", "approved": true}'
# -> executes the plan against Elasticsearch, validates the result, stores the outcome,
#    and updates Scenario Memory for future ranking

# 3. Send feedback
curl -X POST http://localhost:8000/v1/feedback \
  -H "X-API-Key: change-me" -H "Content-Type: application/json" \
  -d '{"request_id": "<request_id>", "outcome": "worked_as_expected"}'
```

## Tests

```bash
pytest                              # unit + integration (stubs, no external services needed)
python -m evaluation.run_evaluation # golden-dataset metrics (section 18)
```

## Diagrams
See `diagrams/architecture_diagram.mermaid`, `diagrams/component_diagram.mermaid`,
and `diagrams/workflow_diagram.mermaid` for the system, component, and
end-to-end decision-flow views (render at mermaid.live or any Mermaid-aware viewer).
