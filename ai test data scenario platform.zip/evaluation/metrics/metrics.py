"""
Evaluation metrics (doc section 18): Recall@K, Precision@K, MRR,
exact-match rate, condition-success rate, synthesis-success rate,
false-positive rate, validation-failure rate.

Each function takes simple, framework-agnostic inputs so it can be reused
from a notebook, a CLI script, or a CI job.
"""
from dataclasses import dataclass


@dataclass
class EvalCase:
    expected_record_ids: list[str]
    retrieved_record_ids: list[str]  # ranked, best first
    expected_action: str
    actual_action: str
    validation_passed: bool | None = None


def recall_at_k(case: EvalCase, k: int) -> float:
    if not case.expected_record_ids:
        return 1.0 if not set(case.retrieved_record_ids[:k]) & set(case.expected_record_ids) else 1.0
    hits = set(case.retrieved_record_ids[:k]) & set(case.expected_record_ids)
    return len(hits) / len(case.expected_record_ids)


def precision_at_k(case: EvalCase, k: int) -> float:
    top_k = case.retrieved_record_ids[:k]
    if not top_k:
        return 0.0
    hits = set(top_k) & set(case.expected_record_ids)
    return len(hits) / len(top_k)


def reciprocal_rank(case: EvalCase) -> float:
    for i, record_id in enumerate(case.retrieved_record_ids, start=1):
        if record_id in case.expected_record_ids:
            return 1.0 / i
    return 0.0


def mean_reciprocal_rank(cases: list[EvalCase]) -> float:
    if not cases:
        return 0.0
    return sum(reciprocal_rank(c) for c in cases) / len(cases)


def exact_match_rate(cases: list[EvalCase]) -> float:
    if not cases:
        return 0.0
    exact = [c for c in cases if c.expected_action == "return_match"]
    if not exact:
        return 0.0
    correct = sum(1 for c in exact if c.actual_action == "return_match")
    return correct / len(exact)


def condition_success_rate(cases: list[EvalCase]) -> float:
    attempted = [c for c in cases if c.actual_action == "condition"]
    if not attempted:
        return 0.0
    return sum(1 for c in attempted if c.validation_passed) / len(attempted)


def synthesis_success_rate(cases: list[EvalCase]) -> float:
    attempted = [c for c in cases if c.actual_action == "synthesize"]
    if not attempted:
        return 0.0
    return sum(1 for c in attempted if c.validation_passed) / len(attempted)


def false_positive_rate(cases: list[EvalCase]) -> float:
    """Cases returned as an exact match but the record wasn't actually
    in the expected/acceptable set."""
    returned = [c for c in cases if c.actual_action == "return_match"]
    if not returned:
        return 0.0
    false_positives = sum(
        1 for c in returned
        if not (set(c.retrieved_record_ids[:1]) & set(c.expected_record_ids))
    )
    return false_positives / len(returned)


def validation_failure_rate(cases: list[EvalCase]) -> float:
    validated = [c for c in cases if c.validation_passed is not None]
    if not validated:
        return 0.0
    return sum(1 for c in validated if not c.validation_passed) / len(validated)


def summarize(cases: list[EvalCase], k: int = 5) -> dict:
    return {
        "recall_at_k": sum(recall_at_k(c, k) for c in cases) / len(cases) if cases else 0.0,
        "precision_at_k": sum(precision_at_k(c, k) for c in cases) / len(cases) if cases else 0.0,
        "mrr": mean_reciprocal_rank(cases),
        "exact_match_rate": exact_match_rate(cases),
        "condition_success_rate": condition_success_rate(cases),
        "synthesis_success_rate": synthesis_success_rate(cases),
        "false_positive_rate": false_positive_rate(cases),
        "validation_failure_rate": validation_failure_rate(cases),
    }
