"""
CLI entrypoint for section 18: "Run evaluation on every prompt/model/ranking
change." Loads the golden dataset, runs each prompt through the Orchestrator,
and prints the summary metrics.

Usage:
    python -m evaluation.run_evaluation
"""
import asyncio
import json
from pathlib import Path

from app.orchestrator.workflow import Orchestrator
from evaluation.metrics.metrics import EvalCase, summarize

DATASET_PATH = Path(__file__).parent / "datasets" / "golden_dataset.json"


async def run() -> None:
    dataset = json.loads(DATASET_PATH.read_text())
    orchestrator = Orchestrator()
    cases: list[EvalCase] = []

    for row in dataset:
        response = await orchestrator.run_search_flow(row["prompt"])
        recommendation = response.get("recommendation") or {}
        retrieved = [recommendation["record_id"]] if recommendation.get("record_id") else []

        cases.append(
            EvalCase(
                expected_record_ids=row["expected_record_ids"],
                retrieved_record_ids=retrieved,
                expected_action=row["expected_fallback"],
                actual_action=response["action"],
                validation_passed=None,
            )
        )

    print(json.dumps(summarize(cases), indent=2))


if __name__ == "__main__":
    asyncio.run(run())
