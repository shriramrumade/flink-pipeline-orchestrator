from app.elastic_client import get_es


def reserve(cards, user):
    """
    Marks the given cards as reserved in Elasticsearch
    """

    es = get_es()

    reserved_cards = []

    for card in cards:
        card_id = card["card_id"]

        es.update(
            index="card_inventory",
            id=card_id,
            body={
                "doc": {
                    "reserved": True,
                    "reserved_by": user
                }
            }
        )

        reserved_cards.append(card)

    return reserved_cards