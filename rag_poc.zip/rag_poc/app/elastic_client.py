from elasticsearch import Elasticsearch

es = Elasticsearch("http://localhost:9200")
print(es)

def get_es():
    return es