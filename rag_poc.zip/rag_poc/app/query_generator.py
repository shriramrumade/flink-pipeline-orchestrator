import json
from app.llm_client import ask_llm

def generate_query(prompt, context):

    system_prompt = f"""
Context:
{context}

Convert request to JSON query.

Fields:
card_type
country
credit_limit_gt
count

User request:
{prompt}

Return JSON only.
"""

    response = ask_llm(system_prompt)

    try:
        return json.loads(response)
    except:
        return {
            "card_type":"visa",
            "country":"US",
            "credit_limit_gt":10000,
            "count":2
        }