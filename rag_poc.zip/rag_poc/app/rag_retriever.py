from app.elastic_client import get_es
from app.embedding import embed

def retrieve_context(prompt):

    es = get_es()

    vector = embed(prompt)

    query = {
        "knn": {
            "field": "embedding",
            "query_vector": vector,
            "k": 3,
            "num_candidates": 50
        }
    }

    res = es.search(index="rag_knowledge", body=query)

    return [hit["_source"]["text"] for hit in res["hits"]["hits"]]