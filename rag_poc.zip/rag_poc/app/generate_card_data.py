import random
import uuid
from datetime import datetime, timedelta
from elasticsearch import Elasticsearch, helpers
from faker import Faker
from tqdm import tqdm

fake = Faker()

es = Elasticsearch("http://localhost:9200")

INDEX = "card_inventory"

issuers = [
    "Chase",
    "Bank of America",
    "Citi",
    "BMO",
    "Capital One",
    "Discover",
    "Wells Fargo"
]

card_types = [
    "credit",
    "debit",
    "business",
    "premium"
]

networks = [
    "Visa",
    "Mastercard",
    "Amex"
]

merchant_categories = [
    "Retail",
    "Travel",
    "Food",
    "Electronics",
    "Healthcare",
    "Entertainment"
]

def generate_record():

    credit_limit = random.randint(2000, 50000)
    balance = random.randint(0, credit_limit)

    return {
        "card_id": str(uuid.uuid4()),
        "card_number": fake.credit_card_number(),
        "card_type": random.choice(card_types),
        "issuer": random.choice(issuers),
        "network": random.choice(networks),

        "customer_id": str(uuid.uuid4()),
        "customer_name": fake.name(),
        "email": fake.email(),
        "phone": fake.phone_number(),

        "address": fake.street_address(),
        "city": fake.city(),
        "state": fake.state(),
        "country": "USA",
        "zip_code": fake.zipcode(),

        "credit_limit": credit_limit,
        "available_credit": credit_limit - balance,
        "balance": balance,

        "apr": round(random.uniform(12, 30), 2),
        "cashback_percent": random.choice([1,2,3,5]),
        "annual_fee": random.choice([0,95,250]),

        "card_status": random.choice(["active","blocked","expired"]),

        "issue_date": fake.date_between(start_date="-5y"),
        "expiry_date": fake.date_between(start_date="+1y", end_date="+5y"),

        "last_transaction_date": fake.date_between(start_date="-30d"),
        "transaction_count": random.randint(0,500),

        "avg_transaction_amount": round(random.uniform(10,500),2),

        "risk_score": random.randint(1,100),
        "fraud_flag": random.choice([True, False]),
        "delinquent_flag": random.choice([True, False]),

        "payment_due": random.randint(50,2000),
        "payment_due_date": fake.date_between(start_date="today", end_date="+30d"),

        "min_payment": random.randint(20,200),

        "reward_points": random.randint(0,50000),
        "reward_program": random.choice(["cashback","travel","points"]),

        "customer_segment": random.choice(["mass","affluent","student","business"]),

        "income_band": random.choice(["low","medium","high"]),
        "employment_status": random.choice(["employed","self-employed","unemployed"]),

        "marital_status": random.choice(["single","married"]),
        "age": random.randint(21,70),
        "gender": random.choice(["male","female"]),

        "kyc_verified": random.choice([True,False]),
        "fraud_score": random.randint(1,100),

        "device_id": fake.uuid4(),
        "ip_address": fake.ipv4(),

        "merchant_category": random.choice(merchant_categories),

        "last_login": fake.date_time_this_year(),
        "login_count": random.randint(1,200),

        "reserved": False,
        "reserved_by": None,
        "reserved_time": None
    }

def generate_bulk(total=1000000, batch_size=5000):

    actions = []

    for i in tqdm(range(total)):

        doc = generate_record()

        actions.append({
            "_index": INDEX,
            "_source": doc
        })

        if len(actions) == batch_size:
            helpers.bulk(es, actions)
            actions = []

    if actions:
        helpers.bulk(es, actions)

    print("Finished inserting records")

if __name__ == "__main__":
    generate_bulk()