from app.elastic_client import get_es


def search_cards(query):

    es = get_es()

    es_query = {
        "size": query["count"],
        "query": {
            "bool": {
                "must": [
                    {"term": {"card_type": query["card_type"]}},
                    {"term": {"country": query["country"]}},
                    {"range": {"credit_limit": {"gt": query["credit_limit_gt"]}}}
                ],
                "filter": [
                    {"term": {"reserved": False}}
                ]
            }
        }
    }

    res = es.search(index="card_inventory", body=es_query)

    return [hit["_source"] for hit in res["hits"]["hits"]]