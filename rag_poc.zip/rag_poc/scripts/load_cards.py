from elasticsearch import Elasticsearch

es = Elasticsearch("http://localhost:9200")

cards = [
{"card_id":"1","card_type":"visa","country":"US","credit_limit":12000,"expiry":"2027-01-01","reserved":False},
{"card_id":"2","card_type":"visa","country":"US","credit_limit":15000,"expiry":"2027-01-01","reserved":False},
{"card_id":"3","card_type":"visa","country":"US","credit_limit":8000,"expiry":"2026-01-01","reserved":False},
{"card_id":"4","card_type":"mastercard","country":"US","credit_limit":20000,"expiry":"2027-01-01","reserved":False}
]

for c in cards:
    es.index(index="card_inventory", id=c["card_id"], document=c)

print("Cards loaded")