from elasticsearch import Elasticsearch
from app.embedding import embed

es = Elasticsearch("http://localhost:9200")

docs = [
 "High limit card means credit_limit greater than 10000",
 "Valid card types are visa mastercard and amex",
 "Maximum cards per request is 100",
 "Active cards must have expiry date in the future"
]

for d in docs:

    es.index(
        index="rag_knowledge",
        document={
            "text": d,
            "embedding": embed(d)
        }
    )

print("Knowledge loaded")