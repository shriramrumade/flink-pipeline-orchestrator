from elasticsearch import Elasticsearch

es = Elasticsearch("http://localhost:9200")

knowledge_index = {
 "mappings": {
  "properties": {
   "text": {"type": "text"},
   "embedding": {
     "type": "dense_vector",
     "dims": 384,
     "index": True,
     "similarity": "cosine"
   }
  }
 }
}

card_index = {
 "mappings": {
  "properties": {
   "card_id": {"type": "keyword"},
   "card_type": {"type": "keyword"},
   "country": {"type": "keyword"},
   "credit_limit": {"type": "integer"},
   "expiry": {"type": "date"},
   "reserved": {"type": "boolean"},
   "reserved_by": {"type": "keyword"}
  }
 }
}

es.indices.create(index="rag_knowledge", body=knowledge_index)
es.indices.create(index="card_inventory", body=card_index)

print("Indices created")