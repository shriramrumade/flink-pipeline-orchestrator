
# Advanced Local RAG System

Includes architecture diagram in docs/architecture_diagram.pptx

Run Steps:

1. docker compose up -d
2. pip install -r requirements.txt
3. python scripts/create_indices.py
4. python scripts/generate_card_data.py
5. python scripts/build_schema_graph.py
6. ollama serve
7. ollama pull llama3
8. uvicorn app.main:app --reload
