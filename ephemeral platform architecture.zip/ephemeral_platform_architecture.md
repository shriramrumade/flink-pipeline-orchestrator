# Enterprise Ephemeral Test Platform

## Architecture & Design Document

| | |
|---|---|
| **Version** | 1.0 — POC Edition |
| **Scope** | Short-lived ephemeral environments for integration testing |
| **Provider** | AWS (Spring Boot + PostgreSQL reference implementation) |
| **Audience** | Platform engineers and application team leads |

> **Document scope — Part 1 only**
> This document covers system architecture, functional layers, lifecycle flow, and the AWS stack reference implementation.
> The implementation guide (Part 2) is published separately.

---

## Table of Contents

- [1. Overview](#1-overview)
  - [1.1 Key Design Decisions](#11-key-design-decisions)
- [2. Ephemeral Lifecycle](#2-ephemeral-lifecycle)
  - [2.1 Architecture Diagram — Lifecycle](#21-architecture-diagram--lifecycle)
  - [2.2 Lifecycle Flowchart](#22-lifecycle-flowchart)
  - [2.3 Component Interaction Sequence](#23-component-interaction-sequence)
- [3. Functional Architecture](#3-functional-architecture)
  - [3.1 Architecture Diagram — Functional Layers](#31-architecture-diagram--functional-layers)
  - [3.2 Functional Layers — Mermaid](#32-functional-layers--mermaid)
  - [3.3 Provider Adapter Class Structure](#33-provider-adapter-class-structure)
  - [3.4 Layer Summary](#34-layer-summary)
  - [3.5 Platform Core Components](#35-platform-core-components)
- [4. Spring Boot + PostgreSQL on AWS](#4-spring-boot--postgresql-on-aws)
  - [4.1 Architecture Diagram — AWS Stack](#41-architecture-diagram--aws-stack)
  - [4.2 AWS Infrastructure per PR](#42-aws-infrastructure-per-pr)
  - [4.3 Environment Lifecycle State Machine](#43-environment-lifecycle-state-machine)
  - [4.4 AWS Resources per PR](#44-aws-resources-per-pr)

---

## 1. Overview

The ephemeral test platform creates a complete, isolated infrastructure stack when a pull request is opened, runs the application's integration test suite against real cloud services, and tears everything down when the PR closes or a TTL expires. **No infrastructure survives past the test run.**

Three core principles drive the design:

- **Any team, any stack** — a single `env.yaml` file is the only contract teams write.
- **Any cloud** — the same `ProviderAdapter` interface works on AWS, GCP, and on-prem Kubernetes.
- **Zero residual cost** — destroy always runs, even when tests fail.

> **POC scope**
> This document covers the core ephemeral lifecycle. The policy engine, self-service portal, and chargeback dashboard are post-POC extensions that plug into the same architecture without changes to the core.

---

### 1.1 Key Design Decisions

| Component | Description |
|---|---|
| **ProviderAdapter SPI** | Platform core has zero cloud SDK imports. All cloud operations go through one Java interface: `provision`, `seedData`, `runTests`, `destroy`. |
| **env.yaml contract** | Teams write one file. The platform reads, validates, and acts on it. No Terraform, no cloud SDK, no IAM knowledge required from application teams. |
| **Workspace isolation** | Every PR gets its own Terraform workspace (`pr-{number}`). All resource names are prefixed — zero collisions between concurrent PRs. |
| **Destroy guarantee** | CI uses `if: always()` on the destroy job. A TTL watchdog destroys stale stacks independently, catching anything the CI runner left behind. |
| **Idempotent seed** | Test data uses `INSERT ... ON CONFLICT DO NOTHING`. Safe to re-run on a retried job without duplicating rows. |

---

## 2. Ephemeral Lifecycle

The platform executes a four-stage linear lifecycle for every PR. Stages run in strict sequence. If any stage fails, destroy still runs unconditionally.

| Stage | Name | What happens |
|---|---|---|
| **1** | Trigger | PR opened/updated. GitHub Actions fires. CI reads `env.yaml`, runs `mvn package`, builds a Docker image, pushes to ECR tagged `pr-{number}`. |
| **2** | Provision | Terraform creates an isolated VPC with the application container, database, and object storage — all named with the `pr-{number}` prefix. Terraform outputs (endpoints, secret ARNs) are captured. |
| **3** | Test execution | Flyway migrations run first. The data loader pulls CSV files from S3 and bulk-inserts them. The test runner executes the JUnit suite with live endpoints injected as env vars. Results post to the PR check. |
| **4** | Destroy | `terraform destroy` removes every resource. Secrets Manager secret uses `recovery_window=0` for instant deletion. TTL watchdog fires independently after the configured timeout. |

---

### 2.1 Architecture Diagram — Lifecycle

> Detailed architecture diagram: full AWS resource layout, provisioning flow, test execution, and destroy sequence.

![Figure 1 — Architecture: Ephemeral lifecycle](img/fig1_architecture_lifecycle.svg)

*Figure 1 — Architecture: Ephemeral lifecycle (trigger → provision → test execution → destroy)*

---

### 2.2 Lifecycle Flowchart

```mermaid
flowchart TD
    A([PR opened / updated]) --> B[CI reads env.yaml]
    B --> C[mvn package + docker build]
    C --> D[Push image to ECR\ntagged pr-{number}]
    D --> E[terraform apply\nworkspace = pr-{number}]

    E --> F[(RDS PostgreSQL)]
    E --> G[ECS Fargate\nSpring Boot]
    E --> H[(S3 test-data bucket)]
    E --> I[(Secrets Manager)]

    F & G & H & I --> J[Flyway migrations]
    J --> K[Load CSV seed data\nS3 → RDS via COPY]
    K --> L[mvn test -Pintegration\nJUnit 5 + RestAssured]
    L --> M{Tests passed?}
    M -->|yes| N[Post results to PR check]
    M -->|no| N
    N --> O[terraform destroy\nif always]
    O --> P([All resources removed\nzero residual cost])

    style A fill:#EEEDFE,stroke:#534AB7
    style P fill:#E1F5EE,stroke:#0F6E56
    style O fill:#FCEBEB,stroke:#A32D2D
```

*Diagram 1 — Core lifecycle flowchart: PR trigger through provision, test execution, and guaranteed destroy*

---

### 2.3 Component Interaction Sequence

```mermaid
sequenceDiagram
    autonumber
    participant CI as GitHub Actions
    participant ORC as Orchestrator
    participant AWS as AwsProviderAdapter
    participant TF as Terraform
    participant RDS as RDS PostgreSQL
    participant S3 as S3 bucket

    CI->>ORC: run(EnvironmentSpec)
    ORC->>ORC: stateStore.save(PROVISIONING)
    ORC->>ORC: watchdog.register(ttl)
    ORC->>AWS: provision(spec)
    AWS->>TF: terraform apply workspace=pr-n
    TF-->>AWS: outputs (db_host, s3_bucket, app_endpoint)
    AWS-->>ORC: EnvironmentSpec with live endpoints

    ORC->>AWS: seedData(spec, testDataDir)
    AWS->>S3: upload CSV files
    AWS->>RDS: Flyway migrate
    AWS->>RDS: COPY from S3

    ORC->>AWS: runTests(spec)
    AWS->>CI: mvn test -Pintegration
    CI-->>AWS: TestResult (pass/fail)
    AWS-->>ORC: TestResult

    Note over ORC,AWS: always runs — even on failure
    ORC->>AWS: destroy(spec)
    AWS->>TF: terraform destroy workspace=pr-n
    TF-->>AWS: all resources removed
    ORC->>ORC: reporter.publish(result)
```

*Diagram 2 — Component interaction sequence: numbered call order between all actors*

---

## 3. Functional Architecture

The platform is structured in five layers. Each layer has a single responsibility and communicates downward only.

---

### 3.1 Architecture Diagram — Functional Layers

> Detailed architecture diagram: all five layers with every internal component named and connected.

![Figure 2 — Architecture: Five-layer functional platform structure](img/fig2_architecture_functional.svg)

*Figure 2 — Architecture: Five-layer functional platform structure*

---

### 3.2 Functional Layers — Mermaid

```mermaid
flowchart TB
    subgraph L1["Layer 1 — Consumer entry"]
        direction LR
        EY[env.yaml]
        CW[Reusable CI workflow]
        CLI[Platform CLI]
    end

    subgraph L2["Layer 2 — Platform core"]
        direction LR
        ORC[Orchestrator]
        CP[Config parser]
        SM[Secret manager]
        TTL[TTL watchdog]
    end

    subgraph L3["Layer 3 — Test execution"]
        direction LR
        MR[Migration runner]
        DL[Data loader]
        TR[Test runner]
        RP[Report publisher]
    end

    subgraph L4["Layer 4 — Infrastructure providers"]
        direction LR
        AWS[AWS provider]
        GCP[GCP provider]
        K8S[On-prem / K8s]
    end

    subgraph L5["Layer 5 — Shared long-lived infra"]
        direction LR
        SS[(State store)]
        CE[Cost engine]
        CR[Container registry]
        OB[Observability]
    end

    L1 --> L2 --> L3 --> L4 --> L5
```

*Diagram 3 — Functional architecture: five-layer structure with directional flow*

---

### 3.3 Provider Adapter Class Structure

```mermaid
classDiagram
    class ProviderAdapter {
        <<interface>>
        +name() String
        +provision(spec) EnvironmentSpec
        +seedData(spec, testDataDir) void
        +runTests(spec) TestResult
        +destroy(spec) void
    }

    class EnvironmentSpec {
        +envId String
        +team String
        +provider String
        +ttl Duration
        +dbHost String
        +dbSecretRef String
        +testDataBucket String
        +appEndpoint String
    }

    class TestResult {
        +passed int
        +failed int
        +duration Duration
        +reportUrl String
        +failed(Exception) TestResult$
    }

    class AwsProviderAdapter {
        -TerraformRunner tf
        -S3DataUploader s3
        -AwsSecretsClient secrets
        +name() aws
    }

    class GcpProviderAdapter {
        -TerraformRunner tf
        -GcsDataUploader gcs
        -GcpSecretManager secrets
        +name() gcp
    }

    class K8sProviderAdapter {
        -HelmRunner helm
        -KubectlRunner kubectl
        -VaultClient vault
        +name() onprem
    }

    ProviderAdapter <|.. AwsProviderAdapter
    ProviderAdapter <|.. GcpProviderAdapter
    ProviderAdapter <|.. K8sProviderAdapter
    ProviderAdapter ..> EnvironmentSpec : uses
    ProviderAdapter ..> TestResult : returns
```

*Diagram 4 — Provider adapter class structure: ProviderAdapter SPI and its three implementations*

---

### 3.4 Layer Summary

| Component | Description |
|---|---|
| **L1 — Consumer entry** | Teams interact with one `env.yaml`, a two-line CI workflow call, and an optional CLI. No platform internals are exposed. |
| **L2 — Platform core** | Orchestrator, Config parser, Secret manager, TTL watchdog. Distributed as a versioned Docker image. Zero cloud SDK imports. |
| **L3 — Test execution** | Migration runner, Data loader, Test runner, Report publisher. Provider-agnostic — identical on AWS, GCP, and on-prem. |
| **L4 — Infrastructure providers** | Pluggable `ProviderAdapter` implementations for AWS, GCP, and Kubernetes. Adding a provider means implementing one interface. |
| **L5 — Shared infra** | State store (PostgreSQL + Redis), Cost engine, Container registry, Observability stack. Never torn down. |

---

### 3.5 Platform Core Components

| Component | Description |
|---|---|
| **Orchestrator** | Drives `provision → seedData → runTests → destroy` in sequence. Wraps `destroy()` in `finally` so it cannot be skipped. Registers TTL before provisioning starts. |
| **Config parser** | Parses `env.yaml` into a typed `EnvironmentSpec`. Validates schema version, TTL limits, and required fields. Errors reported before any cloud resource is touched. |
| **Secret manager** | Abstraction over Vault, AWS SM, and GCP SM. Returns `DbCredentials` — the orchestrator never touches raw passwords. |
| **TTL watchdog** | Scheduled every 5 minutes. Destroys any environment whose `startedAt + ttl` is in the past. Catches stacks orphaned by runner timeouts or OOM kills. |

---

## 4. Spring Boot + PostgreSQL on AWS

The Spring Boot reference implementation is the recommended starting point for all teams onboarding to the platform. It covers all AWS resources provisioned per PR, how they connect, and the complete test and teardown sequence.

---

### 4.1 Architecture Diagram — AWS Stack

> Detailed architecture diagram: full VPC layout, ECS, RDS, S3, Secrets Manager, connections, and teardown sequence.

![Figure 3 — Architecture: Spring Boot + PostgreSQL on AWS ephemeral stack](img/fig3_architecture_springboot.svg)

*Figure 3 — Architecture: Spring Boot + PostgreSQL on AWS ephemeral stack*

---

### 4.2 AWS Infrastructure per PR

```mermaid
flowchart LR
    subgraph VPC["AWS ephemeral VPC — pr-{number}"]
        subgraph Private["Private subnets"]
            ALB[ALB internal]
            ECS[ECS Fargate\nSpring Boot :8080]
            RDS[(RDS PostgreSQL 15\ndb.t3.micro)]
        end
        S3[(S3 bucket\npr-n-test-data)]
        SM2[(Secrets Manager\npr-n/db-credentials)]
    end

    CI([CI runner]) -->|docker push| ECR[(ECR\nimage pr-n)]
    CI -->|terraform apply| VPC
    ECR -->|pull| ECS
    ALB -->|HTTP :80| ECS
    ECS -->|:5432| RDS
    ECS -->|GetSecretValue| SM2
    ECS -->|GetObject| S3
    CI -->|sync testdata/| S3
    CI -->|run tests| ALB

    style VPC fill:#E1F5EE,stroke:#0F6E56
    style Private fill:#9FE1CB,stroke:#1D9E75
```

*Diagram 5 — AWS infrastructure per PR: CI runner, ECR, and all VPC-internal resources*

---

### 4.3 Environment Lifecycle State Machine

```mermaid
stateDiagram-v2
    [*] --> PROVISIONING : PR opened

    PROVISIONING --> SEEDING : provision() success
    PROVISIONING --> FAILED : provision() error

    SEEDING --> TESTING : seedData() success
    SEEDING --> FAILED : seedData() error

    TESTING --> COMPLETE : runTests() pass
    TESTING --> FAILED : runTests() fail or error

    COMPLETE --> DESTROYING : destroy triggered
    FAILED --> DESTROYING : destroy triggered\n(always)

    DESTROYING --> DESTROYED : destroy() success
    DESTROYING --> DESTROY_FAILED : destroy() error

    DESTROYED --> [*]
    DESTROY_FAILED --> [*] : manual cleanup\nrequired

    note right of DESTROYING
        Runs unconditionally.
        CI: if always()
        TTL watchdog: backup
    end note
```

*Diagram 6 — Environment lifecycle state machine: all states and valid transitions*

---

### 4.4 AWS Resources per PR

| Resource | Configuration | Purpose |
|---|---|---|
| **ECS Fargate** | 0.5 vCPU · 1 GB · private subnet | Runs the Spring Boot container. Health check at `/actuator/health`. IAM task role grants S3 and Secrets Manager access. |
| **ALB (internal)** | Private subnets only | Routes HTTP to ECS port 8080. ALB DNS name becomes `APP_ENDPOINT` injected into the test runner. |
| **RDS PostgreSQL 15** | `db.t3.micro` · 20 GB · private subnet | Fresh DB per PR. SG allows 5432 from ECS only. `skip_final_snapshot=true`, `deletion_protection=false` for fast teardown. |
| **S3 bucket** | `pr-{n}-test-data` · private | Holds CSV seed files. Emptied then deleted on destroy. VPC endpoint avoids public internet traffic. |
| **Secrets Manager** | `pr-{n}/db-creds` · `recovery=0 days` | Stores host/port/username/password as JSON. Instantly deleted on destroy. |
| **VPC + subnets** | Private subnets · no public IP | Isolated per PR. VPC endpoints for S3 and SM. ECS and RDS in separate private subnets. |

---

## Diagram Reference

| Ref | Type | Title | Location |
|---|---|---|---|
| Figure 1 | SVG (architecture) | Ephemeral lifecycle — full detail | `img/fig1_architecture_lifecycle.svg` |
| Figure 2 | SVG (architecture) | Five-layer functional platform | `img/fig2_architecture_functional.svg` |
| Figure 3 | SVG (architecture) | Spring Boot + PostgreSQL on AWS | `img/fig3_architecture_springboot.svg` |
| Diagram 1 | Mermaid flowchart | Core lifecycle flowchart | [Section 2.2](#22-lifecycle-flowchart) |
| Diagram 2 | Mermaid sequence | Component interaction sequence | [Section 2.3](#23-component-interaction-sequence) |
| Diagram 3 | Mermaid flowchart | Functional architecture layers | [Section 3.2](#32-functional-layers--mermaid) |
| Diagram 4 | Mermaid class | Provider adapter class structure | [Section 3.3](#33-provider-adapter-class-structure) |
| Diagram 5 | Mermaid flowchart | AWS infrastructure per PR | [Section 4.2](#42-aws-infrastructure-per-pr) |
| Diagram 6 | Mermaid state | Environment lifecycle state machine | [Section 4.3](#43-environment-lifecycle-state-machine) |

---

*Enterprise Ephemeral Test Platform — Architecture & Design Document v1.0*
*Part 1 of 2 — Architecture only. Implementation guide published separately.*
