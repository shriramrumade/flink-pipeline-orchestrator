# Enterprise Ephemeral Test Platform

## Architecture & Design Document

| | |
|---|---|
| **Version** | 1.0 — POC Edition |
| **Scope** | Short-lived ephemeral environments — AWS, GCP, on-prem Kubernetes |
| **Audience** | Platform engineers and application team leads |
| **SVG diagrams** | `img/` folder — open in draw.io, Lucidchart, Confluence, Inkscape |

> **Part 1 — Architecture only.** Implementation guide published separately.

---

## Table of Contents

- [0. System Context (Level 0)](#0-system-context-level-0)
- [1. Container Diagram (Level 1)](#1-container-diagram-level-1)
- [2. Overview](#2-overview)
- [3. Ephemeral Lifecycle](#3-ephemeral-lifecycle)
- [4. Functional Architecture](#4-functional-architecture)
- [5. Spring Boot + PostgreSQL on AWS](#5-spring-boot--postgresql-on-aws)
- [Diagram Reference](#diagram-reference)

---

## 0. System Context (Level 0)

> **What this diagram shows:** The platform treated as a single black box. Identifies every person and external system that interacts with it, and the nature of each relationship. Use this as the first slide in any presentation to a new audience.

### Who interacts with the platform

| Actor | Type | Relationship |
|---|---|---|
| **Dev / App team** | Person | Writes `env.yaml`, opens pull requests, reads test results on the PR check |
| **Platform team** | Person | Owns, operates, and evolves the platform; manages onboarding and cost governance |
| **Finance / Auditors** | Person | Reads per-team cost reports and the immutable audit trail for compliance evidence |
| **GitHub / GitLab** | External system | Source of PR-opened events; receives check results and status updates back |
| **AWS / GCP / K8s** | External system | Target cloud providers where ephemeral resources are provisioned and destroyed |
| **Vault / Secrets Mgr** | External system | Stores all credentials; leases are auto-revoked when environments are destroyed |
| **Datadog / Grafana** | External system | Receives OpenTelemetry metrics, traces, and logs from the platform |
| **Slack / Jira** | External system | Receives test-result notifications; Jira tickets created automatically on failure |

### Diagram

![Level 0 — Full platform system context](img/diag_l0_platform.svg)

*Figure L0-A — System context: full platform, all actors and external systems*

> **Editable SVG:** `img/diag_l0_platform.svg` — drag into Confluence, draw.io, or Lucidchart to edit.

### Key boundary decisions

- The platform is a **single deployable unit** (Docker image) from a consumer perspective. Teams call it and get results — they never configure AWS, Terraform, or IAM.
- The **only inbound trigger** is a PR event. There is no polling, no webhook server to maintain, and no always-on compute beyond the platform control plane.
- Every external system relationship is **one-directional from the platform outward** after the initial trigger. This keeps the blast radius of a platform failure contained.

---

## 1. Container Diagram (Level 1)

> **What this diagram shows:** The platform boundary opened up. Every major deployable component is shown with its technology, its responsibility, and how it communicates with neighbouring components. Use this when explaining platform internals to a new platform engineer or when planning where to add a new feature.

### Component summary

| Component | Technology | Responsibility |
|---|---|---|
| **GitHub Actions Runner** | CI/CD | Triggered by PR events. Calls the platform Docker image. Posts results back to the PR check. |
| **Platform CLI** | Java CLI | Wraps the orchestrator for local dev use. No cloud credentials required — uses the same env.yaml contract. |
| **Self-Service Portal** | Spring Boot + React | Team registration, active environment dashboard, cost history, and audit log viewer. |
| **REST API** | Spring Boot | Exposes cost aggregations, lifecycle history, and audit log for finance and tooling integrations. |
| **Container Registry** | ECR / GCR / Harbor | Shared long-lived registry. All three provider adapters pull images tagged `pr-{number}`. |
| **Orchestrator** | platform-core.jar | Drives `provision → seedData → runTests → destroy` in strict sequence. `destroy()` is in a `finally` block — it cannot be skipped. |
| **Config Parser** | Java — platform-core | Parses `env.yaml` into a typed `EnvironmentSpec`. Validates schema version, TTL limits, and required fields before any cloud resource is touched. |
| **Secret Manager** | Java abstraction | Facade over Vault, AWS SM, and GCP SM. Returns `DbCredentials` — raw passwords never reach the orchestrator. |
| **TTL Watchdog** | @Scheduled Spring bean | Runs every 5 minutes. Queries for environments whose `startedAt + ttl < NOW()`. Calls `destroy()` on each — catches stacks orphaned by CI runner crashes. |
| **Report Publisher** | Spring + REST clients | Parses Surefire XML. Posts pass/fail summary to the GitHub PR check. Sends alert to Slack. Creates Jira ticket on failure. |
| **State Store** | PostgreSQL + Redis | Append-only lifecycle event log (PostgreSQL). Redis pub/sub event bus for real-time TTL and cost tracking. Terraform remote state bucket (S3). |
| **AWS Provider** | AwsProviderAdapter.java | Implements `ProviderAdapter`. Shells out to `terraform apply/destroy`. Provisions ECS Fargate, RDS, S3, Secrets Manager inside an isolated VPC per PR. |
| **GCP Provider** | GcpProviderAdapter.java | Implements `ProviderAdapter`. Provisions Cloud Run, Cloud SQL, GCS, Secret Manager inside an isolated VPC per PR. |
| **On-prem / K8s Provider** | K8sProviderAdapter.java | Implements `ProviderAdapter`. Uses Helm + kubectl. Provisions CNPG PostgreSQL, MinIO, and the app as a Helm release inside one Kubernetes namespace per PR. |

### Diagram

![Level 1 — Full platform container diagram](img/diag_l1_platform.svg)

*Figure L1-A — Container diagram: full platform, all internal components and communication flows*

> **Editable SVG:** `img/diag_l1_platform.svg`

### Critical design rules enforced at this level

- `destroy()` is **always** wrapped in a `finally` block inside the Orchestrator. No exception path can bypass it.
- The Orchestrator saves `PROVISIONING` state to the State Store **before** calling `provision()`. If the CI runner is killed mid-job, the TTL watchdog reads this state and destroys the environment within 5 minutes.
- The three ProviderAdapters have **zero shared code**. They implement the same interface but are compiled as separate Maven modules. A bug in the AWS adapter cannot affect GCP or K8s runs.
- The Container Registry is **shared and long-lived**. It is the only component in the diagram that both the CI runner (writer) and the providers (readers) depend on simultaneously.

---

## 2. Overview

The ephemeral test platform creates a complete, isolated infrastructure stack when a pull request is opened, runs the application's integration test suite against real cloud services, and tears everything down when the PR closes or a TTL expires. **No infrastructure survives past the test run.**

Three core principles drive the design:

- **Any team, any stack** — a single `env.yaml` file is the only contract teams write.
- **Any cloud** — the same `ProviderAdapter` interface works on AWS, GCP, and on-prem Kubernetes.
- **Zero residual cost** — destroy always runs, even when tests fail.

### 2.1 Key design decisions

| Component | Description |
|---|---|
| **ProviderAdapter SPI** | Platform core has zero cloud SDK imports. All cloud operations go through one Java interface: `provision`, `seedData`, `runTests`, `destroy`. |
| **env.yaml contract** | Teams write one file. The platform reads, validates, and acts on it. No Terraform, no cloud SDK, no IAM knowledge required from application teams. |
| **Workspace isolation** | Every PR gets its own Terraform workspace (`pr-{number}`). All resource names are prefixed — zero collisions between concurrent PRs. |
| **Destroy guarantee** | CI uses `if: always()` on the destroy job. A TTL watchdog destroys stale stacks independently, catching anything the CI runner left behind. |
| **Idempotent seed** | Test data uses `INSERT ... ON CONFLICT DO NOTHING`. Safe to re-run on a retried job without duplicating rows. |

---

## 3. Ephemeral Lifecycle

The platform executes a four-stage linear lifecycle for every PR. Stages run in strict sequence. If any stage fails, destroy still runs unconditionally.

| Stage | Name | What happens |
|---|---|---|
| **1** | Trigger | PR opened/updated. GitHub Actions fires. CI reads `env.yaml`, runs `mvn package`, builds a Docker image, pushes to ECR tagged `pr-{number}`. |
| **2** | Provision | Terraform creates an isolated VPC with the application container, database, and object storage — all named with the `pr-{number}` prefix. Terraform outputs (endpoints, secret ARNs) are captured. |
| **3** | Test execution | Flyway migrations run first. The data loader pulls CSV files from S3 and bulk-inserts them. The test runner executes the JUnit suite with live endpoints injected as env vars. Results post to the PR check. |
| **4** | Destroy | `terraform destroy` removes every resource. Secrets Manager secret uses `recovery_window=0` for instant deletion. TTL watchdog fires independently after the configured timeout. |

### 3.1 Architecture diagram — lifecycle detail

![Figure 1 — Architecture: Ephemeral lifecycle](img/fig1_architecture_lifecycle.svg)

*Figure 1 — Architecture: Ephemeral lifecycle (trigger → provision → test execution → destroy)*

### 3.2 Lifecycle flowchart

```mermaid
flowchart TD
    A([PR opened / updated]) --> B[CI reads env.yaml]
    B --> C[mvn package + docker build]
    C --> D[Push image to ECR tagged pr-{number}]
    D --> E[terraform apply workspace = pr-{number}]
    E --> F[(RDS PostgreSQL)]
    E --> G[ECS Fargate Spring Boot]
    E --> H[(S3 test-data bucket)]
    E --> I[(Secrets Manager)]
    F & G & H & I --> J[Flyway migrations]
    J --> K[Load CSV seed data S3 to RDS via COPY]
    K --> L[mvn test -Pintegration JUnit 5 + RestAssured]
    L --> M{Tests passed?}
    M -->|yes| N[Post results to PR check]
    M -->|no| N
    N --> O[terraform destroy if always]
    O --> P([All resources removed zero residual cost])
```

*Diagram 1 — Core lifecycle flowchart*

### 3.3 Component interaction sequence

```mermaid
sequenceDiagram
    autonumber
    participant CI as GitHub Actions
    participant ORC as Orchestrator
    participant AWS as AwsProviderAdapter
    participant TF as Terraform
    participant RDS as RDS PostgreSQL
    participant S3 as S3 bucket
    CI->>ORC: run(EnvironmentSpec)
    ORC->>ORC: stateStore.save(PROVISIONING)
    ORC->>ORC: watchdog.register(ttl)
    ORC->>AWS: provision(spec)
    AWS->>TF: terraform apply workspace=pr-n
    TF-->>AWS: outputs (db_host, s3_bucket, app_endpoint)
    AWS-->>ORC: EnvironmentSpec with live endpoints
    ORC->>AWS: seedData(spec, testDataDir)
    AWS->>S3: upload CSV files
    AWS->>RDS: Flyway migrate
    AWS->>RDS: COPY from S3
    ORC->>AWS: runTests(spec)
    AWS->>CI: mvn test -Pintegration
    CI-->>AWS: TestResult (pass/fail)
    AWS-->>ORC: TestResult
    Note over ORC,AWS: always runs even on failure
    ORC->>AWS: destroy(spec)
    AWS->>TF: terraform destroy workspace=pr-n
    TF-->>AWS: all resources removed
    ORC->>ORC: reporter.publish(result)
```

*Diagram 2 — Component interaction sequence*

---

## 4. Functional Architecture

The platform is structured in five layers. Each layer has a single responsibility and communicates downward only.

### 4.1 Architecture diagram — functional layers

![Figure 2 — Architecture: Five-layer functional platform structure](img/fig2_architecture_functional.svg)

*Figure 2 — Architecture: Five-layer functional platform structure*

### 4.2 Functional layers — Mermaid

```mermaid
flowchart TB
    subgraph L1["Layer 1 — Consumer entry"]
        EY[env.yaml] 
        CW[Reusable CI workflow]
        CLI[Platform CLI]
    end
    subgraph L2["Layer 2 — Platform core"]
        ORC[Orchestrator]
        CP[Config parser]
        SM[Secret manager]
        TTL[TTL watchdog]
    end
    subgraph L3["Layer 3 — Test execution"]
        MR[Migration runner]
        DL[Data loader]
        TR[Test runner]
        RP[Report publisher]
    end
    subgraph L4["Layer 4 — Infrastructure providers"]
        AWS[AWS provider]
        GCP[GCP provider]
        K8S[On-prem / K8s]
    end
    subgraph L5["Layer 5 — Shared long-lived infra"]
        SS[(State store)]
        CE[Cost engine]
        CR[Container registry]
        OB[Observability]
    end
    L1 --> L2 --> L3 --> L4 --> L5
```

*Diagram 3 — Functional architecture layers*

### 4.3 Layer summary

| Component | Description |
|---|---|
| **L1 — Consumer entry** | Teams interact with one `env.yaml`, a two-line CI workflow call, and an optional CLI. No platform internals are exposed. |
| **L2 — Platform core** | Orchestrator, Config parser, Secret manager, TTL watchdog. Distributed as a versioned Docker image. Zero cloud SDK imports. |
| **L3 — Test execution** | Migration runner, Data loader, Test runner, Report publisher. Provider-agnostic — identical on AWS, GCP, and on-prem. |
| **L4 — Infrastructure providers** | Pluggable `ProviderAdapter` implementations for AWS, GCP, and Kubernetes. Adding a provider means implementing one interface. |
| **L5 — Shared infra** | State store (PostgreSQL + Redis), Cost engine, Container registry, Observability stack. Never torn down. |

### 4.4 Provider adapter class structure

```mermaid
classDiagram
    class ProviderAdapter {
        <<interface>>
        +name() String
        +provision(spec) EnvironmentSpec
        +seedData(spec, testDataDir) void
        +runTests(spec) TestResult
        +destroy(spec) void
    }
    class AwsProviderAdapter {
        -TerraformRunner tf
        -S3DataUploader s3
        -AwsSecretsClient secrets
        +name() aws
    }
    class GcpProviderAdapter {
        -TerraformRunner tf
        -GcsDataUploader gcs
        +name() gcp
    }
    class K8sProviderAdapter {
        -HelmRunner helm
        -KubectlRunner kubectl
        +name() onprem
    }
    ProviderAdapter <|.. AwsProviderAdapter
    ProviderAdapter <|.. GcpProviderAdapter
    ProviderAdapter <|.. K8sProviderAdapter
```

*Diagram 4 — Provider adapter class structure*

---

## 5. Spring Boot + PostgreSQL on AWS

> See [Section 5 in the single-application document](ephemeral_springboot_aws.md) for the full Spring Boot reference implementation with its own L0, L1, and stack detail diagrams.

---

## Diagram Reference

| Ref | File | Type | Description |
|---|---|---|---|
| L0-A | `img/diag_l0_platform.svg` | Editable SVG | Full platform system context — all actors and external systems |
| L1-A | `img/diag_l1_platform.svg` | Editable SVG | Full platform container diagram — all internal components |
| Fig 1 | `img/fig1_architecture_lifecycle.svg` | SVG | Detailed lifecycle: trigger → provision → test → destroy |
| Fig 2 | `img/fig2_architecture_functional.svg` | SVG | Detailed five-layer functional architecture |
| Fig 3 | `img/fig3_architecture_springboot.svg` | SVG | Detailed Spring Boot on AWS stack |
| D1 | Section 3.2 | Mermaid flowchart | Core lifecycle flowchart |
| D2 | Section 3.3 | Mermaid sequence | Component interaction sequence |
| D3 | Section 4.2 | Mermaid flowchart | Functional architecture layers |
| D4 | Section 4.4 | Mermaid class | Provider adapter class structure |

---

*Enterprise Ephemeral Test Platform — Architecture & Design Document v1.0*
