# Infra Team Example

This folder shows how an **application/infrastructure team** wires the
`shared-data-seeding` reusable workflow into their own repo.

Copy `.github/workflows/create-env.yml` into your application repository,
adjust the Terraform steps to match your actual provisioning process, and
add the required secrets:

| Secret | Required for | Description |
|---|---|---|
| `DB_PASSWORD` | Both | Database password |
| `AWS_ROLE_TO_ASSUME` | AWS | ARN of an IAM role with S3 read access (OIDC) |
| `GCP_WORKLOAD_IDENTITY_PROVIDER` | GCP | Workload Identity Provider resource name |
| `GCP_SERVICE_ACCOUNT` | GCP | Service account email to impersonate |

See the full guide in `shared-data-seeding/ARCHITECTURE.md` for details on
how the call chain and multi-cloud auth work end to end.
