from setuptools import setup, find_packages

setup(
    name="shared-data-seeding",
    version="1.2.0",
    description="Enterprise ephemeral data seeding platform for GitHub Actions",
    packages=find_packages(exclude=["tests", "tests.*"]),
    python_requires=">=3.11",
    install_requires=[
        "boto3>=1.34.0",
        "google-cloud-storage>=2.10.0",
        "psycopg2-binary>=2.9.9",
        "pymysql>=1.1.0",
        "PyYAML>=6.0",
        "pandas>=2.0.0",
        "Faker>=20.0.0",
    ],
)
