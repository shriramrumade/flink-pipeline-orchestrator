import pytest


class TestCloudClients:
    @pytest.mark.integration
    def test_s3_download(self):
        """Requires AWS credentials and a real/test S3 bucket."""
        from src.cloud.aws_client import S3Client
        client = S3Client()
        client.download_seed_data(
            source='s3://test-bucket/seed-data/pr-123/',
            destination='/tmp/test'
        )
        # Assert files downloaded (fill in with real assertions in your env)

    @pytest.mark.integration
    def test_gcs_download(self):
        """Requires GCP credentials and a real/test GCS bucket."""
        from src.cloud.gcp_client import GCSClient
        client = GCSClient()
        client.download_seed_data(
            source='gs://test-bucket/seed-data/pr-123/',
            destination='/tmp/test'
        )
        # Assert files downloaded (fill in with real assertions in your env)
