from src.generators.synthetic import DataGenerator


class TestDataGenerator:
    def test_generate_users(self):
        gen = DataGenerator()
        users = gen._generate_users(5)
        assert len(users) == 5
        assert all('email' in u for u in users)

    def test_generate_respects_dev_profile_cap(self):
        gen = DataGenerator()
        data = gen.generate(profile='dev', tables={'users': {'count': 500}})
        assert len(data['users']) <= 50

    def test_generate_staging_multiplies_count(self):
        gen = DataGenerator()
        data = gen.generate(profile='staging', tables={'products': {'count': 10}})
        assert len(data['products']) == 100
