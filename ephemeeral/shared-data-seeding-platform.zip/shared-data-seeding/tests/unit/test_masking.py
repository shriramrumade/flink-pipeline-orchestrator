from src.generators.masking import hash_field, mask_field, apply_masking_rules


class TestMasking:
    def test_hash_field_is_deterministic(self):
        assert hash_field("test@example.com") == hash_field("test@example.com")

    def test_mask_field_keeps_first_char(self):
        assert mask_field("Jane") == "J***"

    def test_apply_masking_rules(self):
        records = [{"email": "jane@example.com", "first_name": "Jane"}]
        rules = [
            {"field": "email", "operation": "hash"},
            {"field": "first_name", "operation": "mask"},
        ]
        result = apply_masking_rules(records, rules)
        assert result[0]["first_name"] == "J***"
        assert result[0]["email"] != "jane@example.com"
