import pytest
from unittest.mock import patch
from src.orchestration.seed_engine import SeedEngine


class TestSeedEngine:
    def test_initialization(self):
        with patch.dict('os.environ', {
            'CLOUD_PROVIDER': 'aws',
            'ENVIRONMENT_ID': 'test-123',
            'DB_HOST': 'localhost',
            'DB_NAME': 'testdb',
            'DB_USER': 'testuser',
            'DB_PASSWORD': 'testpass'
        }):
            with patch('src.orchestration.seed_engine.get_cloud_client'), \
                 patch('src.orchestration.seed_engine.get_db_connector'):
                engine = SeedEngine()
                assert engine.cloud_provider == 'aws'
                assert engine.environment_id == 'test-123'

    def test_validate_config_missing(self):
        with patch.dict('os.environ', {}, clear=True):
            with pytest.raises(ValueError) as exc:
                SeedEngine()
            assert "Missing required config" in str(exc.value)

    @patch('src.orchestration.seed_engine.SeedEngine._verify_seed')
    @patch('src.orchestration.seed_engine.SeedEngine._apply_seed')
    @patch('src.orchestration.seed_engine.SeedEngine._process_data')
    @patch('src.orchestration.seed_engine.SeedEngine._get_seed_data')
    def test_run_success(self, mock_get, mock_process, mock_apply, mock_verify):
        with patch.dict('os.environ', {
            'CLOUD_PROVIDER': 'aws',
            'ENVIRONMENT_ID': 'test-123',
            'DB_HOST': 'localhost',
            'DB_NAME': 'testdb',
            'DB_USER': 'testuser',
            'DB_PASSWORD': 'testpass'
        }):
            with patch('src.orchestration.seed_engine.get_cloud_client'), \
                 patch('src.orchestration.seed_engine.get_db_connector'):
                engine = SeedEngine()
                mock_get.return_value = {'users': [{'id': 1}]}
                mock_process.return_value = {'users': [{'id': 1}]}

                engine.run()

                mock_get.assert_called_once()
                mock_process.assert_called_once()
                mock_apply.assert_called_once()
                mock_verify.assert_called_once()
