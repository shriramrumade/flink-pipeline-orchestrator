"""
Factory for cloud storage clients
"""

from src.cloud.base import CloudStorageClient


def get_cloud_client(provider: str) -> CloudStorageClient:
    """Factory method for cloud clients"""
    if provider.lower() == 'aws':
        from src.cloud.aws_client import S3Client
        return S3Client()
    elif provider.lower() == 'gcp':
        from src.cloud.gcp_client import GCSClient
        return GCSClient()
    else:
        raise ValueError(f"Unsupported cloud provider: {provider}")
