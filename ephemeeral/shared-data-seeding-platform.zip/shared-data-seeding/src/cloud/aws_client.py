"""
AWS S3 cloud storage client
"""

import os
from src.cloud.base import CloudStorageClient
import boto3


class S3Client(CloudStorageClient):
    """AWS S3 client implementation"""

    def __init__(self):
        self.client = boto3.client('s3')

    def download_seed_data(self, source: str, destination: str):
        """Download from S3 bucket"""
        parts = source.replace('s3://', '').split('/', 1)
        bucket = parts[0]
        prefix = parts[1] if len(parts) > 1 else ''

        paginator = self.client.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get('Contents', []):
                key = obj['Key']
                if key.endswith('.json'):
                    local_path = os.path.join(destination, os.path.basename(key))
                    self.client.download_file(bucket, key, local_path)

    def upload_seed_data(self, source: str, destination: str):
        """Upload to S3 bucket"""
        # Implementation left to team-specific requirements
        pass

    def list_seed_environments(self) -> list:
        """List environments in S3"""
        # Implementation left to team-specific requirements
        return []
