"""
Abstract cloud storage client interface
"""

from abc import ABC, abstractmethod


class CloudStorageClient(ABC):
    """Abstract cloud storage client"""

    @abstractmethod
    def download_seed_data(self, source: str, destination: str):
        """Download seed data from cloud storage"""
        pass

    @abstractmethod
    def upload_seed_data(self, source: str, destination: str):
        """Upload seed data to cloud storage"""
        pass

    @abstractmethod
    def list_seed_environments(self) -> list:
        """List available seed environments"""
        pass
