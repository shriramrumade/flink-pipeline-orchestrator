"""
Google Cloud Storage client
"""

import os
from src.cloud.base import CloudStorageClient
from google.cloud import storage


class GCSClient(CloudStorageClient):
    """Google Cloud Storage client implementation"""

    def __init__(self):
        self.client = storage.Client()

    def download_seed_data(self, source: str, destination: str):
        """Download from GCS bucket"""
        parts = source.replace('gs://', '').split('/', 1)
        bucket_name = parts[0]
        prefix = parts[1] if len(parts) > 1 else ''

        bucket = self.client.bucket(bucket_name)
        blobs = bucket.list_blobs(prefix=prefix)

        for blob in blobs:
            if blob.name.endswith('.json'):
                local_path = os.path.join(destination, os.path.basename(blob.name))
                blob.download_to_filename(local_path)

    def upload_seed_data(self, source: str, destination: str):
        """Upload to GCS bucket"""
        # Implementation left to team-specific requirements
        pass

    def list_seed_environments(self) -> list:
        """List environments in GCS"""
        # Implementation left to team-specific requirements
        return []
