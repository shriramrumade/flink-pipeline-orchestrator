"""
Abstract database connector interface
"""

from abc import ABC, abstractmethod
from typing import List, Dict


class DatabaseConnector(ABC):
    """Abstract database connector"""

    def __init__(self, host: str, port: int, database: str, user: str, password: str):
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        self.connection = None

    @abstractmethod
    def connect(self):
        """Establish database connection"""
        pass

    @abstractmethod
    def truncate_table(self, table_name: str):
        """Truncate table"""
        pass

    @abstractmethod
    def insert_records(self, table_name: str, records: List[Dict]):
        """Insert records in batch"""
        pass

    @abstractmethod
    def get_count(self, table_name: str) -> int:
        """Get record count"""
        pass

    def close(self):
        """Close connection"""
        if self.connection:
            self.connection.close()
