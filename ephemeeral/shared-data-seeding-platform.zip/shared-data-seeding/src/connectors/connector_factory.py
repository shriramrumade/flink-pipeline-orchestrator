"""
Factory for database connectors
"""

from src.connectors.base import DatabaseConnector


def get_db_connector(db_type: str, **kwargs) -> DatabaseConnector:
    """Factory method for database connectors"""
    db_type = db_type.lower()

    if db_type in ['postgresql', 'postgres']:
        from src.connectors.postgres import PostgreSQLConnector
        return PostgreSQLConnector(**kwargs)
    elif db_type == 'mysql':
        from src.connectors.mysql import MySQLConnector
        return MySQLConnector(**kwargs)
    elif db_type == 'oracle':
        from src.connectors.oracle import OracleConnector
        return OracleConnector(**kwargs)
    elif db_type == 'sqlserver':
        from src.connectors.sqlserver import SQLServerConnector
        return SQLServerConnector(**kwargs)
    else:
        raise ValueError(f"Unsupported database type: {db_type}")
