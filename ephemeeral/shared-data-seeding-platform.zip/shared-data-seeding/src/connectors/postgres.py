"""
PostgreSQL database connector
"""

from typing import List, Dict
from src.connectors.base import DatabaseConnector
import psycopg2
from psycopg2.extras import execute_values


class PostgreSQLConnector(DatabaseConnector):
    """PostgreSQL connector"""

    def connect(self):
        self.connection = psycopg2.connect(
            host=self.host,
            port=self.port,
            dbname=self.database,
            user=self.user,
            password=self.password
        )

    def truncate_table(self, table_name: str):
        with self.connection.cursor() as cursor:
            cursor.execute(f'TRUNCATE TABLE {table_name} RESTART IDENTITY CASCADE')
            self.connection.commit()

    def insert_records(self, table_name: str, records: List[Dict]):
        if not records:
            return

        columns = list(records[0].keys())
        columns_str = ', '.join(columns)
        values = [[record.get(col) for col in columns] for record in records]

        with self.connection.cursor() as cursor:
            query = f'INSERT INTO {table_name} ({columns_str}) VALUES %s'
            execute_values(cursor, query, values)
            self.connection.commit()

    def get_count(self, table_name: str) -> int:
        with self.connection.cursor() as cursor:
            cursor.execute(f'SELECT COUNT(*) FROM {table_name}')
            return cursor.fetchone()[0]
