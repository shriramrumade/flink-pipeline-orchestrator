"""
Oracle database connector

NOTE: This is a structural placeholder matching the platform's connector
interface. Implement using `oracledb` (formerly cx_Oracle) before use.
"""

from typing import List, Dict
from src.connectors.base import DatabaseConnector


class OracleConnector(DatabaseConnector):
    """Oracle connector (not yet implemented)"""

    def connect(self):
        raise NotImplementedError(
            "OracleConnector.connect() requires the 'oracledb' driver. "
            "Add it to requirements.txt and implement the connection logic."
        )

    def truncate_table(self, table_name: str):
        raise NotImplementedError("Implement TRUNCATE TABLE logic for Oracle")

    def insert_records(self, table_name: str, records: List[Dict]):
        raise NotImplementedError("Implement batch INSERT logic for Oracle")

    def get_count(self, table_name: str) -> int:
        raise NotImplementedError("Implement SELECT COUNT(*) logic for Oracle")
