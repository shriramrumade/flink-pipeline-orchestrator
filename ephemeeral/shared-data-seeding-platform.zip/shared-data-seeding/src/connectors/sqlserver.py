"""
SQL Server database connector

NOTE: This is a structural placeholder matching the platform's connector
interface. Implement using `pyodbc` or `pymssql` before use.
"""

from typing import List, Dict
from src.connectors.base import DatabaseConnector


class SQLServerConnector(DatabaseConnector):
    """SQL Server connector (not yet implemented)"""

    def connect(self):
        raise NotImplementedError(
            "SQLServerConnector.connect() requires 'pyodbc' or 'pymssql'. "
            "Add it to requirements.txt and implement the connection logic."
        )

    def truncate_table(self, table_name: str):
        raise NotImplementedError("Implement TRUNCATE TABLE logic for SQL Server")

    def insert_records(self, table_name: str, records: List[Dict]):
        raise NotImplementedError("Implement batch INSERT logic for SQL Server")

    def get_count(self, table_name: str) -> int:
        raise NotImplementedError("Implement SELECT COUNT(*) logic for SQL Server")
