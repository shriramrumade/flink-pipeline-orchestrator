"""
Utilities for creating referentially-consistent subsets of data,
e.g., sampling a percentage of rows while preserving foreign-key
relationships across related tables.
"""

import random
from typing import Dict, List


def sample_table(records: List[Dict], fraction: float, seed: int = 42) -> List[Dict]:
    """Randomly sample a fraction of records from a table."""
    if not (0 < fraction <= 1):
        raise ValueError("fraction must be between 0 and 1")
    rng = random.Random(seed)
    k = max(1, int(len(records) * fraction))
    return rng.sample(records, k) if len(records) > k else list(records)


def filter_related(
    parent_records: List[Dict],
    child_records: List[Dict],
    parent_key: str,
    child_fk: str,
) -> List[Dict]:
    """
    Keep only child records whose foreign key matches one of the
    sampled parent records, preserving referential integrity.
    """
    valid_ids = {record[parent_key] for record in parent_records}
    return [r for r in child_records if r.get(child_fk) in valid_ids]
