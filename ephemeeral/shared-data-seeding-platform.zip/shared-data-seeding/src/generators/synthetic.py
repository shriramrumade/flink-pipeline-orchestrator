"""
Synthetic data generation using Faker
"""

import random
from typing import Dict, List
from faker import Faker


class DataGenerator:
    """Generate synthetic test data"""

    def __init__(self):
        self.faker = Faker()
        Faker.seed(42)  # Deterministic for consistency

    def generate(self, profile: str, tables: Dict) -> Dict:
        """Generate data for all tables based on profile"""
        data = {}

        for table_name, config in tables.items():
            count = config.get('count', 100)

            if profile == 'dev':
                count = min(count, 50)
            elif profile == 'staging':
                count = count * 10
            # 'test' profile uses the configured count as-is

            generator_method = getattr(self, f'_generate_{table_name}', None)
            if generator_method:
                data[table_name] = generator_method(count)
            else:
                data[table_name] = self._generate_generic(count, config)

        return data

    def _generate_users(self, count: int) -> List[Dict]:
        """Generate user data"""
        users = []
        for _ in range(count):
            users.append({
                'id': self.faker.uuid4(),
                'email': self.faker.email(),
                'first_name': self.faker.first_name(),
                'last_name': self.faker.last_name(),
                'created_at': self.faker.date_time_this_year().isoformat(),
                'active': self.faker.boolean(chance_of_getting_true=80)
            })
        return users

    def _generate_products(self, count: int) -> List[Dict]:
        """Generate product data"""
        products = []
        categories = ['Electronics', 'Books', 'Clothing', 'Food', 'Toys']

        for _ in range(count):
            products.append({
                'id': self.faker.uuid4(),
                'name': self.faker.catch_phrase(),
                'description': self.faker.text(max_nb_chars=200),
                'price': round(random.uniform(10, 1000), 2),
                'category': random.choice(categories),
                'stock': random.randint(0, 1000)
            })
        return products

    def _generate_orders(self, count: int) -> List[Dict]:
        """Generate order data"""
        orders = []
        statuses = ['pending', 'processing', 'completed', 'cancelled']

        for _ in range(count):
            orders.append({
                'id': self.faker.uuid4(),
                'user_id': self.faker.uuid4(),
                'total': round(random.uniform(20, 5000), 2),
                'status': random.choice(statuses),
                'created_at': self.faker.date_time_this_year().isoformat()
            })
        return orders

    def _generate_generic(self, count: int, config: Dict) -> List[Dict]:
        """Generate generic data based on config"""
        records = []
        for _ in range(count):
            record = {}
            for field, field_config in config.get('fields', {}).items():
                field_type = field_config.get('type', 'string')
                if field_type == 'string':
                    record[field] = self.faker.word()
                elif field_type == 'email':
                    record[field] = self.faker.email()
                elif field_type == 'int':
                    record[field] = random.randint(0, 1000)
                elif field_type == 'float':
                    record[field] = random.uniform(0, 100)
                elif field_type == 'date':
                    record[field] = self.faker.date_this_year().isoformat()
                elif field_type == 'boolean':
                    record[field] = self.faker.boolean()
                else:
                    record[field] = self.faker.text(max_nb_chars=50)
            records.append(record)
        return records
