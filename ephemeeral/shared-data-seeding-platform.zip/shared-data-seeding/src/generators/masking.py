"""
Data masking utilities for redacting/anonymizing sensitive fields
before seed data is written to ephemeral environments.
"""

import hashlib
from typing import Dict, List


def hash_field(value: str, salt: str = "") -> str:
    """One-way hash a field value (e.g., for emails, identifiers)."""
    if value is None:
        return value
    return hashlib.sha256(f"{salt}{value}".encode("utf-8")).hexdigest()[:16]


def mask_field(value: str, keep_chars: int = 1, mask_char: str = "*") -> str:
    """Mask all but the first `keep_chars` characters of a string field."""
    if not value:
        return value
    visible = value[:keep_chars]
    return visible + mask_char * max(len(value) - keep_chars, 0)


def apply_masking_rules(records: List[Dict], rules: List[Dict]) -> List[Dict]:
    """
    Apply a list of masking rules to a batch of records.

    rules example:
        [{"field": "email", "operation": "hash"},
         {"field": "first_name", "operation": "mask"}]
    """
    for record in records:
        for rule in rules:
            field = rule.get("field")
            operation = rule.get("operation")
            if field not in record:
                continue
            if operation == "hash":
                record[field] = hash_field(record[field])
            elif operation == "mask":
                record[field] = mask_field(record[field])
    return records
