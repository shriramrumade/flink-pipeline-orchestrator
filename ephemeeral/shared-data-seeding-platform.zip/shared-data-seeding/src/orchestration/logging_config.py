"""
Centralized logging configuration
"""

import logging
import sys
from pathlib import Path
import json
from datetime import datetime, timezone


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging"""

    def format(self, record):
        log_entry = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'level': record.levelname,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        if hasattr(record, 'extra_data'):
            log_entry['extra'] = record.extra_data
        return json.dumps(log_entry)


def setup_logging():
    """Setup logging configuration"""
    log_dir = Path(__file__).resolve().parents[2] / 'logs'
    log_dir.mkdir(exist_ok=True)

    logger = logging.getLogger('data_seed')
    logger.setLevel(logging.DEBUG)

    if logger.handlers:
        return logger  # avoid duplicate handlers on reimport

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_format = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    console_handler.setFormatter(console_format)
    logger.addHandler(console_handler)

    log_file = log_dir / f'seed-{datetime.now().strftime("%Y%m%d-%H%M%S")}.log'
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(JSONFormatter())
    logger.addHandler(file_handler)

    return logger
