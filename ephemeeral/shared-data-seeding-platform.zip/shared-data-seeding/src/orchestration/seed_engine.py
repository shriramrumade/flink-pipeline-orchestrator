#!/usr/bin/env python3
"""
Enterprise Data Seeding Engine
Handles seeding ephemeral databases from various sources
"""

import os
import json
import tempfile
from pathlib import Path
from typing import Dict, List
import yaml
import pandas as pd

from src.cloud.client_factory import get_cloud_client
from src.connectors.connector_factory import get_db_connector
from src.generators.synthetic import DataGenerator
from src.orchestration.logging_config import setup_logging

# Initialize logging
logger = setup_logging()


class SeedEngine:
    """Main seeding orchestration engine"""

    def __init__(self):
        self.cloud_provider = os.getenv('CLOUD_PROVIDER', 'aws')
        self.environment_id = os.getenv('ENVIRONMENT_ID', 'local')
        self.seed_source = os.getenv('SEED_SOURCE', 'template')
        self.seed_profile = os.getenv('SEED_PROFILE', 'test')

        self.db_config = {
            'host': os.getenv('DB_HOST'),
            'port': int(os.getenv('DB_PORT', 5432)),
            'database': os.getenv('DB_NAME'),
            'user': os.getenv('DB_USER'),
            'password': os.getenv('DB_PASSWORD')
        }

        self._validate_config()

        self.cloud_client = get_cloud_client(self.cloud_provider)
        self.db_connector = get_db_connector(
            db_type=self._detect_db_type(),
            **self.db_config
        )
        self.data_generator = DataGenerator()

        self.config = self._load_config()

    def _validate_config(self):
        """Validate all required environment variables"""
        required = ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']
        missing = [r for r in required if not os.getenv(r)]
        if missing:
            raise ValueError(f"Missing required config: {missing}")

    def _detect_db_type(self) -> str:
        """Detect database type from port or config"""
        port = int(os.getenv('DB_PORT', 5432))
        if port in [5432, 5433]:
            return 'postgresql'
        elif port in [3306, 3307]:
            return 'mysql'
        elif port in [1521]:
            return 'oracle'
        elif port in [1433]:
            return 'sqlserver'
        return 'postgresql'  # default

    def _load_config(self) -> Dict:
        """Load seed configuration"""
        config_path = Path(__file__).resolve().parents[2] / 'config' / 'seed-config.yaml'
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)

    def run(self):
        """Main execution flow"""
        logger.info(f"Starting seed for {self.environment_id} on {self.cloud_provider}")

        try:
            seed_data = self._get_seed_data()
            processed_data = self._process_data(seed_data)
            self._apply_seed(processed_data)
            self._verify_seed()
            logger.info("Seeding completed successfully")
        except Exception as e:
            logger.error(f"Seeding failed: {str(e)}")
            raise

    def _get_seed_data(self) -> Dict:
        """Retrieve seed data from source"""
        if self.seed_source == 'template':
            return self._get_template_data()
        elif self.seed_source.startswith('s3://') or self.seed_source.startswith('gs://'):
            return self._get_cloud_data()
        elif self.seed_source == 'generate':
            return self._generate_data()
        else:
            return self._get_custom_data()

    def _get_template_data(self) -> Dict:
        """Load template seed data"""
        template_dir = Path(__file__).resolve().parents[2] / 'seed-data-templates'
        data = {}
        for file in template_dir.glob('*.csv'):
            table_name = file.stem
            df = pd.read_csv(file)
            data[table_name] = df.to_dict('records')
        logger.info(f"Loaded template data with {len(data)} tables")
        return data

    def _get_cloud_data(self) -> Dict:
        """Download seed data from cloud storage"""
        logger.info(f"Downloading seed data from {self.seed_source}")
        cloud_path = self._construct_cloud_path()

        with tempfile.TemporaryDirectory() as tmpdir:
            self.cloud_client.download_seed_data(source=cloud_path, destination=tmpdir)
            data = {}
            for file in Path(tmpdir).glob('*.json'):
                with open(file, 'r') as f:
                    data[file.stem] = json.load(f)
            return data

    def _get_custom_data(self) -> Dict:
        """Load a custom named seed set (placeholder hook for teams to extend)"""
        raise NotImplementedError(
            f"No handler registered for custom seed source '{self.seed_source}'"
        )

    def _construct_cloud_path(self) -> str:
        """Construct cloud storage path based on environment"""
        base_path = self.config.get('storage', {}).get('base_path', 'seed-data')
        if self.cloud_provider == 'aws':
            return f"s3://{base_path}/{self.environment_id}/"
        else:
            return f"gs://{base_path}/{self.environment_id}/"

    def _generate_data(self) -> Dict:
        """Generate synthetic data"""
        logger.info(f"Generating synthetic data with profile: {self.seed_profile}")
        return self.data_generator.generate(
            profile=self.seed_profile,
            tables=self.config.get('tables', {})
        )

    def _process_data(self, data: Dict) -> Dict:
        """Transform and validate data before insertion"""
        processed = {}
        for table_name, records in data.items():
            if table_name in self.config.get('transformations', {}):
                transforms = self.config['transformations'][table_name]
                records = self._apply_transformations(records, transforms)

            if table_name in self.config.get('validations', {}):
                schema = self.config['validations'][table_name]
                self._validate_records(records, schema)

            processed[table_name] = records
        return processed

    def _apply_transformations(self, records: List[Dict], transforms: List) -> List:
        """Apply field transformations (hashing PII, date formatting, etc.)"""
        return records

    def _validate_records(self, records: List[Dict], schema: Dict):
        """Validate records against schema"""
        pass

    def _apply_seed(self, data: Dict):
        """Apply seeded data to database"""
        logger.info(f"Applying seed to database: {self.db_config['database']}")
        self.db_connector.connect()

        for table_name, records in data.items():
            logger.info(f"Seeding {table_name} with {len(records)} records")
            self.db_connector.truncate_table(table_name)

            batch_size = self.config.get('batch_size', 1000)
            for i in range(0, len(records), batch_size):
                batch = records[i:i + batch_size]
                self.db_connector.insert_records(table_name, batch)
                logger.debug(f"Inserted {min(i + batch_size, len(records))} records")

        self.db_connector.close()

    def _verify_seed(self):
        """Verify seed data counts and relationships"""
        verification = self.config.get('verification', {})
        for table_name, expected_count in verification.get('counts', {}).items():
            actual_count = self.db_connector.get_count(table_name)
            if actual_count != expected_count:
                raise ValueError(
                    f"Verification failed: {table_name} expected {expected_count}, "
                    f"got {actual_count}"
                )
        logger.info("Verification passed")


if __name__ == "__main__":
    engine = SeedEngine()
    engine.run()
