# Changelog

All notable changes to this project are documented here.

## [1.2.0] - Unreleased
- Restructured `src/` into `orchestration/`, `cloud/`, `connectors/`, and
  `generators/` submodules to match the platform architecture.
- Added `masking.py` and `subsets.py` generator utilities.
- Added connector stubs for Oracle and SQL Server (interfaces only —
  implement with `oracledb` / `pyodbc` before use).

## [1.1.0]
- Added GCP support (Workload Identity Federation, GCS).
- Added synthetic data generation profiles (`dev`, `test`, `staging`).

## [1.0.0]
- Initial release: reusable workflow, composite action, S3-backed seeding,
  PostgreSQL and MySQL connectors.
