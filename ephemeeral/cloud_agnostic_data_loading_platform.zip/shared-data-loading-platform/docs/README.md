# Design Documentation

See `cloud-agnostic-data-loading.md` for the complete architecture and workflow documentation.
