# Cloud-Agnostic Data Loading for Ephemeral Environments

## 1. Scope and assumptions

This design solves one focused problem:

> An ephemeral environment already exists. A dataset already exists in application-team-owned cloud storage. Load that dataset into the target database inside the ephemeral environment.

### Existing capabilities

- Dataset creation already exists.
- Datasets are stored by the application team in GCS, S3, or Azure Blob.
- Ephemeral environment provisioning already exists.
- Application teams can provide a manifest describing source storage, dataset path, files, table names, formats, and dependency/load order.

### V1 implementation

| Source | Target |
|---|---|
| GCS | Cloud SQL PostgreSQL |
| S3 | MySQL |

The design deliberately does **not** use Spark. Spark can remain part of dataset creation/preparation if needed, but it is not required for materializing an already-created dataset.

---

## 2. Architecture diagram

```mermaid
flowchart LR
    A[Application Team] -->|Manifest YAML/JSON| W[Shared Data Seeding Workflow<br/>GitHub Actions]

    A --> GCS[GCS Dataset]
    A --> S3[S3 Dataset]
    A --> AB[Azure Blob<br/>Future]

    W -->|Launch Job| K[Ephemeral Environment<br/>Public Cloud / Kubernetes]

    K --> L[Data Loader Job]

    L --> SP[Storage Provider]
    SP --> G[ GCS Adapter ]
    SP --> S[ S3 Adapter ]
    SP --> AF[ Azure Adapter<br/>Future ]

    G --> GCS
    S --> S3
    AF --> AB

    L --> DBP[Database Provider]
    DBP --> PG[PostgreSQL Loader]
    DBP --> MY[MySQL Loader]
    DBP --> OF[Oracle / SQL Server<br/>Future]

    PG --> CSQL[Cloud SQL PostgreSQL]
    MY --> MYSQL[MySQL]

    K -. workload identity / IAM .-> GCS
    K -. workload identity / IAM .-> S3
```

### Main architectural boundary

**Application teams own:**
- Dataset
- Dataset storage
- Manifest
- Dataset file/table structure

**Platform team owns:**
- Shared workflow
- Data loader
- Storage adapters
- Database adapters
- Retry/checkpoint behavior
- Validation
- Observability

---

## 3. Component architecture

```mermaid
flowchart TB
    M[Manifest] --> C[Loader Core]

    C --> MR[Manifest Parser]
    C --> DR[Dependency Resolver]
    C --> CP[Checkpoint Store]
    C --> VAL[Validation / Reporting]

    C --> SF[Storage Factory]
    SF --> GCS[GCSObjectStore]
    SF --> S3[S3ObjectStore]

    C --> DF[Database Factory]
    DF --> PG[PostgresLoader]
    DF --> MY[MySQLLoader]

    GCS --> DATA[Dataset Files]
    S3 --> DATA

    PG --> PGDB[Cloud SQL PostgreSQL]
    MY --> MYDB[MySQL]
```

The core has no cloud-specific or database-specific implementation logic. Factories select adapters based on the manifest.

---

## 4. Workflow diagram

```mermaid
flowchart TD
    A[Dataset already exists] --> B[Application team provides manifest]
    B --> C[Invoke shared-data-seeding workflow]
    C --> D[Validate manifest]
    D --> E[Resolve ephemeral environment]
    E --> F[Create ConfigMap / loader configuration]
    F --> G[Launch Data Loader Kubernetes Job]
    G --> H[Authenticate using cloud workload identity]
    H --> I[Read dataset files]
    I --> J[Resolve table dependencies / load order]
    J --> K[Bulk load target database]
    K --> L[Checkpoint table completion]
    L --> M{More tables?}
    M -->|Yes| I
    M -->|No| N[Validate row counts / load result]
    N --> O{Validation successful?}
    O -->|Yes| P[Environment ready]
    O -->|No| Q[Fail and report]
```

---

## 5. Detailed runtime sequence

```mermaid
sequenceDiagram
    participant App as Application Repo
    participant GH as Shared Data Seeding
    participant K8s as Ephemeral Kubernetes
    participant Loader as Data Loader Job
    participant Store as GCS / S3
    participant DB as Target Database

    App->>GH: seed(manifest, environment)
    GH->>GH: Validate manifest
    GH->>K8s: Create loader ConfigMap
    GH->>K8s: Create loader Job
    K8s->>Loader: Start container
    Loader->>Store: Authenticate + read dataset
    Store-->>Loader: Dataset file
    Loader->>Loader: Resolve dependency order
    Loader->>DB: Bulk load table
    DB-->>Loader: Load result
    Loader->>Loader: Checkpoint COMPLETE
    Loader->>Store: Read next file
    Loader->>DB: Bulk load next table
    DB-->>Loader: Load result
    Loader->>Loader: Validate final counts
    Loader-->>K8s: Job complete
    K8s-->>GH: Job status + logs
    GH-->>App: SUCCESS / FAILURE
```

---

## 6. Manifest contract

Application teams provide a manifest such as:

```yaml
version: "1"

source:
  type: gcs
  bucket: app-team-data
  prefix: payments/regression-v5

target:
  type: postgres
  database: payments

tables:
  - name: customer
    file: customer.csv
    format: csv
    order: 1

  - name: account
    file: account.csv
    format: csv
    order: 2
    dependsOn: [customer]

  - name: transaction
    file: transaction.csv
    format: csv
    order: 3
    dependsOn: [account]

options:
  validation: true
```

For S3 -> MySQL only the source and target types change.

Credentials should **never** be placed in the manifest.

---

## 7. Authentication model

### GCS

```text
Data Loader Pod
      |
      v
GCP Workload Identity
      |
      v
GCS
```

Grant the loader service account only the required read permissions.

### S3

```text
Data Loader Pod
      |
      v
AWS IAM / Web Identity
      |
      v
S3
```

Grant only `ListBucket` and `GetObject` for the required dataset prefix.

### Future Azure

Use Azure Workload Identity / Managed Identity.

---

## 8. Loading strategy

V1 flow:

```text
Object Storage
     |
     | download
     v
Ephemeral Loader Disk
     |
     | bulk load
     v
Database
```

PostgreSQL uses `COPY`.

MySQL uses `LOAD DATA LOCAL INFILE`.

This is intentionally different from row-by-row inserts.

### Future optimization

For very large datasets, replace the local-file stage with a bounded streaming / multipart pipeline:

```text
Object Storage
      |
      v
Parallel Reader
      |
      v
Bounded Buffer
      |
      v
Database Bulk API
```

The storage and database interfaces are designed so this optimization does not require changing the workflow contract.

---

## 9. Table dependency handling

Simple datasets can use `order`.

Example:

```text
customer     order 1
account      order 2
transaction  order 3
```

For richer datasets, `dependsOn` is preferred:

```text
customer
   |
   v
account
   |
   v
transaction
```

The loader performs a topological ordering and detects cycles before loading.

---

## 10. Checkpoint and retry

The loader records completion:

```text
customer       COMPLETE
account        COMPLETE
transaction    FAILED
```

A retry skips completed tables and resumes from the failed table.

For production, the checkpoint should eventually be stored outside the container filesystem if retries can land on a new pod. Recommended future options:

- Kubernetes-mounted persistent volume
- Small control-plane database
- Object-store checkpoint
- Job status / external state service

---

## 11. Security

Do not put these in the manifest:

- Cloud access keys
- Secret keys
- DB passwords
- OAuth tokens

Use:

- GCP Workload Identity
- AWS IAM / Web Identity
- Azure Workload Identity
- Kubernetes Secrets / External Secrets for database credentials
- Least-privilege object-storage permissions

---

## 12. Extensibility model

### Storage

```text
ObjectStore
├── GCSObjectStore
├── S3ObjectStore
└── AzureBlobStore       # future
```

### Database

```text
DatabaseLoader
├── PostgresLoader
├── MySQLLoader
├── OracleLoader         # future
├── SQLServerLoader      # future
└── MongoLoader          # future
```

### File formats

```text
FileReader
├── CSVReader            # V1
├── ParquetReader        # V2
└── JSONReader           # future
```

Adding an adapter should not require changing the loader core or the application-team workflow.

---

## 13. Repository ownership

Recommended organization:

```text
GitHub Enterprise
|
+-- shared-data-seeding/
|     +-- .github/workflows/seed.yml
|     +-- k8s/
|     +-- examples/
|
+-- shared-data-loader/
|     +-- src/data_loader/
|     +-- helm/
|     +-- tests/
|
+-- application-a/
|     +-- .github/data/data-loader.yaml
|
+-- application-b/
|     +-- .github/data/data-loader.yaml
```

Application teams consume:

```yaml
jobs:
  seed-data:
    uses: company/shared-data-seeding/.github/workflows/seed.yml@v2
    with:
      environment: ${{ needs.create-environment.outputs.name }}
      manifest: .github/data/data-loader.yaml
    secrets:
      KUBE_CONFIG: ${{ secrets.KUBE_CONFIG }}
```

The workflow is the **stable public interface**. The loader implementation can evolve independently.

---

## 14. V1 implementation

### GCS -> Cloud SQL

```text
GCS
 |
 | GCS SDK + Workload Identity
 v
Data Loader
 |
 | CSV
 v
Postgres COPY
 |
 v
Cloud SQL PostgreSQL
```

### S3 -> MySQL

```text
S3
 |
 | AWS SDK + IAM/Web Identity
 v
Data Loader
 |
 | CSV
 v
MySQL LOAD DATA
 |
 v
MySQL
```

---

## 15. What is deliberately not included

- Spark
- Dataset generation
- Dataset catalog
- Environment provisioning
- Data transformation
- PII generation/masking
- Centralized storage ownership

Those are separate concerns in the existing platform.

---

## 16. Recommended implementation roadmap

### Phase 1
- Manifest validation
- GCS adapter
- S3 adapter
- PostgreSQL adapter
- MySQL adapter
- CSV reader
- Dependency ordering
- Kubernetes Job
- Basic checkpoint
- Row-count validation

### Phase 2
- Parallel table loading
- Streaming/multipart loading
- Better checkpoint persistence
- Metrics
- Structured logs
- Load duration metrics
- Detailed failure reporting

### Phase 3
- Parquet
- Azure Blob
- Additional databases
- Snapshot-based loading
- Dataset/file integrity checks

---

## 17. Key design principle

> **Application teams specify WHAT and WHERE. The platform owns HOW.**

Example:

```text
WHAT:
payments dataset

WHERE:
GCS gs://team-data/payments/v5

TARGET:
Cloud SQL PostgreSQL

TABLES:
customer
account
transaction

ORDER:
customer -> account -> transaction
```

The platform decides:

```text
How to authenticate
How to read
How to parallelize
How to bulk load
How to retry
How to checkpoint
How to validate
How to observe
```
