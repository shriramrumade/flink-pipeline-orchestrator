# Cloud-Agnostic Data Loading Platform

This package contains two repositories plus design documentation.

## Repositories

### shared-data-loader
Reusable data-loading engine:
- GCS -> PostgreSQL / Cloud SQL
- S3 -> MySQL
- Adapter-based storage and database interfaces
- Kubernetes Job deployment
- Manifest-driven ordering
- Checkpoint and validation

### shared-data-seeding
Reusable GitHub Actions workflow:
- Stable interface for application teams
- Validates application-owned manifests
- Launches the loader Job in the existing ephemeral environment
- Monitors and reports the result

### docs
Architecture, component, workflow, sequence, security, extensibility, and implementation diagrams.
