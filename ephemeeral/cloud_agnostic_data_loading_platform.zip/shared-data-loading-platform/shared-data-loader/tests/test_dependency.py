from data_loader.core.dependency import ordered_tables

def test_orders_dependencies():
    tables = [
        {"name": "transaction", "order": 3, "dependsOn": ["account"]},
        {"name": "account", "order": 2, "dependsOn": ["customer"]},
        {"name": "customer", "order": 1},
    ]
    assert [x["name"] for x in ordered_tables(tables)] == [
        "customer", "account", "transaction"
    ]
