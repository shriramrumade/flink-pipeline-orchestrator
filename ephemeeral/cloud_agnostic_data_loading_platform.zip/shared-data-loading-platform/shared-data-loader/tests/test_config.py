import pytest
from data_loader.config import validate_manifest

def test_rejects_unknown_storage():
    with pytest.raises(ValueError):
        validate_manifest({
            "version": "1",
            "source": {"type": "azure", "bucket": "x"},
            "target": {"type": "postgres"},
            "tables": [{"name": "t", "file": "t.csv"}],
        })
