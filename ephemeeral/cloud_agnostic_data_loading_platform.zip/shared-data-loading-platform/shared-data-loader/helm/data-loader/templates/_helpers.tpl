{{- define "data-loader.fullname" -}}
{{- printf "%s-data-loader" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
