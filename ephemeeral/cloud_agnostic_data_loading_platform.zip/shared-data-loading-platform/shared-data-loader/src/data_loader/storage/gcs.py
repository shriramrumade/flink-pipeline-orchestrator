from google.cloud import storage
from .base import ObjectStore

class GCSObjectStore(ObjectStore):
    def __init__(self, bucket: str):
        self.client = storage.Client()
        self.bucket = self.client.bucket(bucket)

    def open(self, path: str):
        return self.bucket.blob(path).open("rb")

    def download(self, path: str, destination: str) -> None:
        self.bucket.blob(path).download_to_filename(destination)

    def exists(self, path: str) -> bool:
        return self.bucket.blob(path).exists()
