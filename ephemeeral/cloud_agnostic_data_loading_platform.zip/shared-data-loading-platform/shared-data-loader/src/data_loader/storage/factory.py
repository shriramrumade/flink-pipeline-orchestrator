from .gcs import GCSObjectStore
from .s3 import S3ObjectStore

def create_object_store(config: dict):
    provider = config["type"]
    if provider == "gcs":
        return GCSObjectStore(config["bucket"])
    if provider == "s3":
        return S3ObjectStore(config["bucket"])
    raise ValueError(f"Unsupported storage provider: {provider}")
