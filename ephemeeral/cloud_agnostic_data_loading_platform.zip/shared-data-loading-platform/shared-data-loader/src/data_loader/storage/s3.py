import boto3
from botocore.exceptions import ClientError
from .base import ObjectStore

class S3ObjectStore(ObjectStore):
    def __init__(self, bucket: str):
        self.client = boto3.client("s3")
        self.bucket = bucket

    def open(self, path: str):
        return self.client.get_object(Bucket=self.bucket, Key=path)["Body"]

    def download(self, path: str, destination: str) -> None:
        self.client.download_file(self.bucket, path, destination)

    def exists(self, path: str) -> bool:
        try:
            self.client.head_object(Bucket=self.bucket, Key=path)
            return True
        except ClientError:
            return False
