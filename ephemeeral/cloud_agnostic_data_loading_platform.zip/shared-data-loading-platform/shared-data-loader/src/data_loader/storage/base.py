from abc import ABC, abstractmethod
from typing import BinaryIO

class ObjectStore(ABC):
    @abstractmethod
    def open(self, path: str) -> BinaryIO:
        raise NotImplementedError

    @abstractmethod
    def download(self, path: str, destination: str) -> None:
        raise NotImplementedError

    @abstractmethod
    def exists(self, path: str) -> bool:
        raise NotImplementedError
