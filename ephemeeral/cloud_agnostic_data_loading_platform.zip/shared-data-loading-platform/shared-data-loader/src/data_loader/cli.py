import argparse
from .config import load_manifest, env_db_config
from .storage.factory import create_object_store
from .database.factory import create_database_loader
from .core.loader import DataLoader

def main():
    parser = argparse.ArgumentParser(description="Cloud-agnostic dataset loader")
    parser.add_argument("--manifest", required=True)
    args = parser.parse_args()

    manifest = load_manifest(args.manifest)
    storage = create_object_store(manifest["source"])
    db_config = env_db_config(manifest)
    database = create_database_loader(db_config)

    try:
        DataLoader(storage, database, manifest).load()
    finally:
        database.close()

if __name__ == "__main__":
    main()
