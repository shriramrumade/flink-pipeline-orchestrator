import os
import yaml

def load_manifest(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    validate_manifest(data)
    return data

def validate_manifest(manifest: dict) -> None:
    if manifest.get("version") != "1":
        raise ValueError("manifest.version must be '1'")

    source = manifest.get("source") or {}
    if source.get("type") not in {"gcs", "s3"}:
        raise ValueError("source.type must be one of: gcs, s3")

    if not source.get("bucket"):
        raise ValueError("source.bucket is required")

    target = manifest.get("target") or {}
    if target.get("type") not in {"postgres", "mysql"}:
        raise ValueError("target.type must be one of: postgres, mysql")

    tables = manifest.get("tables")
    if not tables:
        raise ValueError("at least one table is required")

    names = set()
    for table in tables:
        for key in ("name", "file"):
            if not table.get(key):
                raise ValueError(f"table.{key} is required")
        if table["name"] in names:
            raise ValueError(f"duplicate table: {table['name']}")
        names.add(table["name"])

def env_db_config(manifest: dict) -> dict:
    target = manifest["target"]
    db_type = target["type"]
    defaults = {"postgres": 5432, "mysql": 3306}
    return {
        "type": db_type,
        "host": os.environ["DB_HOST"],
        "port": int(os.getenv("DB_PORT", defaults[db_type])),
        "database": os.environ.get("DB_NAME", target.get("database")),
        "user": os.environ["DB_USER"],
        "password": os.environ["DB_PASSWORD"],
    }
