import os
import tempfile
from .dependency import ordered_tables
from .checkpoint import CheckpointStore

class DataLoader:
    def __init__(self, storage, database, manifest):
        self.storage = storage
        self.database = database
        self.manifest = manifest
        self.source = manifest["source"]
        self.options = manifest.get("options", {})
        self.checkpoint = CheckpointStore(
            self.options.get("checkpoint_path", "/tmp/data-loader-checkpoint.json")
        )

    def _object_path(self, filename: str) -> str:
        prefix = self.source.get("prefix", "").strip("/")
        return f"{prefix}/{filename}" if prefix else filename

    def load(self) -> None:
        for table in ordered_tables(self.manifest["tables"]):
            name = table["name"]
            if self.checkpoint.is_complete(name):
                print(f"[SKIP] {name}: checkpoint says COMPLETE")
                continue

            path = self._object_path(table["file"])
            print(f"[START] {name} <- {path}")

            if not self.storage.exists(path):
                raise FileNotFoundError(f"Dataset object not found: {path}")

            suffix = os.path.splitext(table["file"])[1]
            fd, local_path = tempfile.mkstemp(suffix=suffix)
            os.close(fd)

            try:
                self.storage.download(path, local_path)
                self.database.load_file(name, local_path, table.get("options", {}))
                count = self.database.validate_table(name)
                print(f"[COMPLETE] {name}: {count} rows")
                self.checkpoint.mark_complete(name)
            finally:
                if os.path.exists(local_path):
                    os.remove(local_path)
