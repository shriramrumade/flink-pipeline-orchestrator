def ordered_tables(tables: list[dict]) -> list[dict]:
    """Topologically order tables using dependsOn and order.

    If no dependsOn values are provided, order is used.
    """
    by_name = {t["name"]: t for t in tables}
    visiting, visited, result = set(), set(), []

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            raise ValueError(f"Dependency cycle detected at {name}")
        if name not in by_name:
            raise ValueError(f"Unknown dependency: {name}")
        visiting.add(name)
        for dep in by_name[name].get("dependsOn", []) or []:
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        result.append(by_name[name])

    for table in sorted(tables, key=lambda x: x.get("order", 0)):
        visit(table["name"])
    return result
