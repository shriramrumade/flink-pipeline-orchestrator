import json
from pathlib import Path

class CheckpointStore:
    def __init__(self, path="/tmp/data-loader-checkpoint.json"):
        self.path = Path(path)
        self.state = {}
        if self.path.exists():
            self.state = json.loads(self.path.read_text())

    def is_complete(self, table: str) -> bool:
        return self.state.get(table) == "COMPLETE"

    def mark_complete(self, table: str) -> None:
        self.state[table] = "COMPLETE"
        self.path.write_text(json.dumps(self.state, indent=2))
