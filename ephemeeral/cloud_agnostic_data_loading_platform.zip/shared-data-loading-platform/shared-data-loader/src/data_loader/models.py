from dataclasses import dataclass
from typing import Any

@dataclass
class TableSpec:
    name: str
    file: str
    format: str = "csv"
    order: int = 0
    depends_on: list[str] | None = None
    options: dict[str, Any] | None = None
