import re
import psycopg
from .base import DatabaseLoader

_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

def safe_ident(value: str) -> str:
    if not _IDENT.match(value):
        raise ValueError(f"Unsafe SQL identifier: {value}")
    return value

class PostgresLoader(DatabaseLoader):
    def __init__(self, host, port, database, user, password):
        self.connection = psycopg.connect(
            host=host, port=port, dbname=database, user=user, password=password
        )

    def load_file(self, table, file_path, options):
        table = safe_ident(table)
        delimiter = options.get("delimiter", ",")
        with self.connection.cursor() as cur:
            with open(file_path, "rb") as fh:
                with cur.copy(
                    f"COPY {table} FROM STDIN WITH (FORMAT csv, HEADER true, DELIMITER '{delimiter}')"
                ) as copy:
                    while chunk := fh.read(1024 * 1024):
                        copy.write(chunk)
        self.connection.commit()

    def validate_table(self, table):
        table = safe_ident(table)
        with self.connection.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            return cur.fetchone()[0]

    def close(self):
        self.connection.close()
