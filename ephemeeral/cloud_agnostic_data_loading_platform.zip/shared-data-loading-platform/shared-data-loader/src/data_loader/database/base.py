from abc import ABC, abstractmethod

class DatabaseLoader(ABC):
    @abstractmethod
    def load_file(self, table: str, file_path: str, options: dict) -> None:
        raise NotImplementedError

    @abstractmethod
    def validate_table(self, table: str) -> int:
        raise NotImplementedError

    @abstractmethod
    def close(self) -> None:
        raise NotImplementedError
