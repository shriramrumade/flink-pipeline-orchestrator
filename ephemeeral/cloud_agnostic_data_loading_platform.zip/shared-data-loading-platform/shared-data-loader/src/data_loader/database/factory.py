from .postgres import PostgresLoader
from .mysql import MySQLLoader

def create_database_loader(config: dict):
    db_type = config["type"]
    args = (
        config["host"], config["port"], config["database"],
        config["user"], config["password"]
    )
    if db_type == "postgres":
        return PostgresLoader(*args)
    if db_type == "mysql":
        return MySQLLoader(*args)
    raise ValueError(f"Unsupported database type: {db_type}")
