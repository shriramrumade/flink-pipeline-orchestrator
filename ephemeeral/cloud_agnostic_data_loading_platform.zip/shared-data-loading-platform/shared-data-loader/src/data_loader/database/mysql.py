import re
import pymysql
from .base import DatabaseLoader

_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

def safe_ident(value: str) -> str:
    if not _IDENT.match(value):
        raise ValueError(f"Unsafe SQL identifier: {value}")
    return value

class MySQLLoader(DatabaseLoader):
    def __init__(self, host, port, database, user, password):
        self.connection = pymysql.connect(
            host=host, port=port, database=database, user=user,
            password=password, local_infile=True, autocommit=False
        )

    def load_file(self, table, file_path, options):
        table = safe_ident(table)
        delimiter = options.get("delimiter", ",")
        sql = (
            f"LOAD DATA LOCAL INFILE %s INTO TABLE {table} "
            f"FIELDS TERMINATED BY %s OPTIONALLY ENCLOSED BY '\"' "
            "IGNORE 1 LINES"
        )
        with self.connection.cursor() as cur:
            cur.execute(sql, (file_path, delimiter))
        self.connection.commit()

    def validate_table(self, table):
        table = safe_ident(table)
        with self.connection.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            return cur.fetchone()[0]

    def close(self):
        self.connection.close()
