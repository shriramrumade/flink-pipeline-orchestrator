# Shared Data Loader

Cloud-agnostic data loading engine for ephemeral environments.

## Supported in v1

- GCS -> PostgreSQL / Cloud SQL
- S3 -> MySQL
- CSV input
- Manifest-driven table ordering
- Storage and database adapter interfaces
- Kubernetes Job deployment
- No credentials in manifests
- Designed for future Azure Blob, Parquet, Oracle, SQL Server, etc.

## Quick start

```bash
pip install -r requirements.txt

export DB_HOST=localhost
export DB_PORT=5432
export DB_NAME=payments
export DB_USER=postgres
export DB_PASSWORD=...

python -m data_loader.cli --manifest examples/gcs-postgres.yaml
```

The production deployment is intended to run the container as a Kubernetes Job. Cloud access should use workload identity / IAM / managed identity rather than static credentials in the manifest.
