# Shared Data Seeding

This repository is the **stable platform-facing interface** for application teams.

Application teams provide a manifest and invoke the reusable workflow. The workflow launches the internal `shared-data-loader` Kubernetes Job in the already-created ephemeral environment.

Application teams do not need to know how GCS/S3 access, bulk loading, retries, or database adapters are implemented.
