
# Implementation Steps

1. Start Oracle with Docker
cd docker
docker compose up -d

2. Wait ~1 minute for Oracle XE startup

3. Create schema
Run schema/create_tables.sql in Oracle

4. Install Python libraries
pip install oracledb faker

5. Load initial dataset
python loader/load_sample_data.py

6. Learn metadata
python learning/metadata_learning.py

7. Generate synthetic dataset
python generator/synthetic_generator.py

Tables maintain referential integrity:
CUSTOMER → CARD_ACCOUNT → CARD → TRANSACTION
MERCHANT → TRANSACTION
