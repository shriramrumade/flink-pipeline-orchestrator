
import oracledb

conn = oracledb.connect(
    user="testuser",
    password="testpass",
    dsn="localhost:1521/XEPDB1"
)

cur = conn.cursor()
schema = {}

cur.execute("SELECT table_name FROM user_tables")
tables = [t[0] for t in cur.fetchall()]

for table in tables:
    cur.execute(f"SELECT column_name,data_type FROM user_tab_columns WHERE table_name='{table}'")
    cols = cur.fetchall()
    schema[table] = {"columns": cols}

print("Learned Schema:")
print(schema)
