
import random
from faker import Faker

fake = Faker()

customers=[]
accounts=[]
cards=[]
transactions=[]
merchants=[]

for i in range(1,50):
    merchants.append({"MERCHANT_ID":i,"NAME":fake.company(),"CATEGORY":random.choice(["RETAIL","TRAVEL","FOOD"])})

for i in range(1,1000):
    customers.append({"CUSTOMER_ID":i,"NAME":fake.name(),"EMAIL":fake.email(),"SEGMENT":random.choice(["MASS","PREMIUM","BUSINESS"])})

aid=1
for c in customers:
    for _ in range(random.randint(1,2)):
        accounts.append({"ACCOUNT_ID":aid,"CUSTOMER_ID":c["CUSTOMER_ID"],"CREDIT_LIMIT":random.randint(2000,50000)})
        aid+=1

cid=1
for acc in accounts:
    for _ in range(random.randint(1,2)):
        cards.append({"CARD_ID":cid,"ACCOUNT_ID":acc["ACCOUNT_ID"],"NETWORK":random.choice(["VISA","MASTERCARD","AMEX"]),"ISSUER":random.choice(["CHASE","CITI","BMO"])})
        cid+=1

tid=1
for card in cards:
    for _ in range(random.randint(5,20)):
        transactions.append({"TXN_ID":tid,"CARD_ID":card["CARD_ID"],"MERCHANT_ID":random.choice(merchants)["MERCHANT_ID"],"AMOUNT":random.randint(10,2000)})
        tid+=1

print("Generated sizes")
print(len(customers),"customers")
print(len(accounts),"accounts")
print(len(cards),"cards")
print(len(transactions),"transactions")
