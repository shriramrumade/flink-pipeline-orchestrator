
import random
import oracledb
from faker import Faker

fake = Faker()

conn = oracledb.connect(
    user="testuser",
    password="testpass",
    dsn="localhost:1521/XEPDB1"
)

cur = conn.cursor()

for i in range(1,101):
    cur.execute("INSERT INTO CUSTOMER VALUES (:1,:2,:3,:4)",
        (i, fake.name(), fake.email(), random.choice(["MASS","PREMIUM","BUSINESS"])))

for i in range(1,21):
    cur.execute("INSERT INTO MERCHANT VALUES (:1,:2,:3)",
        (i, fake.company(), random.choice(["RETAIL","TRAVEL","FOOD"])))

for i in range(1,151):
    cur.execute("INSERT INTO CARD_ACCOUNT VALUES (:1,:2,:3)",
        (i, random.randint(1,100), random.randint(2000,50000)))

for i in range(1,201):
    cur.execute("INSERT INTO CARD VALUES (:1,:2,:3,:4)",
        (i, random.randint(1,150), random.choice(["VISA","MASTERCARD","AMEX"]), random.choice(["CHASE","CITI","BMO"])))

for i in range(1,501):
    cur.execute("INSERT INTO TRANSACTION VALUES (:1,:2,:3,:4,SYSDATE)",
        (i, random.randint(1,200), random.randint(1,20), random.randint(10,1000)))

conn.commit()
print("Sample data loaded")
