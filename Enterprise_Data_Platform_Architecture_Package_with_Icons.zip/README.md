# Enterprise Data Platform Architecture (Package v2)

This package contains:
- **Enterprise_Data_Platform_Confluence.drawio**: Editable diagrams.net / draw.io file (Confluence compatible)
- **Enterprise_Data_Platform_Architecture.png**: Rendered image version of the architecture diagram
- **icons/**: Icon files used for diagramming (SVG placeholders)

## Notes
- For production/official brand icons, replace SVG placeholders in `icons/` with official assets from vendor sites.
- React UI authenticates with Okta.
- API Gateway validates Okta tokens and routes to microservices.
- Spring Boot microservices: Account, Conditioning, Search, Reservation
- Python microservice: Data Pipeline + SDR (pulls from SORs -> S3 -> Elasticsearch)
- Shared/common services: Vault, Redis, Couchbase, Elasticsearch, S3
- External Systems of Record (SORs): Kafka, Oracle DB, Mainframe, etc.
