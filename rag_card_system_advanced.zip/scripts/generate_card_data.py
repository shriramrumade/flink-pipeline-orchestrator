
import random
import uuid
from elasticsearch import Elasticsearch, helpers
from faker import Faker
from tqdm import tqdm

fake = Faker()
es = Elasticsearch("http://localhost:9200")

INDEX="card_inventory"

issuers=["Chase","Citi","BMO","Bank of America","Capital One"]
networks=["Visa","Mastercard","Amex"]

def record():

    credit=random.randint(2000,50000)

    return {
        "_index":INDEX,
        "_source":{
            "card_id":str(uuid.uuid4()),
            "issuer":random.choice(issuers),
            "network":random.choice(networks),
            "credit_limit":credit,
            "reserved":False
        }
    }

def generate(total=100000):

    actions=[]

    for i in tqdm(range(total)):

        actions.append(record())

        if len(actions)==2000:

            helpers.bulk(es,actions)
            actions=[]

    if actions:
        helpers.bulk(es,actions)

if __name__=="__main__":
    generate()
