
from app.llm_client import ask_llm

def generate_query(prompt, context):

    system_prompt = f'''
You are an Elasticsearch query generator.

Schema Knowledge:
{context}

User Prompt:
{prompt}

Generate Elasticsearch DSL JSON query.
'''

    return ask_llm(system_prompt)
