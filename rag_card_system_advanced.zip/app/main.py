
from fastapi import FastAPI
from app.rag_retriever import retrieve_context
from app.query_generator import generate_query
from app.card_service import search_cards
from app.reservation_service import reserve

app = FastAPI()

@app.get("/reserve")

def reserve_cards(prompt:str,user:str):

    context = retrieve_context(prompt)

    query = generate_query(prompt, context)

    cards = search_cards(query)

    reserved = reserve(cards,user)

    return {
        "context":context,
        "query":query,
        "reserved_cards":reserved
    }
