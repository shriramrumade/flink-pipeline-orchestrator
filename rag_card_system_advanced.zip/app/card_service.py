
from app.elastic_client import get_es

def search_cards(query):

    es = get_es()

    res = es.search(index="card_inventory", body=query)

    return [hit["_source"] for hit in res["hits"]["hits"]]
