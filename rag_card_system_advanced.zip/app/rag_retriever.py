
from app.elastic_client import get_es
from app.embedding import embed

def retrieve_context(prompt):

    es = get_es()

    vector = embed(prompt)

    query = {
        "knn": {
            "field": "embedding",
            "query_vector": vector,
            "k": 5,
            "num_candidates": 100
        }
    }

    res = es.search(index="rag_knowledge", body=query)

    context = [hit["_source"]["text"] for hit in res["hits"]["hits"]]

    return "\n".join(context)
