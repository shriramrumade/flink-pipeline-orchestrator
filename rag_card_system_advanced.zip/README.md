
# Local RAG + Elasticsearch + Ollama System

This project demonstrates a **local Retrieval-Augmented Generation (RAG) system** that:

- Scans Elasticsearch data automatically
- Builds knowledge dynamically
- Uses a local LLM via Ollama
- Generates Elasticsearch queries from natural language prompts
- Supports large datasets (1M+ records)

Everything runs **locally on your Mac**.

---

# 1. Install prerequisites

Install:

Docker Desktop
Python 3.10+
Ollama

Mac commands:

brew install python
brew install ollama

---

# 2. Start Elasticsearch

docker compose up -d

Verify:

curl http://localhost:9200

---

# 3. Install Python dependencies

pip install -r requirements.txt

---

# 4. Create Elasticsearch indices

python scripts/create_indices.py

---

# 5. Generate synthetic dataset (1M records optional)

python scripts/generate_card_data.py

---

# 6. Build RAG knowledge automatically from database

python scripts/build_schema_graph.py

---

# 7. Start Ollama

ollama serve

Download model:

ollama pull llama3

---

# 8. Start API

uvicorn app.main:app --reload

Open Swagger:

http://localhost:8000/docs

---

# Example Prompt

Give me 20 Chase Visa cards with credit limit above 20000

Pipeline:

Prompt -> RAG retrieval -> LLM reasoning -> Elasticsearch query -> results

---

# Architecture

User Prompt
     |
FastAPI API
     |
Embedding Model
     |
Vector Search (rag_knowledge)
     |
LLM (Ollama + Llama3)
     |
Generated Elasticsearch Query
     |
Search card_inventory
     |
Return / Reserve Cards

---

This project supports:

- 50+ attributes
- Multi-tenant architecture
- Automatic knowledge generation
- Local LLM reasoning
