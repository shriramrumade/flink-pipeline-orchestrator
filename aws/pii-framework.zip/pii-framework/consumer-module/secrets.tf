resource "aws_secretsmanager_secret" "db_credentials" {
  name        = "pii-framework/${var.team_name}/db-credentials"
  description = "DB credentials used by the ephemeral PII scrubbing Glue job. Read-only access limited to the Glue execution role."
  tags        = var.tags
}

resource "aws_secretsmanager_secret_version" "db_credentials" {
  secret_id = aws_secretsmanager_secret.db_credentials.id
  secret_string = jsonencode({
    engine   = var.db_engine
    host     = var.db_host
    port     = var.db_port
    dbname   = var.db_name
    username = var.db_username
    password = var.db_password
  })
}

# Explicit resource policy: only the Glue execution role in THIS account can
# read this secret. No cross-account access — the platform account never
# touches these credentials.
resource "aws_secretsmanager_secret_policy" "db_credentials" {
  secret_arn = aws_secretsmanager_secret.db_credentials.arn
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AllowGlueRoleOnly"
        Effect    = "Allow"
        Principal = { AWS = aws_iam_role.glue_execution.arn }
        Action    = "secretsmanager:GetSecretValue"
        Resource  = "*"
      }
    ]
  })
}
