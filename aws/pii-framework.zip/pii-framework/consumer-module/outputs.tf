output "cross_account_role_arn" {
  description = "Give this ARN + your external_id back to the platform portal to complete onboarding"
  value       = aws_iam_role.platform_access.arn
}

output "state_machine_arn" {
  value = aws_sfn_state_machine.pii_extraction.arn
}

output "synthetic_output_bucket" {
  value = aws_s3_bucket.synthetic_output.bucket
}

output "glue_connection_name" {
  value = aws_glue_connection.db.name
}

output "db_secret_arn" {
  value     = aws_secretsmanager_secret.db_credentials.arn
  sensitive = true
}
