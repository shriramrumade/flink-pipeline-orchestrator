# ---------------------------------------------------------------------------
# 1. Cross-account role the PLATFORM account assumes to trigger workflows and
#    read back completion status. Scoped tightly with an external ID.
# ---------------------------------------------------------------------------
data "aws_iam_policy_document" "platform_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::${var.platform_account_id}:root"]
    }
    condition {
      test     = "StringEquals"
      variable = "sts:ExternalId"
      values   = [var.external_id]
    }
  }
}

resource "aws_iam_role" "platform_access" {
  name               = "pii-framework-${var.team_name}-platform-access"
  assume_role_policy = data.aws_iam_policy_document.platform_trust.json
  tags               = var.tags
}

# The platform account can only start/describe THIS team's state machine —
# nothing else in the account.
resource "aws_iam_role_policy" "platform_access" {
  name = "platform-access-policy"
  role = aws_iam_role.platform_access.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "states:StartExecution",
          "states:DescribeExecution",
          "states:StopExecution"
        ]
        Resource = [
          aws_sfn_state_machine.pii_extraction.arn,
          "${aws_sfn_state_machine.pii_extraction.arn}:*"
        ]
      }
    ]
  })
}

# ---------------------------------------------------------------------------
# 2. Glue execution role — used by the EPHEMERAL job created per run.
#    Read-only to source DB secret, write-only to synthetic/ prefix, read
#    the shared script + library from the platform's script bucket.
# ---------------------------------------------------------------------------
data "aws_iam_policy_document" "glue_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["glue.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "glue_execution" {
  name               = "pii-framework-${var.team_name}-glue-execution"
  assume_role_policy = data.aws_iam_policy_document.glue_trust.json
  tags               = var.tags
}

resource "aws_iam_role_policy" "glue_execution" {
  name = "glue-execution-policy"
  role = aws_iam_role.glue_execution.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ReadSharedScriptAndLibrary"
        Effect = "Allow"
        Action = ["s3:GetObject", "s3:ListBucket"]
        Resource = [
          "arn:aws:s3:::${var.platform_script_bucket}",
          "arn:aws:s3:::${var.platform_script_bucket}/*"
        ]
      },
      {
        Sid      = "WriteSyntheticOutputOnly"
        Effect   = "Allow"
        Action   = ["s3:PutObject", "s3:GetObject", "s3:DeleteObject", "s3:ListBucket"]
        Resource = [aws_s3_bucket.synthetic_output.arn, "${aws_s3_bucket.synthetic_output.arn}/*"]
      },
      {
        Sid      = "ReadDbSecret"
        Effect   = "Allow"
        Action   = ["secretsmanager:GetSecretValue"]
        Resource = [aws_secretsmanager_secret.db_credentials.arn]
      },
      {
        Sid    = "GlueVpcNetworking"
        Effect = "Allow"
        Action = [
          "ec2:CreateNetworkInterface",
          "ec2:DeleteNetworkInterface",
          "ec2:DescribeNetworkInterfaces",
          "ec2:DescribeSubnets",
          "ec2:DescribeSecurityGroups",
          "ec2:DescribeVpcEndpoints",
          "ec2:DescribeRouteTables",
          "ec2:DescribeVpcAttribute"
        ]
        Resource = "*"
      },
      {
        Sid      = "GlueLogging"
        Effect   = "Allow"
        Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "arn:aws:logs:*:*:/aws-glue/*"
      }
    ]
  })
}

# ---------------------------------------------------------------------------
# 3. Step Functions execution role — needs permission to create/run/delete
#    the ephemeral Glue job, and to pass the glue_execution role to it.
# ---------------------------------------------------------------------------
data "aws_iam_policy_document" "sfn_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["states.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "step_functions" {
  name               = "pii-framework-${var.team_name}-stepfunctions"
  assume_role_policy = data.aws_iam_policy_document.sfn_trust.json
  tags               = var.tags
}

resource "aws_iam_role_policy" "step_functions" {
  name = "stepfunctions-policy"
  role = aws_iam_role.step_functions.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ManageEphemeralGlueJob"
        Effect = "Allow"
        Action = [
          "glue:CreateJob",
          "glue:DeleteJob",
          "glue:GetJob",
          "glue:StartJobRun",
          "glue:GetJobRun",
          "glue:GetJobRuns",
          "glue:BatchStopJobRun"
        ]
        Resource = "*"
      },
      {
        Sid      = "PassGlueExecutionRole"
        Effect   = "Allow"
        Action   = ["iam:PassRole"]
        Resource = aws_iam_role.glue_execution.arn
      },
      {
        Sid      = "EventRuleForCallbacks"
        Effect   = "Allow"
        Action   = ["events:PutEvents"]
        Resource = "*"
      }
    ]
  })
}
