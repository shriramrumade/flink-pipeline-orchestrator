resource "aws_s3_bucket" "synthetic_output" {
  bucket = "pii-framework-${var.team_name}-synthetic-output"
  tags   = var.tags
}

resource "aws_s3_bucket_public_access_block" "synthetic_output" {
  bucket                  = aws_s3_bucket.synthetic_output.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "synthetic_output" {
  bucket = aws_s3_bucket.synthetic_output.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.team.arn
    }
    bucket_key_enabled = true
  }
}

resource "aws_kms_key" "team" {
  description             = "KMS key for ${var.team_name} synthetic data bucket"
  deletion_window_in_days = 30
  enable_key_rotation     = true
  tags                    = var.tags
}

# synthetic/ prefix — the actual deliverable, retained per your data
# lifecycle policy (defaulted here to 90 days, override as needed).
resource "aws_s3_bucket_lifecycle_configuration" "synthetic_output" {
  bucket = aws_s3_bucket.synthetic_output.id

  rule {
    id     = "expire-synthetic-output"
    status = "Enabled"
    filter {
      prefix = "synthetic/"
    }
    expiration {
      days = 90
    }
  }

  # Safety net only — the job does not write here under normal operation,
  # but if a future job version ever does stage intermediate data, it
  # self-expires quickly rather than lingering.
  rule {
    id     = "expire-any-staging-artifacts"
    status = "Enabled"
    filter {
      prefix = "staging/"
    }
    expiration {
      days = 1
    }
  }
}

resource "aws_s3_bucket_versioning" "synthetic_output" {
  bucket = aws_s3_bucket.synthetic_output.id
  versioning_configuration {
    status = "Enabled"
  }
}
