# Durable: the JDBC connection definition and its security group.
# NOT durable: the Glue Job itself — that's created and destroyed per
# extraction run by the Step Functions state machine (see stepfunctions.tf).

resource "aws_security_group" "glue" {
  name        = "pii-framework-${var.team_name}-glue"
  description = "Glue ENIs for PII scrubbing job - egress to DB only"
  vpc_id      = var.vpc_id

  egress {
    description = "To source database"
    from_port   = var.db_port
    to_port     = var.db_port
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"] # narrow to your DB's actual CIDR/SG in prod
  }

  # Glue requires a self-referencing rule for internal job communication
  egress {
    description = "Self-referencing for Glue internal communication"
    from_port   = 0
    to_port     = 65535
    protocol    = "tcp"
    self        = true
  }
  ingress {
    from_port = 0
    to_port   = 65535
    protocol  = "tcp"
    self      = true
  }

  tags = var.tags
}

resource "aws_glue_connection" "db" {
  name = "pii-framework-${var.team_name}-db-connection"

  connection_type = "JDBC"

  connection_properties = {
    JDBC_CONNECTION_URL = local.jdbc_url
    SECRET_ID            = aws_secretsmanager_secret.db_credentials.name
    JDBC_ENFORCE_SSL     = "true"
  }

  physical_connection_requirements {
    availability_zone      = data.aws_subnet.selected.availability_zone
    security_group_id_list = [aws_security_group.glue.id]
    subnet_id               = var.subnet_ids[0]
  }

  tags = var.tags
}

data "aws_subnet" "selected" {
  id = var.subnet_ids[0]
}

locals {
  jdbc_url = {
    mysql     = "jdbc:mysql://${var.db_host}:${var.db_port}/${var.db_name}"
    postgres  = "jdbc:postgresql://${var.db_host}:${var.db_port}/${var.db_name}"
    oracle    = "jdbc:oracle:thin:@${var.db_host}:${var.db_port}/${var.db_name}"
    sqlserver = "jdbc:sqlserver://${var.db_host}:${var.db_port};databaseName=${var.db_name}"
  }[var.db_engine]
}
