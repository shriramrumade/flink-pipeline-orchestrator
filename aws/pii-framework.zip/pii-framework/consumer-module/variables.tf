variable "team_name" {
  description = "Short, unique name for this app team, e.g. 'alpha'"
  type        = string
}

variable "platform_account_id" {
  description = "AWS account ID of the platform team (for cross-account trust)"
  type        = string
}

variable "external_id" {
  description = "Unique external ID issued by the platform portal during onboarding"
  type        = string
  sensitive   = true
}

variable "platform_script_bucket" {
  description = "Platform-owned S3 bucket holding the shared Glue script + PII library wheel"
  type        = string
}

variable "platform_script_key" {
  description = "S3 key (with version suffix) of the shared Glue script, e.g. pii_extract_scrub_v1.2.0.py"
  type        = string
  default     = "pii_extract_scrub_v1.0.0.py"
}

# --- Database connection (MySQL for the first onboarded team) ---
variable "db_engine" {
  description = "Database engine — drives JDBC URL construction in the Glue job"
  type        = string
  default     = "mysql"
  validation {
    condition     = contains(["mysql", "postgres", "oracle", "sqlserver"], var.db_engine)
    error_message = "db_engine must be one of: mysql, postgres, oracle, sqlserver."
  }
}

variable "db_host" {
  type        = string
  description = "DB host/endpoint, reachable from the VPC subnets given below"
}

variable "db_port" {
  type    = number
  default = 3306
}

variable "db_name" {
  type = string
}

variable "db_username" {
  type      = string
  sensitive = true
}

variable "db_password" {
  type      = string
  sensitive = true
}

# --- Networking (must have connectivity to db_host) ---
variable "vpc_id" {
  type = string
}

variable "subnet_ids" {
  description = "Private subnets Glue will attach ENIs into"
  type        = list(string)
}

variable "platform_event_bus_arn" {
  description = "ARN of the platform account's central EventBridge bus, for completion callbacks"
  type        = string
}

variable "tags" {
  type    = map(string)
  default = {}
}
