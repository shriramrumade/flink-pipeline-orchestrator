resource "aws_sfn_state_machine" "pii_extraction" {
  name     = "pii-framework-${var.team_name}-extraction"
  role_arn = aws_iam_role.step_functions.arn

  definition = templatefile("${path.module}/../stepfunctions/pii_extraction_workflow.asl.json", {
    glue_role_arn        = aws_iam_role.glue_execution.arn
    script_location       = "s3://${var.platform_script_bucket}/${var.platform_script_key}"
    secret_arn            = aws_secretsmanager_secret.db_credentials.arn
    db_name               = var.db_name
    output_bucket          = aws_s3_bucket.synthetic_output.bucket
    glue_connection_name  = aws_glue_connection.db.name
    team_name             = var.team_name
    platform_event_bus_arn = var.platform_event_bus_arn
  })

  tags = var.tags
}

# Safety-net scheduled Lambda: catches any Glue job definition matching
# pii-extract-* that outlives its run (crashed state machine, throttling,
# etc.) and force-deletes it after 1 hour.
resource "aws_lambda_function" "orphan_cleanup" {
  function_name = "pii-framework-${var.team_name}-orphan-cleanup"
  role          = aws_iam_role.orphan_cleanup.arn
  handler       = "cleanup_orphaned_glue_jobs.handler"
  runtime       = "python3.12"
  timeout       = 60
  filename         = "${path.module}/../lambda/cleanup_orphaned_glue_jobs.zip"
  source_code_hash = filebase64sha256("${path.module}/../lambda/cleanup_orphaned_glue_jobs.zip")

  environment {
    variables = {
      JOB_NAME_PREFIX     = "pii-extract-"
      MAX_AGE_MINUTES     = "60"
    }
  }
  tags = var.tags
}

resource "aws_cloudwatch_event_rule" "orphan_cleanup_schedule" {
  name                = "pii-framework-${var.team_name}-orphan-cleanup"
  schedule_expression = "rate(1 hour)"
}

resource "aws_cloudwatch_event_target" "orphan_cleanup" {
  rule = aws_cloudwatch_event_rule.orphan_cleanup_schedule.name
  arn  = aws_lambda_function.orphan_cleanup.arn
}

resource "aws_lambda_permission" "orphan_cleanup_eventbridge" {
  statement_id  = "AllowEventBridgeInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.orphan_cleanup.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.orphan_cleanup_schedule.arn
}

data "aws_iam_policy_document" "orphan_cleanup_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "orphan_cleanup" {
  name               = "pii-framework-${var.team_name}-orphan-cleanup"
  assume_role_policy = data.aws_iam_policy_document.orphan_cleanup_trust.json
  tags               = var.tags
}

resource "aws_iam_role_policy" "orphan_cleanup" {
  name = "orphan-cleanup-policy"
  role = aws_iam_role.orphan_cleanup.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["glue:GetJobs", "glue:GetJobRuns", "glue:DeleteJob"]
        Resource = "*"
      },
      {
        Effect   = "Allow"
        Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "arn:aws:logs:*:*:*"
      },
      {
        Effect   = "Allow"
        Action   = ["sns:Publish"]
        Resource = "*"
      }
    ]
  })
}
