data "aws_iam_policy_document" "lambda_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "platform_lambda" {
  name               = "${var.platform_prefix}-lambda"
  assume_role_policy = data.aws_iam_policy_document.lambda_trust.json
  tags               = var.tags
}

resource "aws_iam_role_policy" "platform_lambda" {
  name = "platform-lambda-policy"
  role = aws_iam_role.platform_lambda.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "DynamoDbAccess"
        Effect = "Allow"
        Action = [
          "dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:UpdateItem",
          "dynamodb:Query", "dynamodb:DeleteItem"
        ]
        Resource = [
          aws_dynamodb_table.pii_metadata.arn,
          "${aws_dynamodb_table.pii_metadata.arn}/index/*"
        ]
      },
      {
        Sid      = "AssumeAppTeamRoles"
        Effect   = "Allow"
        Action   = ["sts:AssumeRole"]
        Resource = "arn:aws:iam::*:role/pii-framework-*-platform-access"
      },
      {
        Sid      = "Logging"
        Effect   = "Allow"
        Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "arn:aws:logs:*:*:*"
      }
    ]
  })
}

locals {
  lambda_functions = {
    onboard_team          = "onboard_team.handler"
    confirm_team          = "confirm_team.handler"
    certify_column        = "certify_column.handler"
    create_extract_request = "create_extract_request.handler"
    trigger_extraction     = "trigger_extraction.handler"
    extraction_callback    = "extraction_callback.handler"
  }
}

resource "aws_lambda_function" "this" {
  for_each      = local.lambda_functions
  function_name = "${var.platform_prefix}-${each.key}"
  role          = aws_iam_role.platform_lambda.arn
  handler       = each.value
  runtime       = "python3.12"
  timeout       = 30
  filename         = "${path.module}/dist/${each.key}.zip"
  source_code_hash = filebase64sha256("${path.module}/dist/${each.key}.zip")

  environment {
    variables = {
      DYNAMODB_TABLE = aws_dynamodb_table.pii_metadata.name
    }
  }

  tags = var.tags
}
