resource "aws_dynamodb_table" "pii_metadata" {
  name         = "${var.platform_prefix}-pii-metadata"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "PK"
  range_key    = "SK"

  attribute {
    name = "PK"
    type = "S"
  }

  attribute {
    name = "SK"
    type = "S"
  }

  # Used to query "all pending certifications" across teams/tables
  attribute {
    name = "certificationStatus"
    type = "S"
  }

  # Used to query "everything under this extract request"
  attribute {
    name = "requestId"
    type = "S"
  }

  global_secondary_index {
    name            = "gsi-certification-status"
    hash_key        = "certificationStatus"
    range_key       = "PK"
    projection_type = "ALL"
  }

  global_secondary_index {
    name            = "gsi-request-id"
    hash_key        = "requestId"
    range_key       = "SK"
    projection_type = "ALL"
  }

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = aws_kms_key.platform.arn
  }

  tags = var.tags
}

resource "aws_kms_key" "platform" {
  description             = "KMS key for PII metadata store"
  deletion_window_in_days = 30
  enable_key_rotation     = true
  tags                    = var.tags
}

resource "aws_kms_alias" "platform" {
  name          = "alias/${var.platform_prefix}-pii-metadata"
  target_key_id = aws_kms_key.platform.key_id
}

# --- Item shape reference (documentation only, not a resource) ---
# Table item:
#   PK = "DB#<dbname>#TABLE#<tablename>"          SK = "METADATA"
# Column item:
#   PK = "DB#<dbname>#TABLE#<tablename>"          SK = "COLUMN#<colname>"
# Relationship item:
#   PK = "DB#<dbname>#TABLE#<tablename>"          SK = "REL#<relatedtable>"
# Extract request item:
#   PK = "REQUEST#<requestId>"                    SK = "METADATA"
# Extract request table selection item:
#   PK = "REQUEST#<requestId>"                    SK = "TABLE#<tablename>"
# Team registration item:
#   PK = "TEAM#<teamName>"                        SK = "METADATA"
#   attributes: awsAccountId, externalId, eventBusArn, status
