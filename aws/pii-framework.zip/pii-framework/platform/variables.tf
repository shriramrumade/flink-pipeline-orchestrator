variable "platform_prefix" {
  description = "Prefix for all platform-owned resource names"
  type        = string
  default     = "pii-platform"
}

variable "region" {
  type    = string
  default = "us-east-1"
}

variable "tags" {
  type = map(string)
  default = {
    Owner   = "data-platform-team"
    Project = "pii-scrubbing-framework"
  }
}

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.region
}
