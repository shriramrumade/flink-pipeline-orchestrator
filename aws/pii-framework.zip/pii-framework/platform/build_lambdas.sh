#!/usr/bin/env bash
# Packages each platform Lambda handler together with common.py (and, where
# needed, resolve_relational_keys.py) into a deployable zip under dist/.
# Run this before `terraform apply` in platform/, and re-run whenever the
# handler code changes.
set -euo pipefail
cd "$(dirname "$0")/lambda"
mkdir -p ../dist
rm -f ../dist/*.zip

package() {
  local name=$1
  shift
  local tmp
  tmp=$(mktemp -d)
  cp common.py "$tmp/"
  for f in "$@"; do
    cp "$f" "$tmp/"
  done
  (cd "$tmp" && zip -q -r "$OLDPWD/../dist/${name}.zip" .)
  rm -rf "$tmp"
  echo "built dist/${name}.zip"
}

package onboard_team onboard_team.py
package confirm_team confirm_team.py
package certify_column certify_column.py
package create_extract_request create_extract_request.py resolve_relational_keys.py
package trigger_extraction trigger_extraction.py
package extraction_callback extraction_callback.py
