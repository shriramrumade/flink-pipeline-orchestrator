resource "aws_apigatewayv2_api" "control_plane" {
  name          = "${var.platform_prefix}-control-plane"
  protocol_type = "HTTP"
}

resource "aws_apigatewayv2_stage" "default" {
  api_id      = aws_apigatewayv2_api.control_plane.id
  name        = "$default"
  auto_deploy = true
}

resource "aws_apigatewayv2_integration" "this" {
  for_each               = local.lambda_functions
  api_id                 = aws_apigatewayv2_api.control_plane.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.this[each.key].invoke_arn
  payload_format_version = "2.0"
}

resource "aws_lambda_permission" "apigw" {
  for_each      = local.lambda_functions
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.this[each.key].function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.control_plane.execution_arn}/*/*"
}

resource "aws_apigatewayv2_route" "onboard_team" {
  api_id    = aws_apigatewayv2_api.control_plane.id
  route_key = "POST /teams"
  target    = "integrations/${aws_apigatewayv2_integration.this["onboard_team"].id}"
}

resource "aws_apigatewayv2_route" "confirm_team" {
  api_id    = aws_apigatewayv2_api.control_plane.id
  route_key = "PUT /teams/{teamName}/confirm"
  target    = "integrations/${aws_apigatewayv2_integration.this["confirm_team"].id}"
}

resource "aws_apigatewayv2_route" "certify_column" {
  api_id    = aws_apigatewayv2_api.control_plane.id
  route_key = "POST /teams/{teamName}/certify"
  target    = "integrations/${aws_apigatewayv2_integration.this["certify_column"].id}"
}

resource "aws_apigatewayv2_route" "create_extract_request" {
  api_id    = aws_apigatewayv2_api.control_plane.id
  route_key = "POST /teams/{teamName}/extract-requests"
  target    = "integrations/${aws_apigatewayv2_integration.this["create_extract_request"].id}"
}

resource "aws_apigatewayv2_route" "trigger_extraction" {
  api_id    = aws_apigatewayv2_api.control_plane.id
  route_key = "POST /teams/{teamName}/extract-requests/{requestId}/trigger"
  target    = "integrations/${aws_apigatewayv2_integration.this["trigger_extraction"].id}"
}

output "api_endpoint" {
  value = aws_apigatewayv2_stage.default.invoke_url
}

# NOTE: this HTTP API has no authorizer wired up yet — add a JWT/Lambda
# authorizer (e.g. validating the on-prem portal's service credentials)
# before this leaves a test environment. Every route here can currently be
# called by anyone who can reach the endpoint.
