resource "aws_cloudwatch_event_bus" "central" {
  name = "${var.platform_prefix}-central-bus"
  tags = var.tags
}

# Allows onboarded app team accounts to PutEvents onto this bus. Update
# onboarded_account_ids when a new team completes onboarding (or automate
# this update as a step in confirm_team.py using PutResourcePolicy).
resource "aws_cloudwatch_event_bus_policy" "allow_app_teams" {
  event_bus_name = aws_cloudwatch_event_bus.central.name
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AllowOnboardedAppTeams"
        Effect    = "Allow"
        Principal = { AWS = [for id in var.onboarded_account_ids : "arn:aws:iam::${id}:root"] }
        Action    = "events:PutEvents"
        Resource  = aws_cloudwatch_event_bus.central.arn
      }
    ]
  })
}

resource "aws_cloudwatch_event_rule" "extraction_status" {
  name           = "${var.platform_prefix}-extraction-status"
  event_bus_name = aws_cloudwatch_event_bus.central.name
  event_pattern = jsonencode({
    "detail-type" = ["extraction.completed", "extraction.failed"]
  })
}

resource "aws_cloudwatch_event_target" "extraction_callback" {
  rule           = aws_cloudwatch_event_rule.extraction_status.name
  event_bus_name = aws_cloudwatch_event_bus.central.name
  arn            = aws_lambda_function.this["extraction_callback"].arn
}

resource "aws_lambda_permission" "eventbridge_callback" {
  statement_id  = "AllowEventBridgeInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.this["extraction_callback"].function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.extraction_status.arn
}

variable "onboarded_account_ids" {
  description = "AWS account IDs of onboarded app teams, allowed to PutEvents on the central bus"
  type        = list(string)
  default     = []
}

output "central_event_bus_arn" {
  value = aws_cloudwatch_event_bus.central.arn
}
