"""
POST /teams/{teamName}/extract-requests
Body: {
  "dbName": "orders_prod",
  "mode": "RELATIONAL",            # or "FULL"
  "selectedTables": ["customers", "orders"],
  "seedTable": "customers",         # required for RELATIONAL mode
  "seedColumn": "customer_id",
  "seedValues": ["1001", "1002", "1003"],
  "requestedBy": "jane.doe@company.com"
}

Resolves the full filter/column payload up front (using only certified
metadata already in DynamoDB — no call into the app account yet) so the
portal can show the user a preview of exactly what will be extracted before
they hit "trigger".
"""
import json
from common import new_id, put_extract_request
from resolve_relational_keys import resolve, resolve_full


def handler(event, context):
    body = json.loads(event.get("body") or "{}")
    db_name = body["dbName"]
    mode = body.get("mode", "FULL").upper()
    selected_tables = body["selectedTables"]
    requested_by = body.get("requestedBy", "unknown")

    if mode == "RELATIONAL":
        resolved_tables = resolve(
            db_name=db_name,
            selected_tables=selected_tables,
            seed_table=body["seedTable"],
            seed_column=body["seedColumn"],
            seed_values=body["seedValues"],
        )
    else:
        resolved_tables = resolve_full(db_name, selected_tables)

    request_id = new_id("req")
    put_extract_request(
        request_id=request_id,
        team_name=event["pathParameters"]["teamName"],
        db_name=db_name,
        requested_by=requested_by,
        resolved_tables=resolved_tables,
        mode=mode,
    )

    return {
        "statusCode": 200,
        "body": json.dumps({
            "requestId": request_id,
            "mode": mode,
            "preview": resolved_tables,
            "nextStep": f"POST /teams/{{teamName}}/extract-requests/{request_id}/trigger to run it",
        }),
    }
