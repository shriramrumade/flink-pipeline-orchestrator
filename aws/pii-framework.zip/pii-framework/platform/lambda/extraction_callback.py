"""
Triggered by an EventBridge rule on the platform's central bus matching
detail-type "extraction.completed" / "extraction.failed", put there by the
app team's Step Functions state machine as its final step. Not an API
Gateway route — this is an EventBridge target, so the event shape is the
raw EventBridge event, not an API Gateway proxy event.
"""
from common import update_extract_request_status


def handler(event, context):
    detail = event["detail"]
    request_id = detail["requestId"]
    detail_type = event["detail-type"]

    if detail_type == "extraction.completed":
        update_extract_request_status(request_id, "COMPLETED", extra={
            "outputLocation": detail.get("outputLocation", ""),
        })
    elif detail_type == "extraction.failed":
        update_extract_request_status(request_id, "FAILED", extra={
            "errorMessage": detail.get("errorMessage", ""),
        })

    return {"status": "processed", "requestId": request_id}
