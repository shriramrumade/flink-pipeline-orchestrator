import os
import time
import uuid
import boto3

dynamodb = boto3.resource("dynamodb")
TABLE_NAME = os.environ["DYNAMODB_TABLE"]
table = dynamodb.Table(TABLE_NAME)


def team_pk(team_name):
    return f"TEAM#{team_name}"


def db_table_pk(db_name, table_name):
    return f"DB#{db_name}#TABLE#{table_name}"


def request_pk(request_id):
    return f"REQUEST#{request_id}"


def get_team(team_name):
    resp = table.get_item(Key={"PK": team_pk(team_name), "SK": "METADATA"})
    return resp.get("Item")


def put_team(team_name, aws_account_id, external_id, cross_account_role_arn,
             state_machine_arn):
    table.put_item(Item={
        "PK": team_pk(team_name),
        "SK": "METADATA",
        "teamName": team_name,
        "awsAccountId": aws_account_id,
        "externalId": external_id,
        "crossAccountRoleArn": cross_account_role_arn,
        "stateMachineArn": state_machine_arn,
        "status": "ACTIVE",
        "createdAt": int(time.time()),
    })


def query_columns(db_name, table_name):
    resp = table.query(
        KeyConditionExpression="PK = :pk AND begins_with(SK, :sk)",
        ExpressionAttributeValues={
            ":pk": db_table_pk(db_name, table_name),
            ":sk": "COLUMN#",
        },
    )
    return resp.get("Items", [])


def query_relationships(db_name, table_name):
    resp = table.query(
        KeyConditionExpression="PK = :pk AND begins_with(SK, :sk)",
        ExpressionAttributeValues={
            ":pk": db_table_pk(db_name, table_name),
            ":sk": "REL#",
        },
    )
    return resp.get("Items", [])


def put_extract_request(request_id, team_name, db_name, requested_by, resolved_tables, mode):
    now = int(time.time())
    table.put_item(Item={
        "PK": request_pk(request_id),
        "SK": "METADATA",
        "requestId": request_id,
        "teamName": team_name,
        "dbName": db_name,
        "requestedBy": requested_by,
        "mode": mode,
        "status": "READY",
        "resolvedTables": resolved_tables,
        "createdAt": now,
        "updatedAt": now,
    })


def get_extract_request(request_id):
    resp = table.get_item(Key={"PK": request_pk(request_id), "SK": "METADATA"})
    return resp.get("Item")


def update_extract_request_status(request_id, status, extra=None):
    expr = "SET #s = :s, updatedAt = :u"
    values = {":s": status, ":u": int(time.time())}
    names = {"#s": "status"}
    if extra:
        for i, (k, v) in enumerate(extra.items()):
            expr += f", {k} = :extra{i}"
            values[f":extra{i}"] = v
    table.update_item(
        Key={"PK": request_pk(request_id), "SK": "METADATA"},
        UpdateExpression=expr,
        ExpressionAttributeValues=values,
        ExpressionAttributeNames=names,
    )


def new_id(prefix):
    return f"{prefix}-{uuid.uuid4().hex[:12]}"
