"""
PUT /teams/{teamName}/confirm
Body: { "crossAccountRoleArn": "...", "stateMachineArn": "..." }

Called once by the app team's CI pipeline right after `terraform apply`
succeeds, passing the module's outputs. Flips the team from
PENDING_TERRAFORM_APPLY to ACTIVE.
"""
import json
from common import get_team, team_pk, table


def handler(event, context):
    team_name = event["pathParameters"]["teamName"]
    body = json.loads(event.get("body") or "{}")

    team = get_team(team_name)
    if not team:
        return _resp(404, {"error": "unknown team, call POST /teams first"})

    cross_account_role_arn = body.get("crossAccountRoleArn")
    state_machine_arn = body.get("stateMachineArn")
    if not cross_account_role_arn or not state_machine_arn:
        return _resp(400, {"error": "crossAccountRoleArn and stateMachineArn are required"})

    table.update_item(
        Key={"PK": team_pk(team_name), "SK": "METADATA"},
        UpdateExpression="SET crossAccountRoleArn = :r, stateMachineArn = :s, #st = :active",
        ExpressionAttributeNames={"#st": "status"},
        ExpressionAttributeValues={
            ":r": cross_account_role_arn,
            ":s": state_machine_arn,
            ":active": "ACTIVE",
        },
    )
    return _resp(200, {"teamName": team_name, "status": "ACTIVE"})


def _resp(status, body):
    return {"statusCode": status, "body": json.dumps(body)}
