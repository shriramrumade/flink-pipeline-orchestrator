"""
Turns "user selected these tables and these seed key values" into the full
per-table filter payload the Glue job needs for a RELATIONAL extract.

Key assumption: a join key's VALUES are shared across related tables (e.g.
customer_id=1001 means the same customer in both `customers` and `orders`).
The relationship metadata (certified during onboarding) tells us the COLUMN
NAME on each side, which can differ, but the values themselves propagate
unchanged. This means resolution is pure metadata traversal — no query
against the app team's live database is needed at resolution time.
"""

from common import query_columns, query_relationships


def resolve(db_name, selected_tables, seed_table, seed_column, seed_values):
    """
    selected_tables: list of table names the user checked in the portal
    seed_table/seed_column/seed_values: the table+key+values the user picked
        as the starting point (e.g. customers.customer_id = [1001,1002,1003])

    Returns the `tables` list ready to hand to the Step Functions execution
    input (see examples/example-execution-input.json).
    """
    visited = {}
    queue = [(seed_table, seed_column, list(seed_values))]

    while queue:
        current_table, key_column, values = queue.pop(0)
        if current_table in visited:
            continue
        visited[current_table] = (key_column, values)

        for rel in query_relationships(db_name, current_table):
            related_table = rel["relatedTable"]
            if related_table in visited:
                continue
            if related_table not in selected_tables:
                continue
            # joinKeyColumn = the column name on the RELATED table's side.
            # Falls back to the same column name if not explicitly certified.
            related_join_column = rel.get("relatedJoinColumn", key_column)
            queue.append((related_table, related_join_column, values))

    tables_payload = []
    for table_name, (key_column, values) in visited.items():
        certified_columns = [
            {
                "name": c["columnName"],
                "isPII": c.get("isPII", False),
                "category": c.get("piiCategory"),
            }
            for c in query_columns(db_name, table_name)
            if c.get("certificationStatus") == "approved"
        ]
        tables_payload.append({
            "tableName": table_name,
            "filterColumn": key_column,
            "filterValues": values,
            "certifiedColumns": certified_columns,
        })

    missing = set(selected_tables) - set(visited.keys())
    if missing:
        # Selected tables with no discoverable relationship path to the seed —
        # surface this rather than silently full-extracting them.
        raise ValueError(
            f"No relationship path found from '{seed_table}' to: {sorted(missing)}. "
            "Certify a relationship first, or extract these tables separately in FULL mode."
        )

    return tables_payload


def resolve_full(db_name, selected_tables):
    """FULL mode: every certified column, every row, no filtering."""
    tables_payload = []
    for table_name in selected_tables:
        certified_columns = [
            {
                "name": c["columnName"],
                "isPII": c.get("isPII", False),
                "category": c.get("piiCategory"),
            }
            for c in query_columns(db_name, table_name)
            if c.get("certificationStatus") == "approved"
        ]
        tables_payload.append({
            "tableName": table_name,
            "certifiedColumns": certified_columns,
        })
    return tables_payload
