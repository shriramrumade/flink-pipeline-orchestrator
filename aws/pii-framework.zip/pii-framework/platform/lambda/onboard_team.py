"""
POST /teams
Body: { "teamName": "alpha", "awsAccountId": "222222222222" }

Called by the on-prem portal when an app team starts onboarding. Generates
the external ID they'll put in their Terraform tfvars, and records the team
as PENDING until they report back their cross-account role ARN and state
machine ARN (which their Terraform apply produces as outputs).
"""
import json
import secrets
from common import get_team, table, team_pk, new_id


def handler(event, context):
    body = json.loads(event.get("body") or "{}")
    team_name = body.get("teamName")
    aws_account_id = body.get("awsAccountId")

    if not team_name or not aws_account_id:
        return _resp(400, {"error": "teamName and awsAccountId are required"})

    if get_team(team_name):
        return _resp(409, {"error": f"team '{team_name}' already registered"})

    external_id = f"team-{team_name}-{secrets.token_hex(4)}"

    table.put_item(Item={
        "PK": team_pk(team_name),
        "SK": "METADATA",
        "teamName": team_name,
        "awsAccountId": aws_account_id,
        "externalId": external_id,
        "status": "PENDING_TERRAFORM_APPLY",
    })

    return _resp(200, {
        "teamName": team_name,
        "externalId": external_id,
        "nextStep": "Apply the consumer-module Terraform in your account with "
                    "these values, then call PUT /teams/{teamName}/confirm with "
                    "the resulting cross_account_role_arn and state_machine_arn outputs."
    })


def _resp(status, body):
    return {"statusCode": status, "body": json.dumps(body)}
