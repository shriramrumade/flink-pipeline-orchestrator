"""
POST /teams/{teamName}/certify
Body: {
  "dbName": "orders_prod",
  "tableName": "customers",
  "columns": [
    {"columnName": "email", "isPII": true, "piiCategory": "email", "approve": true},
    {"columnName": "customer_id", "isPII": false, "approve": true}
  ],
  "relationships": [
    {"relatedTable": "orders", "joinKeyColumn": "customer_id", "relatedJoinColumn": "customer_id", "approve": true}
  ],
  "certifiedBy": "jane.doe@company.com"
}
"""
import json
from common import table, db_table_pk


def handler(event, context):
    body = json.loads(event.get("body") or "{}")
    db_name = body["dbName"]
    table_name = body["tableName"]
    certified_by = body.get("certifiedBy", "unknown")
    pk = db_table_pk(db_name, table_name)

    for col in body.get("columns", []):
        table.update_item(
            Key={"PK": pk, "SK": f"COLUMN#{col['columnName']}"},
            UpdateExpression=(
                "SET isPII = :pii, piiCategory = :cat, certificationStatus = :status, certifiedBy = :by"
            ),
            ExpressionAttributeValues={
                ":pii": col.get("isPII", False),
                ":cat": col.get("piiCategory"),
                ":status": "approved" if col.get("approve") else "rejected",
                ":by": certified_by,
            },
        )

    for rel in body.get("relationships", []):
        table.update_item(
            Key={"PK": pk, "SK": f"REL#{rel['relatedTable']}"},
            UpdateExpression=(
                "SET joinKeyColumn = :jk, relatedJoinColumn = :rjk, certificationStatus = :status, certifiedBy = :by"
            ),
            ExpressionAttributeValues={
                ":jk": rel.get("joinKeyColumn"),
                ":rjk": rel.get("relatedJoinColumn", rel.get("joinKeyColumn")),
                ":status": "approved" if rel.get("approve") else "rejected",
                ":by": certified_by,
            },
        )

    return {"statusCode": 200, "body": json.dumps({"tableName": table_name, "status": "certification recorded"})}
