"""
POST /teams/{teamName}/extract-requests/{requestId}/trigger

Assumes the app team's cross-account role (scoped by their external ID) and
starts their Step Functions state machine directly. This is the ONE moment
the platform account reaches into the app account, and it's scoped to a
single sts:AssumeRole + states:StartExecution call.
"""
import json
import boto3
from common import get_team, get_extract_request, update_extract_request_status

sts = boto3.client("sts")


def handler(event, context):
    team_name = event["pathParameters"]["teamName"]
    request_id = event["pathParameters"]["requestId"]

    team = get_team(team_name)
    if not team or team.get("status") != "ACTIVE":
        return _resp(400, {"error": "team not found or not ACTIVE"})

    extract_request = get_extract_request(request_id)
    if not extract_request:
        return _resp(404, {"error": "extract request not found"})

    assumed = sts.assume_role(
        RoleArn=team["crossAccountRoleArn"],
        RoleSessionName=f"pii-trigger-{request_id}",
        ExternalId=team["externalId"],
        DurationSeconds=900,
    )["Credentials"]

    sfn = boto3.client(
        "stepfunctions",
        aws_access_key_id=assumed["AccessKeyId"],
        aws_secret_access_key=assumed["SecretAccessKey"],
        aws_session_token=assumed["SessionToken"],
    )

    execution_input = {
        "requestId": request_id,
        "mode": extract_request["mode"],
        "tables": extract_request["resolvedTables"],
    }

    sfn.start_execution(
        stateMachineArn=team["stateMachineArn"],
        name=request_id,  # idempotent: re-triggering the same request is a no-op if already running
        input=json.dumps(execution_input),
    )

    update_extract_request_status(request_id, "RUNNING")

    return _resp(202, {"requestId": request_id, "status": "RUNNING"})


def _resp(status, body):
    return {"statusCode": status, "body": json.dumps(body)}
