"""
Scheduled safety net (runs hourly via EventBridge). The Step Functions state
machine deletes its own Glue job on both the success and failure paths, so
under normal operation this Lambda finds nothing to do. It exists to catch
the rare case where the state machine itself crashes or is throttled before
its cleanup state runs, so a Glue job definition never silently lingers.
"""

import os
import boto3
from datetime import datetime, timezone

glue = boto3.client("glue")

JOB_NAME_PREFIX = os.environ.get("JOB_NAME_PREFIX", "pii-extract-")
MAX_AGE_MINUTES = int(os.environ.get("MAX_AGE_MINUTES", "60"))


def handler(event, context):
    deleted = []
    paginator = glue.get_paginator("get_jobs")
    for page in paginator.paginate():
        for job in page["Jobs"]:
            name = job["Name"]
            if not name.startswith(JOB_NAME_PREFIX):
                continue

            created_on = job["CreatedOn"]
            age_minutes = (datetime.now(timezone.utc) - created_on).total_seconds() / 60
            if age_minutes < MAX_AGE_MINUTES:
                continue

            # Only delete if there's no currently RUNNING/STARTING job run —
            # avoid killing a legitimately long-running extraction.
            runs = glue.get_job_runs(JobName=name, MaxResults=5).get("JobRuns", [])
            active = [r for r in runs if r["JobRunState"] in ("RUNNING", "STARTING", "WAITING")]
            if active:
                continue

            glue.delete_job(JobName=name)
            deleted.append(name)

    if deleted:
        print(f"Orphaned Glue jobs deleted: {deleted}")
    return {"deletedJobs": deleted}
