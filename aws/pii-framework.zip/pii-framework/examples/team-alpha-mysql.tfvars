team_name            = "alpha"
platform_account_id  = "111111111111"          # your platform account ID
external_id          = "team-alpha-7f2a9c1e"   # issued by the portal at onboarding

platform_script_bucket = "pii-platform-shared-scripts"
platform_script_key    = "pii_extract_scrub_v1.0.0.py"

db_engine   = "mysql"
db_host     = "alpha-orders-db.internal.example.com"
db_port     = 3306
db_name     = "orders_prod"
db_username = "pii_readonly_svc"
# db_password should come from a secure source (CI secret store), not committed:
# db_password = var.db_password  -- pass via TF_VAR_db_password env var

vpc_id     = "vpc-0123456789abcdef0"
subnet_ids = ["subnet-0aaa1111", "subnet-0bbb2222"]

tags = {
  Team    = "alpha"
  Project = "pii-scrubbing-framework"
}
