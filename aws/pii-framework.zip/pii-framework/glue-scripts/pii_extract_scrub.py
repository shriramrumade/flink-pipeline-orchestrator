"""
Shared PII extraction + relational scrubbing job.

Owned and versioned by the platform team. App teams reference this script by
S3 path/version in their Terraform — they do not fork or edit it. Behavior is
controlled entirely through job parameters (--MODE, --TABLES).

MODE = "FULL"
    Every certified non-PII column is passed through as-is; every PII column
    is replaced with a deterministic synthetic value. All rows extracted.

MODE = "RELATIONAL"
    Same scrubbing behavior, but each table is filtered down to only the rows
    matching the certified extraction keys resolved upstream (in the portal /
    DynamoDB relationship metadata) and passed in via the TABLES parameter as
    `filterColumn` / `filterValues`.

Relational consistency: the same real value for a given PII category always
maps to the same synthetic value across every table processed IN THIS RUN,
because the scrub function is a pure deterministic function of
(requestId, category, original value) — no external mapping store needed for
a single run. Using requestId as part of the seed means the same real value
maps to a DIFFERENT synthetic value across separate extraction runs, which is
a deliberate privacy choice (prevents linking two exports of the same data).
If your use case instead needs the SAME synthetic value across runs (e.g. a
stable "customer 1001 is always fake-customer Jane Doe" for downstream test
fixtures), drop requestId from the seed — see SEED_SCOPE below.

No raw PII is ever written to S3. Extraction, scrubbing, and write all happen
within this one Spark job; there is no unscrubbed staging artifact.
"""

import sys
import json
import hashlib

import boto3
from faker import Faker
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql.types import StringType
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions

# Change to "run" if you want stable synthetic values across separate runs
# instead of per-run (see module docstring).
SEED_SCOPE = "request"  # or "global"

args = getResolvedOptions(
    sys.argv,
    ["JOB_NAME", "REQUEST_ID", "SECRET_ARN", "DB_NAME", "MODE", "TABLES", "OUTPUT_BUCKET", "TEAM_NAME"],
)

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

request_id = args["REQUEST_ID"]
mode = args["MODE"].upper()
tables_config = json.loads(args["TABLES"])
output_bucket = args["OUTPUT_BUCKET"]

# --- Fetch DB credentials at runtime only, never persisted to disk/S3 ---
secrets_client = boto3.client("secretsmanager")
secret = json.loads(secrets_client.get_secret_value(SecretId=args["SECRET_ARN"])["SecretString"])

jdbc_url_by_engine = {
    "mysql": f"jdbc:mysql://{secret['host']}:{secret['port']}/{secret['dbname']}",
    "postgres": f"jdbc:postgresql://{secret['host']}:{secret['port']}/{secret['dbname']}",
}
jdbc_url = jdbc_url_by_engine[secret["engine"]]
connection_properties = {
    "user": secret["username"],
    "password": secret["password"],
    "driver": {"mysql": "com.mysql.cj.jdbc.Driver", "postgres": "org.postgresql.Driver"}[secret["engine"]],
}


def scrub_value(category: str, value: str) -> str:
    """Deterministic synthetic replacement for a single PII value."""
    if value is None:
        return None
    seed_input = f"{category}:{value}"
    if SEED_SCOPE == "request":
        seed_input = f"{request_id}:{seed_input}"
    seed = int(hashlib.sha256(seed_input.encode()).hexdigest(), 16) % (2**32)

    fkr = Faker()
    fkr.seed_instance(seed)

    generators = {
        "first_name": fkr.first_name,
        "last_name": fkr.last_name,
        "full_name": fkr.name,
        "email": fkr.email,
        "phone": fkr.phone_number,
        "ssn": fkr.ssn,
        "address": lambda: fkr.address().replace("\n", ", "),
        "date_of_birth": lambda: fkr.date_of_birth().isoformat(),
        "credit_card": fkr.credit_card_number,
        "ip_address": fkr.ipv4_public,
    }
    generator = generators.get(category)
    if generator:
        return generator()
    # Unknown PII category: deterministic redaction rather than passthrough
    return f"REDACTED-{seed}"


def build_scrub_udf(category: str):
    return F.udf(lambda v: scrub_value(category, v), StringType())


for table_cfg in tables_config:
    table_name = table_cfg["tableName"]
    columns = table_cfg["certifiedColumns"]  # [{name, isPII, category}, ...]

    read_kwargs = dict(url=jdbc_url, table=table_name, properties=connection_properties)
    df = spark.read.jdbc(**read_kwargs)

    if mode == "RELATIONAL":
        filter_column = table_cfg.get("filterColumn")
        filter_values = table_cfg.get("filterValues")
        if filter_column and filter_values:
            df = df.where(F.col(filter_column).isin(filter_values))
    # MODE == "FULL" -> no filter, every row extracted

    for col_meta in columns:
        col_name = col_meta["name"]
        if col_meta.get("isPII"):
            category = col_meta.get("category", "unknown")
            df = df.withColumn(col_name, build_scrub_udf(category)(F.col(col_name)))
        # non-PII columns pass through untouched

    output_path = f"s3://{output_bucket}/synthetic/{request_id}/{table_name}/"
    df.write.mode("overwrite").parquet(output_path)

    print(f"[{table_name}] wrote {df.count()} rows to {output_path} (mode={mode})")

job.commit()
