# PII Discovery & Synthetic Data Framework

Two-sided system:

- `platform/` — Terraform for **your** AWS account. Owns DynamoDB (metadata store)
  and the API Gateway control plane. Applied once by the platform team.
- `consumer-module/` — Terraform **module** you publish (git tag or private
  registry) and hand to application teams. Each app team applies it in their
  own AWS account. Owns: cross-account IAM role, Secrets Manager entry for
  their DB creds, S3 bucket for synthetic output, Glue Connection + IAM role,
  the Step Functions state machine that runs the ephemeral ETL, and the
  EventBridge wiring back to your platform account.
- `glue-scripts/pii_extract_scrub.py` — the shared, versioned PySpark job.
  App teams never edit this. You update it centrally; they reference it by
  S3 version.
- `stepfunctions/pii_extraction_workflow.asl.json` — the ephemeral
  create-job -> run-job -> delete-job state machine, using native Step
  Functions AWS-SDK service integrations (no Lambda glue code required).
- `lambda/cleanup_orphaned_glue_jobs.py` — safety-net scheduled Lambda per
  app account, catches anything the state machine's cleanup step missed.
- `examples/team-alpha-mysql.tfvars` — a filled-in example for the first
  app team, using MySQL as the source database.

## Design decisions worth knowing before you deploy

1. **No raw PII ever touches S3.** The Glue job reads from MySQL straight
   into Spark memory, scrubs in-flight, and writes only the synthetic
   output to S3. There is no "staging" prefix of unscrubbed data sitting
   around waiting to be cleaned up — because it never gets written.
2. **The Glue Job definition itself is created and deleted per run** by the
   state machine, not by Terraform. Terraform only creates the Glue
   *Connection* (network/credential plumbing) and the IAM role Glue jobs
   assume. This is what makes the ETL ephemeral: between runs there is zero
   standing Glue job resource in the account.
3. **Relational consistency** (same customer_id maps to the same synthetic
   value across every table in one extraction) is handled inside a single
   Spark job run — all selected tables are processed together, so the
   value-to-synthetic mapping is built once and broadcast, rather than
   needing an external mapping store.
4. **Metadata never crosses the boundary in raw form during a run.** The
   certified column/PII metadata for the selected tables is serialized as a
   Glue job parameter (JSON string) at Step Functions invocation time — the
   Glue job does not call back into your API mid-run. This shrinks the
   cross-account network surface to: (a) the initial event that kicks off
   the run, and (b) a completion callback.

## End-to-end sequence (now that the platform side is built)

1. `terraform apply` in `platform/` (after running `platform/build_lambdas.sh`).
   Gives you the API endpoint and central event bus ARN.
2. Portal calls `POST /teams` -> `onboard_team.py` -> returns `externalId`.
3. App team fills `examples/team-alpha-mysql.tfvars` with that `externalId`
   plus your `platform_account_id`, `platform_script_bucket`, and the
   `platform_event_bus_arn` output from step 1, then `terraform apply`s
   `consumer-module/` in their own account.
4. App team's CI calls `PUT /teams/alpha/confirm` with the module's
   `cross_account_role_arn` and `state_machine_arn` outputs ->
   `confirm_team.py` flips them to `ACTIVE`.
5. Add their AWS account ID to `onboarded_account_ids` in platform tfvars
   and re-apply, so their Step Functions callback is allowed onto your bus.
6. Discovery/certification: `POST /teams/alpha/certify` records approved
   PII flags and table relationships (assumes discovery already populated
   the raw column list — the discovery-side Glue crawler job isn't built in
   this repo yet, see open items below).
7. `POST /teams/alpha/extract-requests` -> `create_extract_request.py`
   resolves the relational key graph (`resolve_relational_keys.py`) and
   returns a preview.
8. `POST /teams/alpha/extract-requests/{id}/trigger` ->
   `trigger_extraction.py` assumes their role and starts their state
   machine.
9. Their state machine creates the ephemeral Glue job, runs it, deletes it,
   and PutEvents onto your central bus either way ->
   `extraction_callback.py` updates the request status in DynamoDB.

## Open items not yet built

- **Discovery-side Glue crawler job** that populates raw column metadata
  before certification (this repo builds the certify/extract path; the
  crawl-and-classify path follows the same ephemeral pattern but isn't
  written yet).
- **API Gateway authorizer** — `api_gateway.tf` has a `NOTE` flagging that
  every route is currently open. Add a Lambda or JWT authorizer validating
  the on-prem portal's service identity before using this outside a test
  account.
- **Automating `onboarded_account_ids`** — right now adding a team's
  account ID to the EventBridge bus policy requires a manual tfvars edit
  + re-apply. `confirm_team.py` could instead call
  `events:PutResourcePolicy` directly to automate this.
