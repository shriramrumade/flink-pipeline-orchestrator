# UC2 — Enterprise Synthetic Data Generation Platform
## Complete Implementation Guide (Org-Standard)

**Version:** 1.0 · **Status:** Implementation-ready · **Owner:** Data Platform Team
**Goal:** Generate realistic, referentially-intact synthetic data for relational databases (cross-table FK consistency) and non-relational stores (documents), preserving statistical properties of production data — for test environments, development, demos, and data sharing — with privacy guarantees.

---

# 1. Executive Summary

Teams need production-like data they're not allowed to copy. This platform:
- **Learns** schema, constraints, distributions, and cross-column/cross-table relationships from production (metadata + statistics only, or full data inside the secure zone)
- **Generates** synthetic relational data with valid FKs, realistic cardinalities (a customer has 0–40 orders, not exactly 5), sequences, and business rules — plus JSON/document data for NoSQL stores
- **Validates** every batch: constraint compliance, statistical fidelity (per-column + correlations), and privacy checks (no memorized real records)
- **Delivers** via SQL dumps, direct DB load, Parquet/JSON files, or an on-demand API

Three generation strategies, selected per table by a strategy resolver: **rule-based (Faker + constraints)** for identifier-like columns, **statistical (fitted distributions + copulas)** for realistic numerics/categoricals, and **ML-based (SDV-style / CTGAN)** where complex inter-column dependencies matter. Hybrid by design — one strategy never fits a whole enterprise schema.

---

# 2. Requirements

## 2.1 Functional

| ID | Requirement |
|----|-------------|
| FR-1 | Introspect schema from Postgres/MySQL/Oracle/SQL Server (tables, columns, types, PK/FK/unique/check constraints, indexes) and from MongoDB (inferred document schemas via sampling) |
| FR-2 | Profile production data: per-column distributions, null rates, category frequencies, correlations, FK cardinality distributions (children-per-parent), temporal patterns |
| FR-3 | Generate N rows per table with: all constraints satisfied, FK graphs consistent, deterministic reproducibility via seed |
| FR-4 | Support scale factors ("50% of prod volume", "10× orders table") with cardinality distributions preserved proportionally |
| FR-5 | Business-rule DSL: cross-column rules (ship_date ≥ order_date; status='refunded' ⇒ refund_amount > 0) declared in YAML, enforced in generation and validated post-hoc |
| FR-6 | Privacy modes: (a) *statistical-only* — generator trained on aggregates, never row-level data leaves the secure zone; (b) *model-based* — trained in-zone on row data, generator artifact exported after privacy validation |
| FR-7 | Output targets: SQL insert scripts, direct load (JDBC/psycopg), Parquet, JSONL (Mongo `mongoimport`-ready) |
| FR-8 | Validation report per batch: constraint pass rate (must be 100%), per-column fidelity (KS/chi² distance), correlation fidelity, privacy audit (nearest-real-record distance) |
| FR-9 | CLI + config-file driven; CI-friendly (generate fresh test data per pipeline run) |

## 2.2 Non-Functional

| ID | Requirement |
|----|-------------|
| NFR-1 | 1M rows across a 30-table schema in < 15 min on a standard 8-core box |
| NFR-2 | Deterministic: same config + seed → byte-identical output (test reproducibility) |
| NFR-3 | Zero production credentials in generation environments; profiling runs in the secure zone, only the *profile artifact* (stats, no rows) crosses out in statistical mode |
| NFR-4 | Memory-bounded streaming writes (never materialize 100M rows in RAM) |
| NFR-5 | Extensible: new column strategy = one class implementing `ColumnGenerator` |

## 2.3 Non-Goals (v1)
- Differential-privacy formal guarantees (v2; v1 uses privacy *auditing* — distance-to-real checks — which is necessary but weaker)
- Free-text generation with semantic coherence beyond template/LLM plugins
- Streaming/CDC synthetic event generation (v2)

---

# 3. Architecture

## 3.1 High-Level Architecture

```mermaid
flowchart TB
    subgraph SecureZone["🔒 Secure Zone (prod-adjacent)"]
        PROD[(Production DBs<br/>PG / MySQL / Mongo)]
        INTRO[Schema Introspector]
        PROF[Data Profiler]
        MLTRAIN[ML Trainer<br/>CTGAN/copulas per table]
        PAUDIT[Privacy Auditor]
        PROFART[(Profile Artifact<br/>schema.json + stats.json<br/>+ models/*.pkl)]
    end

    subgraph GenZone["Generation Zone (dev/CI — no prod access)"]
        CFG[Generation Config<br/>YAML: scale, rules, seed]
        PLAN[Generation Planner<br/>topo-sort FK graph]
        RESOLVE[Strategy Resolver<br/>per column]
        GEN[Generators<br/>rule / statistical / ML]
        RULES[Business-Rule Engine]
        VAL[Validator<br/>constraints + fidelity + privacy]
        OUT[Writers<br/>SQL / Parquet / JSONL / direct-load]
    end

    TGT[(Target Envs<br/>test DBs, CI, demos)]
    REP[Validation Report<br/>HTML/JSON]

    PROD --> INTRO --> PROFART
    PROD --> PROF --> PROFART
    PROD --> MLTRAIN --> PAUDIT --> PROFART
    PROFART --> PLAN
    CFG --> PLAN
    PLAN --> RESOLVE --> GEN --> RULES --> VAL
    VAL --> OUT --> TGT
    VAL --> REP
```

## 3.2 The Two-Zone Privacy Model (core design)

```
SECURE ZONE (has prod access)          GENERATION ZONE (no prod access)
┌─────────────────────────────┐        ┌──────────────────────────────┐
│ introspect + profile + train │  ───▶ │ consume profile artifact only │
│ output: profile artifact     │        │ generate, validate, deliver   │
│ (stats + fitted models,      │        │ runs anywhere: laptop, CI     │
│  NEVER raw rows)             │        │                               │
└─────────────────────────────┘        └──────────────────────────────┘
```
The **profile artifact** is the only thing that crosses the boundary. It's reviewable (JSON stats + model files), versionable, and privacy-audited before export. This design means CI pipelines and dev laptops generate data freely with zero production exposure.

## 3.3 Component Responsibilities

| Component | Responsibility |
|---|---|
| **Schema Introspector** | Read information_schema / catalog → normalized `SchemaModel` (tables, columns, types, PK, FK, unique, checks, nullability). Mongo: sample 10k docs/collection, infer field types + presence rates + nesting |
| **Data Profiler** | Per column: type-appropriate stats (numeric: quantiles + fitted distribution family; categorical: frequency table (top-K + tail mass); datetime: range + weekday/hour profiles; text: length dist + pattern inference like `AAA-9999`). Per table: row count, null co-occurrence. Per FK: children-per-parent histogram. Cross-column: correlation matrix (numeric), mutual information (categorical pairs) |
| **ML Trainer** | For tables flagged `strategy: ml`: fit Gaussian copula (default) or CTGAN (complex) on row data in-zone. Serialize model into artifact |
| **Privacy Auditor** | Before artifact export: (1) k-anonymity screen on categorical stat tables (suppress categories with count < k); (2) for ML models, generate 10k samples, compute nearest-real-neighbor distances, fail export if any sample is "too close" (memorization); (3) forbid export of min/max on quasi-identifier columns, export winsorized bounds instead |
| **Generation Planner** | Topological sort of FK graph (parents before children); cycle handling via deferred nullable-FK backfill; volume plan from scale factors × cardinality distributions |
| **Strategy Resolver** | Column → generator, by priority: (1) explicit config override, (2) semantic detection (name/type patterns: *_email, *_id, *_date), (3) profiled-distribution default |
| **Business-Rule Engine** | Applies YAML rules as post-generation row transforms + rejection/repair sampling |
| **Validator** | Hard gate: 100% constraint compliance. Soft scores: per-column KS/chi² vs profile, correlation delta, cardinality fidelity. Privacy re-check on output |
| **Writers** | Streaming, batched, FK-order aware; SQL with proper quoting/escaping; idempotent loads (truncate-and-load or append modes) |

## 3.4 Architecture Decisions

| # | Decision | Rationale |
|---|---|---|
| ADR-1 | Hybrid strategy per column, not one global model | Enterprise schemas mix IDs (rules), amounts (statistics), and behavior-correlated columns (ML). Global GANs fail on FK integrity and waste capacity on ID columns |
| ADR-2 | Two-zone artifact design | Privacy by architecture: generation environments provably can't touch prod |
| ADR-3 | Copulas default, CTGAN opt-in | Gaussian copulas capture correlations at 1/100 the train cost; CTGAN reserved for tables where copula fidelity fails validation |
| ADR-4 | Constraints enforced generatively (FK sampling from generated parents) + validated post-hoc | Enforce-then-verify: never rely on generation alone for referential integrity |
| ADR-5 | Determinism via seeded RNG hierarchy (master seed → per-table seed → per-column stream) | Reproducible test data; parallel generation stays deterministic |

---

# 4. Sequence Diagrams

## 4.1 Profiling Run (Secure Zone)

```mermaid
sequenceDiagram
    autonumber
    participant OP as Operator
    participant CLI as syndata CLI
    participant IN as Introspector
    participant PR as Profiler
    participant ML as ML Trainer
    participant PA as Privacy Auditor
    participant ART as Profile Artifact

    OP->>CLI: syndata profile --db $PROD_DSN --config profile.yaml
    CLI->>IN: introspect()
    IN-->>CLI: SchemaModel (tables, cols, FKs, checks)
    CLI->>PR: profile(SchemaModel, sample_policy)
    PR->>PR: per-column stats, FK cardinality hists,<br/>correlations (sampled reads, read-only creds)
    PR-->>CLI: StatsModel
    CLI->>ML: train(tables flagged ml)
    ML-->>CLI: fitted models
    CLI->>PA: audit(StatsModel, models)
    PA->>PA: k-anon suppression, memorization test,<br/>bound winsorization
    alt audit passes
        PA-->>ART: write artifact vX.Y (schema.json, stats.json, models/, audit_report.json)
        ART-->>OP: artifact ready for export approval
    else audit fails
        PA-->>OP: BLOCKED + failure details (which table/model memorized)
    end
```

## 4.2 Generation Run (Generation Zone)

```mermaid
sequenceDiagram
    autonumber
    participant U as User / CI
    participant CLI as syndata CLI
    participant PL as Planner
    participant SR as Strategy Resolver
    participant G as Generators
    participant BR as Rule Engine
    participant V as Validator
    participant W as Writer
    participant T as Target DB

    U->>CLI: syndata generate --artifact v1.3 --config gen.yaml --seed 42
    CLI->>PL: plan(schema, scale_factors)
    PL-->>CLI: ordered plan: [customers(10k) → products(2k) → orders(48k) → order_items(130k)...]
    loop per table in topo order
        CLI->>SR: resolve strategies (config > semantic > profiled)
        loop per batch of 50k rows
            SR->>G: generate batch (seeded streams)
            G->>G: FK cols: sample parent keys per<br/>cardinality distribution
            G-->>BR: raw batch
            BR->>BR: apply rules (repair or reject+resample)
            BR-->>V: candidate batch
            V->>V: constraint checks (hard gate)
            V-->>W: validated batch
            W->>T: streamed insert (FK-safe order)
        end
    end
    CLI->>V: full-run fidelity + privacy report
    V-->>U: report.html (PASS/WARN per metric)
```

## 4.3 Workflow — Strategy Resolution per Column

```mermaid
flowchart TD
    A[Column] --> B{Explicit override<br/>in gen.yaml?}
    B -- yes --> Z[Use configured generator]
    B -- no --> C{Semantic match?<br/>name/type patterns}
    C -- "email/phone/name/address/uuid" --> D[Rule-based<br/>Faker-backed, locale-aware]
    C -- "PK / surrogate id" --> E[Sequence / UUID generator]
    C -- "FK" --> F[Parent-key sampler<br/>w/ cardinality distribution]
    C -- no --> G{Profiled type}
    G -- numeric --> H[Fitted distribution sampler<br/>+ copula correlation]
    G -- categorical --> I[Frequency-table sampler<br/>k-anon suppressed tail]
    G -- datetime --> J[Temporal sampler<br/>range + weekday/hour profile]
    G -- text --> K[Pattern sampler AAA-9999<br/>or LLM/template plugin]
    G -- "table flagged ml" --> L[Copula/CTGAN row sampler<br/>column extracted from joint]
```

---

# 5. Data Design

## 5.1 Profile Artifact Layout

```
artifact-v1.3/
├── manifest.json          # version, created_at, source fingerprint, audit status
├── schema.json            # normalized SchemaModel (all DBs, all constraints)
├── stats/
│   ├── customers.json     # per-column stats (example below)
│   └── orders.json
├── fk_cardinality.json    # {"orders.customer_id": {"hist": {...}, "zero_rate": 0.18}}
├── correlations.json      # per-table numeric corr + categorical MI pairs
├── models/
│   └── orders.copula.pkl  # only for ml-strategy tables
└── audit_report.json      # privacy audit outcomes
```

```json
// stats/customers.json (excerpt)
{
  "row_count": 1840233,
  "columns": {
    "age": {"kind": "numeric", "null_rate": 0.02,
            "fit": {"family": "lognorm", "params": [0.31, 0, 38.2]},
            "bounds_winsorized": [18, 94]},
    "country": {"kind": "categorical", "null_rate": 0.0,
                "freq": {"US": 0.41, "IN": 0.17, "DE": 0.09, "__TAIL__": 0.33},
                "tail_cardinality": 141, "k_anon_suppressed": 12},
    "email": {"kind": "semantic:email", "unique": true},
    "signup_at": {"kind": "datetime", "range": ["2019-01-04", "2026-06-30"],
                  "weekday_profile": [0.13,0.15,0.15,0.15,0.16,0.14,0.12]}
  }
}
```

## 5.2 Generation Config (user-facing)

```yaml
# gen.yaml
artifact: artifacts/v1.3
seed: 42
targets:
  - kind: postgres
    dsn_env: TARGET_PG_DSN          # env var, never inline
    mode: truncate_and_load
scale:
  default: 0.1                      # 10% of prod volume
  overrides:
    orders: 0.5
    audit_log: 0.01
strategies:                          # explicit overrides (highest priority)
  customers.email: {generator: email, unique: true, domain_pool: ["example.test"]}
  orders: {table_strategy: ml}       # use the trained copula for this table
rules:                               # business-rule DSL
  - table: orders
    expr: "ship_date IS NULL OR ship_date >= order_date"
    on_violation: repair             # repair | reject
    repair: "ship_date = order_date + random_days(0, 7)"
  - table: payments
    expr: "status != 'refunded' OR refund_amount > 0"
    on_violation: reject
mongo:
  - collection: user_events
    from_schema: inferred            # sampled schema in artifact
    volume: 200000
    link: {field: user_id, references: postgres.customers.id}   # cross-store FK!
privacy:
  min_nn_distance_check: true        # re-audit outputs against artifact fingerprints
```

Note the **cross-store link**: Mongo documents reference generated relational keys — the planner treats collections as FK children of relational parents, which is how you keep a polyglot environment coherent.

---

# 6. Repository Structure

```
syndata/
├── pyproject.toml
├── README.md
├── src/syndata/
│   ├── cli.py                      # typer CLI: profile / generate / validate
│   ├── schema/
│   │   ├── model.py                # SchemaModel dataclasses
│   │   ├── introspect_sql.py       # PG/MySQL/Oracle/MSSQL via SQLAlchemy inspector
│   │   └── introspect_mongo.py     # sampling-based inference
│   ├── profile/
│   │   ├── profiler.py
│   │   ├── fitters.py              # distribution fitting (scipy)
│   │   └── privacy_audit.py
│   ├── plan/
│   │   ├── planner.py              # topo sort, cycles, volumes
│   │   └── resolver.py             # strategy resolution
│   ├── generate/
│   │   ├── base.py                 # ColumnGenerator ABC, seeded streams
│   │   ├── rule_based.py           # Faker-backed semantic generators
│   │   ├── statistical.py          # fitted dists, copula sampler
│   │   ├── ml_sdv.py               # CTGAN/copula table models
│   │   ├── fk.py                   # parent-key cardinality sampler
│   │   └── rules_engine.py         # DSL: repair/reject
│   ├── validate/
│   │   ├── constraints.py          # hard gate
│   │   ├── fidelity.py             # KS/chi²/corr deltas
│   │   └── report.py               # HTML/JSON report
│   └── write/
│       ├── sql_writer.py
│       ├── parquet_writer.py
│       ├── jsonl_writer.py
│       └── direct_load.py
├── tests/
│   ├── test_topo_plan.py
│   ├── test_fk_integrity.py        # generate → 0 orphan check
│   ├── test_determinism.py         # same seed → identical bytes
│   ├── test_rules_engine.py
│   ├── test_privacy_audit.py
│   └── fixtures/tiny_schema/       # 6-table toy schema for CI
├── deploy/Dockerfile
└── .github/workflows/ci.yaml
```

---

# 7. Step-by-Step Implementation

## PHASE 1 — Schema Introspection (Week 1, days 1–3)

```python
# src/syndata/schema/model.py
from dataclasses import dataclass, field

@dataclass
class Column:
    name: str
    dtype: str                      # normalized: int|float|decimal|str|bool|date|datetime|json
    nullable: bool
    unique: bool = False
    is_pk: bool = False
    check: str | None = None        # raw check expression, surfaced to rule engine
    semantic: str | None = None     # detected: email|phone|name|uuid|...

@dataclass
class ForeignKey:
    column: str
    ref_table: str
    ref_column: str

@dataclass
class Table:
    name: str
    columns: dict[str, Column]
    fks: list[ForeignKey] = field(default_factory=list)
    row_count: int = 0

@dataclass
class SchemaModel:
    tables: dict[str, Table]
    def topo_order(self) -> list[str]:
        """Parents before children; cycles broken at nullable FKs (deferred backfill)."""
        # Kahn's algorithm over FK edges; on cycle, drop the nullable-FK edge with
        # lowest cardinality, record it in deferred_edges for backfill pass.
        ...
```

```python
# src/syndata/schema/introspect_sql.py
from sqlalchemy import create_engine, inspect
from .model import SchemaModel, Table, Column, ForeignKey

SEMANTIC_PATTERNS = {
    "email": r".*e?mail.*", "phone": r".*(phone|mobile|msisdn).*",
    "name":  r".*(first|last|full)_?name.*", "uuid": r".*(uuid|guid).*",
    "address": r".*(street|address|city|zip|postal).*",
}

def introspect(dsn: str) -> SchemaModel:
    insp = inspect(create_engine(dsn))
    tables = {}
    for t in insp.get_table_names():
        cols = {}
        pks = set(insp.get_pk_constraint(t)["constrained_columns"])
        uniques = {c for u in insp.get_unique_constraints(t) for c in u["column_names"]}
        for c in insp.get_columns(t):
            cols[c["name"]] = Column(
                name=c["name"], dtype=normalize_type(c["type"]),
                nullable=c["nullable"], unique=c["name"] in uniques,
                is_pk=c["name"] in pks, semantic=detect_semantic(c["name"]))
        fks = [ForeignKey(fk["constrained_columns"][0], fk["referred_table"],
                          fk["referred_columns"][0]) for fk in insp.get_foreign_keys(t)]
        tables[t] = Table(name=t, columns=cols, fks=fks)
    return SchemaModel(tables=tables)
```

Mongo introspection: sample 10k docs per collection, walk keys recursively, record `{path: {types_seen, presence_rate, example_shape}}`; flatten arrays as `path[]`. Nested docs become nested generator specs.

**Milestone:** `syndata profile --schema-only` prints a correct normalized schema for your dev DB, including a topo order and any FK cycles found.

## PHASE 2 — Profiler + Privacy Audit (Week 1 day 4 – Week 2)

```python
# src/syndata/profile/fitters.py
import numpy as np
from scipy import stats

CANDIDATES = [stats.norm, stats.lognorm, stats.expon, stats.gamma, stats.uniform]

def fit_numeric(values: np.ndarray) -> dict:
    """Fit candidate families, pick by KS statistic; fall back to
    empirical quantile sampler when nothing fits well (multimodal etc.)."""
    values = values[~np.isnan(values)]
    best = None
    for dist in CANDIDATES:
        try:
            params = dist.fit(values)
            ks = stats.kstest(values, dist.name, args=params).statistic
            if best is None or ks < best["ks"]:
                best = {"family": dist.name, "params": list(params), "ks": ks}
        except Exception:
            continue
    if best is None or best["ks"] > 0.08:            # poor fit → empirical
        qs = np.quantile(values, np.linspace(0, 1, 101))
        return {"family": "empirical", "quantiles": qs.tolist()}
    return best
```

```python
# src/syndata/profile/privacy_audit.py
K_ANON = 20            # categories seen fewer than K times are folded into __TAIL__

def audit_categorical(freq_counts: dict, total: int) -> dict:
    kept, tail = {}, 0.0
    for cat, cnt in freq_counts.items():
        if cnt >= K_ANON:
            kept[cat] = cnt / total
        else:
            tail += cnt / total
    return {"freq": kept, "__TAIL__": tail, "suppressed": len(freq_counts) - len(kept)}

def audit_ml_model(model, real_sample, n=10000, min_dist_quantile=0.01):
    """Memorization check: generate n rows, find each one's nearest real row
    (normalized euclidean on numeric + hamming on categorical). If generated
    points sit closer to real rows than real rows sit to each other (bottom
    quantile), the model memorized → FAIL export."""
    synth = model.sample(n)
    d_sr = nearest_neighbor_dist(synth, real_sample)
    d_rr = nearest_neighbor_dist(real_sample, real_sample, exclude_self=True)
    threshold = np.quantile(d_rr, min_dist_quantile)
    leak_rate = float((d_sr < threshold).mean())
    return {"leak_rate": leak_rate, "pass": leak_rate < 0.001}
```

Profiler assembles: per-column fits, k-anon-suppressed frequency tables, FK cardinality histograms (`SELECT parent_id, COUNT(*) ... GROUP BY parent_id` → histogram of counts, including the zero-children rate via anti-join), numeric correlation matrices per table, and winsorized bounds (1st/99th percentile — never true min/max, which can identify individuals).

**Milestone:** artifact directory produced from your dev DB; `audit_report.json` shows k-anon suppressions and (if ML tables configured) memorization pass.

## PHASE 3 — Generators (Weeks 2–3, the core)

**Step 3.1 — Seeded determinism infrastructure:**
```python
# src/syndata/generate/base.py
import numpy as np
from abc import ABC, abstractmethod

class SeedTree:
    """master → per-table → per-column independent streams.
    Parallel-safe: streams are derived, not shared."""
    def __init__(self, master: int):
        self.master = master
    def stream(self, *path: str) -> np.random.Generator:
        seq = np.random.SeedSequence([self.master, *[hash(p) & 0xFFFFFFFF for p in path]])
        return np.random.default_rng(seq)

class ColumnGenerator(ABC):
    @abstractmethod
    def generate(self, n: int, rng: np.random.Generator, ctx: "RowContext") -> np.ndarray: ...
```

**Step 3.2 — Statistical generators:**
```python
# src/syndata/generate/statistical.py
from scipy import stats
import numpy as np

class FittedNumeric(ColumnGenerator):
    def __init__(self, fit: dict, bounds, null_rate: float):
        self.fit, self.bounds, self.null_rate = fit, bounds, null_rate

    def generate(self, n, rng, ctx):
        if self.fit["family"] == "empirical":
            u = rng.uniform(0, 1, n)
            vals = np.interp(u, np.linspace(0, 1, 101), self.fit["quantiles"])
        else:
            dist = getattr(stats, self.fit["family"])
            vals = dist.rvs(*self.fit["params"], size=n, random_state=rng)
        vals = np.clip(vals, *self.bounds)
        if self.null_rate > 0:
            vals[rng.uniform(size=n) < self.null_rate] = np.nan
        return vals

class CategoricalFreq(ColumnGenerator):
    def __init__(self, freq: dict, tail_mass: float, tail_card: int):
        self.cats = list(freq); self.p = np.array(list(freq.values()))
        self.tail_mass, self.tail_card = tail_mass, tail_card

    def generate(self, n, rng, ctx):
        # Tail categories regenerated as synthetic labels TAIL_0001.. — realistic
        # cardinality without leaking rare (potentially identifying) real values.
        p_full = np.append(self.p, self.tail_mass)
        idx = rng.choice(len(p_full), size=n, p=p_full / p_full.sum())
        tails = np.array([f"TAIL_{i:04d}" for i in rng.integers(0, max(self.tail_card,1), n)])
        return np.where(idx < len(self.cats),
                        np.array(self.cats + ["_"])[np.minimum(idx, len(self.cats)-1)],
                        tails)
```

**Step 3.3 — Correlation preservation via Gaussian copula** (the piece that makes numerics *jointly* realistic):
```python
class CopulaSampler:
    """Sample correlated uniforms from the profiled correlation matrix,
    then push each through its column's inverse-CDF (the fitted marginal).
    Result: correct marginals AND correct pairwise correlations."""
    def __init__(self, corr: np.ndarray, marginals: list[FittedNumeric]):
        self.L = np.linalg.cholesky(nearest_pd(corr))   # PD repair for noisy corr
        self.marginals = marginals

    def generate(self, n, rng):
        z = rng.standard_normal((n, len(self.marginals))) @ self.L.T
        u = stats.norm.cdf(z)                            # correlated uniforms
        cols = [m.from_uniform(u[:, i]) for i, m in enumerate(self.marginals)]
        return np.column_stack(cols)
```

**Step 3.4 — FK generator with cardinality fidelity** (the piece Faker-only approaches get wrong):
```python
# src/syndata/generate/fk.py
class ParentKeySampler(ColumnGenerator):
    """Given generated parent keys and the profiled children-per-parent
    histogram: assign each parent a child count drawn from that histogram
    (scaled), then emit parent keys accordingly. Preserves the real shape:
    many zero-order customers, a few whales with 200 orders."""
    def __init__(self, parent_keys: np.ndarray, cardinality_hist: dict, zero_rate: float):
        self.parents, self.hist, self.zero_rate = parent_keys, cardinality_hist, zero_rate

    def plan_children(self, rng, scale: float) -> np.ndarray:
        counts = np.array(list(map(int, self.hist.keys())))
        probs  = np.array(list(self.hist.values()), float); probs /= probs.sum()
        active = rng.uniform(size=len(self.parents)) >= self.zero_rate
        per_parent = np.where(active, rng.choice(counts, len(self.parents), p=probs), 0)
        return np.round(per_parent * scale).astype(int)

    def generate_for_plan(self, per_parent: np.ndarray) -> np.ndarray:
        return np.repeat(self.parents, per_parent)       # exact FK integrity by construction
```

**Step 3.5 — Rule engine:**
```python
# src/syndata/generate/rules_engine.py
import pandas as pd

class RuleEngine:
    def __init__(self, rules: list[dict]):
        self.rules = rules

    def apply(self, table: str, df: pd.DataFrame, rng) -> pd.DataFrame:
        for r in (r for r in self.rules if r["table"] == table):
            ok = df.eval(_to_pandas_expr(r["expr"]))
            bad = ~ok
            if not bad.any():
                continue
            if r["on_violation"] == "repair":
                df = _apply_repair(df, bad, r["repair"], rng)   # e.g. ship_date = order_date + rand
            else:  # reject → resample rows up to 3 passes, then hard-drop remainder
                df = df[ok].reset_index(drop=True)
        return df
```

**Milestone:** on the 6-table fixture schema: `syndata generate` produces data where `test_fk_integrity` (zero orphans, exact) and `test_determinism` (same seed → identical parquet bytes) pass.

## PHASE 4 — ML Tables, Validation & Writers (Week 4)

**ML strategy (opt-in per table):** wrap SDV's `GaussianCopulaSynthesizer` (default) / `CTGANSynthesizer` (complex tables) behind the same `TableGenerator` interface; train in secure zone; the sampled rows then flow through the SAME FK sampler and rule engine as everything else (ML models produce *column values*; referential integrity remains structural).

**Validator:**
```python
# src/syndata/validate/fidelity.py
def fidelity_report(synth_df, stats_model, table):
    rows = []
    for col, prof in stats_model.columns(table).items():
        if prof.kind == "numeric":
            score = ks_distance(synth_df[col], prof)          # 0 = perfect
            rows.append((col, "KS", score, score < 0.10))
        elif prof.kind == "categorical":
            score = chi2_distance(synth_df[col], prof)
            rows.append((col, "chi2", score, score < 0.15))
    corr_delta = corr_matrix_delta(synth_df, stats_model.corr(table))
    rows.append(("__corr__", "maxΔ", corr_delta, corr_delta < 0.12))
    return rows
# Report levels: constraints=HARD FAIL, fidelity=WARN thresholds (tunable per table),
# privacy re-check=HARD FAIL. HTML report with red/amber/green per cell.
```

**Writers:** streaming batched inserts in topo order; SQL writer emits `SET session_replication_role = replica;` guard option for FK-checked loads or plain ordered inserts; Parquet per table; JSONL for Mongo with `link` fields resolved against generated relational keys.

**Milestone:** full pipeline on fixture schema → `report.html` all green; 1M-row benchmark under NFR-1.

## PHASE 5 — Hardening & Rollout (Week 5–6)

1. Run against a real (staging) schema of one consenting team; iterate on semantic detection misses and rule needs — expect 10–20 org-specific rules to surface.
2. CI integration recipe: `syndata generate --artifact v1.3 --seed $GITHUB_RUN_ID --target ci-postgres` as a pipeline step; teams get fresh, valid data per run.
3. Governance: artifact export requires privacy-audit PASS + data-owner sign-off recorded in `manifest.json`; artifacts versioned in an internal registry; quarterly re-profile cadence.

---

# 8. Testing Strategy

| Layer | Tests |
|---|---|
| Unit | fitters (fit synthetic samples from known dists, recover family); seed tree independence; rule DSL parser |
| **Integrity** | zero FK orphans on every fixture and every real run (hard CI gate); unique/PK/check compliance = 100% |
| **Determinism** | same config+seed → byte-identical output, including under 4-way parallel generation |
| **Fidelity regression** | fixture schema fidelity scores tracked in CI; PR fails if any score regresses > 20% |
| **Privacy** | memorization test on ML models (audit); synthetic-vs-real nearest-neighbor recheck on outputs; k-anon suppression unit tests |
| Scale | 30-table × 1M-row benchmark in nightly CI; memory ceiling asserted |

---

# 9. Deployment & Operations

- **Packaging:** single wheel + Docker image; CLI-first (`syndata profile|generate|validate`), no long-running service needed for v1. Optional thin FastAPI wrapper for "generate on demand" (same engine).
- **Secure-zone runs:** scheduled quarterly profiling job with read-only replica credentials; artifact publish gated on audit + human approval.
- **Monitoring:** per-run report archived; dashboard over run history (fidelity trend per table, generation throughput, constraint violations caught by validator — should be ~0 if generators are correct; a rise means a generator bug).
- **Runbook:**
  1. *"Load fails with FK violation"* → validator should have caught it; check for target-DB pre-existing rows (mode mismatch: append vs truncate_and_load) — 90% of cases.
  2. *"Synthetic data looks unrealistic for table X"* → check report: marginals green but correlations red → flag table `strategy: ml`; re-profile → regenerate.
  3. *"Privacy audit blocks export"* → audit_report names the table/model; raise K_ANON or drop the offending column to rule-based generation; never override the gate.

---

# 10. Project Plan Summary

| Week | Deliverable |
|---|---|
| 1 | Introspection (SQL + Mongo) + SchemaModel + topo planner |
| 2 | Profiler + privacy audit + artifact format |
| 2–3 | Generators: rule-based, statistical, copula, FK cardinality sampler, rule engine |
| 4 | ML table strategy + validator + writers + benchmark |
| 5–6 | Real-schema pilot, CI recipe, governance, docs |

**Definition of Done (v1):** one real team consuming synthetic data in CI daily; constraint compliance 100% across all runs; fidelity report ≥ green thresholds on their schema; privacy audit gate enforced with sign-off trail; determinism verified; 1M rows/15min met.
