# Implementation Guides — Master Index
## Three Production Systems, Fully Specified

This package contains **complete, org-standard implementation guides** for your three use cases. Each is written as a build manual: read it top to bottom, follow the phases, and you have a shippable system with architecture, code, tests, deployment, monitoring, and governance.

---

## What's In This Package

| File | System | Type | Difficulty | Timeline |
|------|--------|------|-----------|----------|
| `uc1-incident-routing-implementation.md` | **Intelligent Incident Routing** | ML (classification + fusion) | ★★ | 8 weeks to GA |
| `uc2-synthetic-data-implementation.md` | **Synthetic Data Generation Platform** | Data engineering + ML | ★★★ | 6 weeks to v1 |
| `uc3-vuln-fix-agent-implementation.md` | **Autonomous Vulnerability Remediation Agent** | Agentic AI | ★★★ | 7 weeks to v1 |

Each guide is self-contained and follows the same structure:
1. Executive Summary
2. Requirements (functional + non-functional + explicit non-goals)
3. Architecture (diagrams + component responsibilities + ADRs)
4. Sequence diagrams (main flow, feedback/failure flows)
5. Workflow diagrams
6. Data design
7. Repository structure (org-standard layout)
8. Step-by-step implementation (phased, with runnable code + milestones)
9. Testing strategy
10. Deployment
11. Monitoring & operations (dashboards, alerts, runbooks)
12. Security & governance
13. Project plan summary + Definition of Done

---

## How to Read the Diagrams

All diagrams use **Mermaid** syntax (```mermaid blocks). They render automatically in:
- GitHub / GitLab (paste the .md into a repo)
- VS Code (with the "Markdown Preview Mermaid Support" extension)
- Obsidian, Notion (paste), and most modern markdown viewers
- mermaid.live (paste a single diagram to view/export as PNG/SVG)

If your viewer doesn't render Mermaid, the diagrams are still readable as text, and you can paste any block into mermaid.live to get an image.

---

## Recommended Build Order

**Start with UC1 (Incident Routing).** Reasons:
- Shortest path to visible value (routing improves immediately)
- Exercises the ML fundamentals you'll reuse everywhere (features, evaluation, serving, monitoring)
- Lowest safety-blast-radius, so it's a gentle first production ML system

**Then UC3 (Vuln Agent).** Reasons:
- Highest strategic value + most impressive
- Reuses UC1's serving/monitoring patterns
- The safety-first ordering in its Phase 0 teaches you production agent discipline

**Then UC2 (Synthetic Data).** Reasons:
- Most self-contained (fewest external dependencies)
- Deepest single-domain engineering; benefits from momentum built on the first two

You can also run them in parallel if you have a team — they share almost no runtime coupling.

---

## Cross-Cutting Org Standards (applied in all three)

Every guide assumes and implements these, so they're consistent across your systems:

**Code & Config**
- Python 3.12, `pyproject.toml` with pinned deps, `ruff` for lint/format
- 12-factor config: `pydantic-settings`, env + YAML, secrets from vault (never in code/images)
- One shared logic path for train + serve (no skew) where ML is involved

**Testing (CI-gated)**
- Unit + integration + golden-set/eval gates on every PR
- The tests that matter most are called out explicitly per system (leak tests for UC1, integrity/determinism/privacy for UC2, safety gates for UC3)

**Deployment**
- Docker images, non-root user, health endpoints
- CI workflow: lint → test → eval-gate → build; scheduled workflows for retraining (UC1) / profiling (UC2) / remediation runs (UC3)
- Rollback in minutes (pinned artifact/model versions)

**Observability**
- Structured logs with correlation/trace IDs
- Dashboards for flow, quality, drift, cost
- Named alerts with thresholds + runbook actions
- Immutable audit trail for every automated decision

**Safety & Governance**
- Least-privilege service accounts
- Fail-open (UC1) or fail-safe-to-human (UC3) — never fail into a bad automated action
- Human-in-the-loop for anything irreversible, enforced by architecture not prompts (UC3 especially)
- Model/system documentation kept in-repo per release

---

## The Through-Line: These Map to Your Courses

If a concept in a guide is unfamiliar, the relevant course module is your reference:

| Guide concept | Course + Module |
|---|---|
| Feature engineering, leak-safe pipelines, evaluation, serving, drift | **ML Course** M2–7, M12, M23–25 |
| Text/embedding features, fusion | **ML Course** M14, M21 |
| Calibration, SHAP, imbalance | **ML Course** M22 |
| Agent loop, tools, stop conditions | **Agentic Course** M4–5 |
| Reflection / independent reviewer | **Agentic Course** M7 |
| Human-in-the-loop architecture | **Agentic Course** M10 |
| Long-horizon, idempotent, scheduled | **Agentic Course** M16.2 |
| Evals & golden sets | **Agentic Course** M17 |
| Safety, sandboxing, least privilege, injection/secret defense | **Agentic Course** M18 |
| Observability, deployment, cost | **Agentic Course** M19 |

Keep both course files open alongside these guides.

---

## First Week Checklist (whichever you start with)

- [ ] Read the full guide once, end to end, before writing code
- [ ] Set up the repo structure exactly as specified (Section 7 of each guide)
- [ ] Get the "hardest, most important" foundation working first:
  - UC1 → the leak-safe FeatureBuilder + leak tests (Phase 1)
  - UC2 → schema introspection + the two-zone privacy model (Phases 1–2)
  - UC3 → the safety foundations: scoped bot, kill switch, sandbox (Phase 0)
- [ ] Hit Milestone 0/1 with green tests before moving on
- [ ] Wire CI early so the eval/safety gates run on every commit from day one

---

## A Note on Adapting These

These guides are opinionated defaults reflecting good practice, not the only way. Where your org differs (different ITSM, different scanners, different git provider, different secret manager), the **adapter/interface boundaries** are already marked in each guide — swap the concrete implementation, keep the architecture. The ADR tables explain *why* each choice was made, so you can make informed deviations.

Build in phases. Hit milestones. Test the safety-critical paths hardest. Ship the smallest valuable version, then expand.

Go build.
