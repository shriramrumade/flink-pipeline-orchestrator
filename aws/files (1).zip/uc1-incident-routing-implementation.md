# UC1 — Intelligent Incident Routing System
## Complete Implementation Guide (Org-Standard)

**Version:** 1.0 · **Status:** Implementation-ready · **Owner:** ML Platform Team
**Goal:** Route incoming incident tickets to the correct owner group + application using the ticket description, 6 years of ticket history, and ELF logs — with confidence-based automation and human fallback.

---

# 1. Executive Summary

Incidents currently wait in a global queue until a human triager reads and assigns them. This system:
- **Auto-routes** high-confidence tickets (target ≥ 92% accuracy on auto-routed)
- **Suggests** a route with evidence for medium-confidence tickets (human confirms in one click)
- **Escalates** low-confidence tickets to the triage team with a pre-analysis attached

Expected impact: time-to-assignment from hours → minutes for ~70–80% of tickets; misroute rate below current human baseline; full audit trail for every decision.

---

# 2. Requirements

## 2.1 Functional Requirements

| ID | Requirement |
|----|-------------|
| FR-1 | Ingest new tickets via webhook from ITSM (ServiceNow/Jira/Remedy) within 5s of creation |
| FR-2 | Predict `owner_group` and `application` with a calibrated confidence score |
| FR-3 | Auto-assign when confidence ≥ T_auto (default 0.85); suggest when T_suggest ≤ conf < T_auto (default 0.60); escalate below |
| FR-4 | Every prediction includes top-3 candidates and human-readable evidence (top features / similar past tickets) |
| FR-5 | Capture reassignment events as feedback labels for retraining |
| FR-6 | Support manual re-run/override by triage team; overrides logged |
| FR-7 | Batch backfill mode for historical evaluation and shadow testing |
| FR-8 | Model retraining pipeline runnable on demand and on schedule (monthly) |

## 2.2 Non-Functional Requirements

| ID | Requirement |
|----|-------------|
| NFR-1 | P95 end-to-end routing latency < 3s (webhook → assignment written) |
| NFR-2 | Availability 99.5%; on failure, tickets fall through to the existing manual queue (fail-open, never fail-blocked) |
| NFR-3 | All predictions logged with model version, features hash, timestamp (audit + retraining) |
| NFR-4 | No PII leaves the org boundary; if LLM APIs are used, PII scrubbing precedes any external call |
| NFR-5 | Per-team accuracy monitored; drift alerts (PSI) on features and prediction distribution |
| NFR-6 | Rollback to previous model version < 5 minutes |
| NFR-7 | Secrets in vault/secret manager; no credentials in code or images |

## 2.3 Explicit Non-Goals (v1)
- Auto-*resolution* of tickets (routing only)
- Priority/severity prediction (phase 2)
- Real-time log streaming analysis (we use logs attached/linked at creation time)

---

# 3. Architecture

## 3.1 High-Level Architecture Diagram

```mermaid
flowchart LR
    subgraph Sources
        ITSM[ITSM System<br/>ServiceNow / Jira]
        ELF[ELF Log Store<br/>Elastic / Splunk]
        HIST[(Ticket History DB<br/>6 years)]
    end

    subgraph RoutingService["Routing Service (K8s / VM)"]
        API[FastAPI Ingest API<br/>/route /health /feedback]
        Q[[Job Queue<br/>Redis / SQS]]
        W[Router Worker]
        FE[Feature Builder]
        EMB[Embedding Service<br/>sentence-transformers]
        MODEL[Model Server<br/>LightGBM + calibrator]
        POL[Decision Policy<br/>thresholds + rules]
    end

    subgraph MLPlatform["ML Platform"]
        REG[(Model Registry<br/>MLflow)]
        TRAIN[Training Pipeline<br/>scheduled + on-demand]
        EVAL[Eval & Shadow Harness]
    end

    subgraph Storage
        FS[(Feature Store /<br/>aggregates cache)]
        LOGDB[(Prediction Log DB<br/>Postgres)]
        VEC[(Vector Index<br/>similar tickets)]
    end

    OBS[Monitoring<br/>Grafana + alerts]

    ITSM -- webhook: ticket.created --> API
    API --> Q --> W
    W --> FE
    FE --> HIST
    FE --> ELF
    FE --> FS
    FE --> EMB --> VEC
    W --> MODEL --> POL
    POL -- auto-assign / suggest / escalate --> ITSM
    W --> LOGDB
    ITSM -- reassignment events --> API
    API -- feedback --> LOGDB
    LOGDB --> TRAIN --> REG --> MODEL
    TRAIN --> EVAL
    LOGDB --> OBS
    MODEL --> OBS
```

## 3.2 Component Responsibilities

| Component | Responsibility | Tech |
|---|---|---|
| **Ingest API** | Receive webhooks, validate payload, enqueue, receive feedback events | FastAPI + Pydantic |
| **Job Queue** | Decouple ingestion from processing; absorb bursts; retries | Redis (RQ/Celery) or SQS |
| **Feature Builder** | Assemble the 3 feature families (text, history aggregates, log features); PII scrub | Python service module |
| **Embedding Service** | Encode description → vector; query similar historical tickets | sentence-transformers (self-hosted, no data egress) |
| **Model Server** | Load versioned pipeline (preprocessor + LightGBM + calibrator); predict proba per class | joblib artifact from registry |
| **Decision Policy** | Thresholds, per-team overrides, business rules (e.g., "security keywords always escalate to SecOps") | Config-driven Python |
| **Prediction Log DB** | Every prediction, decision, evidence, model version; feedback labels | Postgres |
| **Vector Index** | k-NN over historical ticket embeddings for "similar tickets" evidence | FAISS / pgvector |
| **Training Pipeline** | Rebuild dataset, train, calibrate, evaluate vs champion, register | Scheduled job (Airflow/GitHub Actions/cron) |
| **Eval & Shadow Harness** | Offline eval + shadow mode (predict silently on live traffic, compare to human) | Python + report |
| **Monitoring** | Latency, accuracy-by-team (as labels arrive), PSI drift, escalation rate | Grafana/Prometheus + SQL dashboards |

## 3.3 Key Architecture Decisions (ADR summary)

| # | Decision | Rationale | Alternative rejected |
|---|---|---|---|
| ADR-1 | Queue-based async processing | Webhooks must return in <1s; routing takes ~1–3s; bursts happen during outages (ironically the peak load moment) | Synchronous inline scoring — would drop tickets under load |
| ADR-2 | LightGBM on fused features (embeddings + tabular + log features), not end-to-end deep model | Tabular+embedding fusion is SOTA-competitive for this task, trains in minutes, explainable via SHAP, cheap to serve | Fine-tuned transformer end-to-end — costlier, slower, harder to explain, marginal gains |
| ADR-3 | Self-hosted embedding model | Ticket text contains internal system names and potentially PII; no data egress | External embedding API |
| ADR-4 | Fail-open design | A routing outage must degrade to "today's manual process," never block ticket flow | Fail-closed |
| ADR-5 | Two-headed prediction: separate models for `owner_group` and `application`, application conditioned on predicted group | Group taxonomy (~20–60 classes) is stabler than application (~hundreds); conditioning cuts application error | Single flat multi-class over group×app pairs — sparse classes, unstable |
| ADR-6 | Calibrated probabilities (isotonic) | Thresholds are business decisions; they only work if 0.85 means 85% | Raw scores |

---

# 4. Sequence Diagrams

## 4.1 Main Flow — New Ticket Routing

```mermaid
sequenceDiagram
    autonumber
    participant ITSM as ITSM (ServiceNow/Jira)
    participant API as Ingest API
    participant Q as Queue
    participant W as Router Worker
    participant FB as Feature Builder
    participant H as History DB
    participant L as ELF Logs
    participant M as Model Server
    participant P as Decision Policy
    participant DB as Prediction Log

    ITSM->>API: POST /route (webhook: ticket.created)
    API->>API: validate schema, dedupe (idempotency key = ticket_id)
    API->>Q: enqueue(ticket_id, payload)
    API-->>ITSM: 202 Accepted (<1s)

    Q->>W: dequeue job
    W->>FB: build_features(ticket)
    FB->>FB: PII scrub description
    FB->>H: fetch reporter/app/CI history aggregates
    FB->>L: fetch logs linked to ticket window
    FB->>FB: parse logs → error codes, services, counts
    FB->>M: embed(description) + similar-ticket lookup
    FB-->>W: feature vector + evidence bundle

    W->>M: predict_proba(features)
    M-->>W: group probs + app probs (calibrated)
    W->>P: decide(probs, rules)

    alt confidence >= 0.85 (auto)
        P-->>ITSM: PATCH ticket: assignment_group=X, app=Y, worknote(evidence)
    else 0.60 <= confidence < 0.85 (suggest)
        P-->>ITSM: worknote: "Suggested: X (conf 0.74). Evidence: ..." + 1-click accept
    else confidence < 0.60 (escalate)
        P-->>ITSM: route to Triage queue + attach pre-analysis
    end

    W->>DB: log(prediction, decision, evidence, model_version, latency)
```

## 4.2 Feedback & Retraining Loop

```mermaid
sequenceDiagram
    autonumber
    participant ITSM as ITSM
    participant API as Ingest API
    participant DB as Prediction Log
    participant T as Training Pipeline
    participant E as Eval Harness
    participant R as Model Registry
    participant M as Model Server

    ITSM->>API: webhook: ticket.reassigned / ticket.closed
    API->>DB: upsert final_owner_group, final_application (ground truth)

    Note over T: Monthly schedule or manual trigger
    T->>DB: pull last N months predictions + finals
    T->>T: rebuild dataset (time-based split)
    T->>T: train challenger (same pipeline code)
    T->>E: evaluate challenger vs champion on holdout month
    alt challenger wins (accuracy + per-team floors)
        E->>R: register challenger as candidate
        R->>M: canary deploy 10% traffic
        E->>E: monitor canary 1 week
        E->>R: promote to champion OR rollback
    else champion holds
        E->>DB: log eval report; no deploy
    end
```

## 4.3 Failure Handling Flow

```mermaid
sequenceDiagram
    autonumber
    participant ITSM as ITSM
    participant API as Ingest API
    participant W as Worker
    participant DB as Prediction Log

    ITSM->>API: POST /route
    alt API down
        ITSM->>ITSM: webhook retry (ITSM-side, exp backoff)
        Note over ITSM: after max retries, ticket stays in<br/>default manual queue = FAIL-OPEN
    end
    API->>W: job
    alt feature source down (History DB / ELF)
        W->>W: degrade: predict on available features,<br/>cap confidence at 0.59 → forced suggest/escalate
        W->>DB: log degraded_mode=true
    end
    alt model artifact corrupt / load failure
        W->>ITSM: no-op (ticket remains in manual queue)
        W->>DB: log failure + page on-call
    end
```

---

# 5. Workflow (Decision Policy) Diagram

```mermaid
flowchart TD
    A[Ticket arrives] --> B{Hard rules first}
    B -- security keywords<br/>(breach, CVE, phishing) --> SEC[Escalate to SecOps queue<br/>ALWAYS, regardless of model]
    B -- VIP reporter / P1 --> TRI1[Model runs, but decision<br/>= suggest-only, never auto]
    B -- normal --> C[Build features]
    C --> D[Predict group + app<br/>calibrated probabilities]
    D --> E{max confidence}
    E -- ">= 0.85" --> F{Predicted team opted in<br/>to auto-routing?}
    F -- yes --> G[AUTO-ASSIGN<br/>+ evidence worknote]
    F -- no --> H[SUGGEST]
    E -- "0.60 – 0.85" --> H[SUGGEST<br/>top-3 + evidence, 1-click accept]
    E -- "< 0.60" --> I[ESCALATE to Triage<br/>+ pre-analysis attached]
    G --> J[Log decision]
    H --> J
    I --> J
    SEC --> J
    J --> K{Reassigned later?}
    K -- yes --> L[Feedback label captured<br/>counts as model miss]
    K -- no --> M[Confirmed label<br/>on ticket close]
```

**Policy notes (org-standard details that matter):**
- **Team opt-in:** teams enroll in auto-routing gradually. Until a team opts in, they get suggestions only. This converts a political rollout problem into a product feature.
- **Hard rules always precede ML.** Security, legal, and P1 handling are deterministic and auditable.
- **Every decision writes an evidence worknote** — the top SHAP features in plain English plus 2 similar historical tickets. Evidence is what earns trust and adoption.

---

# 6. Data Design

## 6.1 Prediction Log Schema (Postgres)

```sql
CREATE TABLE routing_predictions (
    id                BIGSERIAL PRIMARY KEY,
    ticket_id         TEXT NOT NULL,
    received_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    model_version     TEXT NOT NULL,
    features_hash     TEXT NOT NULL,            -- reproducibility
    degraded_mode     BOOLEAN NOT NULL DEFAULT FALSE,

    pred_group        TEXT NOT NULL,
    pred_group_conf   REAL NOT NULL,
    pred_app          TEXT,
    pred_app_conf     REAL,
    top3_groups       JSONB NOT NULL,           -- [{group, conf}, ...]
    evidence          JSONB NOT NULL,           -- shap top features + similar tickets

    decision          TEXT NOT NULL CHECK (decision IN ('auto','suggest','escalate','rule_security','rule_vip')),
    latency_ms        INTEGER NOT NULL,

    -- feedback (filled later)
    final_group       TEXT,
    final_app         TEXT,
    was_reassigned    BOOLEAN,
    feedback_at       TIMESTAMPTZ,

    UNIQUE (ticket_id, model_version)
);
CREATE INDEX idx_pred_received ON routing_predictions (received_at);
CREATE INDEX idx_pred_feedback ON routing_predictions (final_group) WHERE final_group IS NOT NULL;
```

## 6.2 Feature Families

| Family | Features (examples) | Source | Leak risk notes |
|---|---|---|---|
| **Text** | 384-d sentence embedding of scrubbed description; length; language; has_stacktrace flag; keyword flags | Ticket payload | Description as-entered at creation only — never later worknotes |
| **Reporter history** | tickets last 90d/1y; top-3 groups their tickets resolved to (rates); dept | History DB | Aggregates computed over data strictly BEFORE ticket timestamp |
| **App/CI signals** | CI mentioned in payload; that CI's historical group distribution; recent change records on CI | CMDB + History | Same as-of-time discipline |
| **Log features** | count by severity; distinct services; top error codes (hashed vocab); burst score vs baseline; anomaly flag (IsolationForest) | ELF store, window = [t-2h, t] | Only logs timestamped BEFORE ticket creation |
| **Temporal** | hour, weekday, is_business_hours, is_change_window | Derived | none |

**The as-of-time rule is the whole ballgame.** Every historical aggregate must be computed as of the ticket's creation timestamp. Training must reproduce exactly what serving will see. This is enforced in code by a single shared `FeatureBuilder` used by BOTH training and serving (no train/serve skew by construction).

---

# 7. Repository Structure (Org-Standard)

```
incident-router/
├── README.md
├── pyproject.toml                  # pinned deps, ruff/black config
├── Makefile                        # make train / serve / test / eval
├── .env.example
├── configs/
│   ├── settings.yaml               # thresholds, queues, endpoints
│   └── policy.yaml                 # hard rules, team opt-ins
├── src/incident_router/
│   ├── __init__.py
│   ├── settings.py                 # pydantic-settings (env + yaml)
│   ├── schemas.py                  # Pydantic request/response/domain models
│   ├── pii.py                      # scrubbing
│   ├── features/
│   │   ├── builder.py              # THE shared FeatureBuilder (train+serve)
│   │   ├── text.py                 # embeddings, text stats
│   │   ├── history.py              # as-of-time aggregates
│   │   └── logs.py                 # ELF parsing + anomaly score
│   ├── model/
│   │   ├── train.py                # training entrypoint
│   │   ├── predictor.py            # load artifact, predict, explain
│   │   ├── calibrate.py
│   │   └── evaluate.py             # offline eval + champion/challenger
│   ├── policy.py                   # decision policy engine
│   ├── service/
│   │   ├── api.py                  # FastAPI app
│   │   ├── worker.py               # queue consumer
│   │   └── itsm_client.py          # ServiceNow/Jira adapter
│   ├── store/
│   │   ├── prediction_log.py       # Postgres repository
│   │   └── vector_index.py         # similar-ticket search
│   └── monitoring/
│       ├── drift.py                # PSI jobs
│       └── metrics.py              # Prometheus exporters
├── training/
│   ├── build_dataset.py            # historical dataset with as-of features
│   └── backfill_shadow.py          # shadow-mode evaluation
├── tests/
│   ├── test_features_no_leak.py    # ← the tests that matter most
│   ├── test_policy.py
│   ├── test_api.py
│   └── golden/                     # 60+ golden tickets with expected routes
├── deploy/
│   ├── Dockerfile
│   ├── docker-compose.yaml         # local: api + worker + redis + postgres
│   └── k8s/                        # manifests / helm chart
└── .github/workflows/
    ├── ci.yaml                     # lint, tests, golden-eval gate
    └── retrain.yaml                # scheduled retraining
```

---

# 8. Step-by-Step Implementation

> Follow phases in order. Each phase ends with a verifiable milestone. Code below is complete for the core path; adapters (ServiceNow vs Jira) are shown as interfaces with one concrete example.

## PHASE 0 — Foundations (Day 1–2)

**Step 0.1 — Settings (12-factor, org-standard):**
```python
# src/incident_router/settings.py
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    env: str = "dev"
    # thresholds
    t_auto: float = 0.85
    t_suggest: float = 0.60
    # infra
    redis_url: str = "redis://localhost:6379/0"
    pg_dsn: str = "postgresql://router:router@localhost:5432/router"
    itsm_base_url: str = ""
    itsm_token: str = ""            # injected from vault, never committed
    elf_base_url: str = ""
    # model
    model_uri: str = "models/champion"   # MLflow URI or local path
    embed_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    class Config:
        env_prefix = "ROUTER_"
        env_file = ".env"

settings = Settings()
```

**Step 0.2 — Domain schemas (contracts first):**
```python
# src/incident_router/schemas.py
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Literal

class TicketIn(BaseModel):
    ticket_id: str
    created_at: datetime
    description: str = Field(min_length=1, max_length=20000)
    reporter_id: str
    ci: str | None = None                 # configuration item if provided
    priority: Literal["P1","P2","P3","P4"] = "P3"
    log_refs: list[str] = []              # ELF query refs / correlation ids

class Candidate(BaseModel):
    group: str
    confidence: float

class Evidence(BaseModel):
    top_features: list[dict]              # [{"feature": "...", "impact": 0.31, "text": "human readable"}]
    similar_tickets: list[dict]           # [{"ticket_id": "...", "group": "...", "similarity": 0.91}]

class RoutingDecision(BaseModel):
    ticket_id: str
    model_version: str
    decision: Literal["auto","suggest","escalate","rule_security","rule_vip"]
    pred_group: str
    pred_group_conf: float
    pred_app: str | None
    pred_app_conf: float | None
    top3: list[Candidate]
    evidence: Evidence
    degraded_mode: bool = False
    latency_ms: int
```

**Step 0.3 — PII scrubbing (runs before ANY model or storage touch):**
```python
# src/incident_router/pii.py
import re

PATTERNS = [
    (re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"), "<EMAIL>"),
    (re.compile(r"\b(?:\+?\d{1,3}[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)\d{3}[-.\s]?\d{4}\b"), "<PHONE>"),
    (re.compile(r"\b(?:\d[ -]*?){13,19}\b"), "<CARD>"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "<SSN>"),
    # add org-specific: employee IDs, hostnames-with-usernames, etc.
]

def scrub(text: str) -> str:
    for pat, repl in PATTERNS:
        text = pat.sub(repl, text)
    return text
```

**Milestone 0 ✅:** `pytest tests/` green on schema + scrub tests; `.env.example` documented.

---

## PHASE 1 — Historical Dataset & Leak-Safe Features (Week 1)

This phase is 50% of project success. Slow down here.

**Step 1.1 — Export raw history.** One row per ticket over 6 years: `ticket_id, created_at, description_at_creation, reporter_id, ci, priority, final_group, final_application, log_refs`. Two traps:
- Use the description **as entered at creation** (ITSM audit tables have field history — pull the first value, not the current one, which triagers may have edited).
- `final_group` = the group that actually resolved it, not the first assignment.

**Step 1.2 — The shared FeatureBuilder (train AND serve use this exact class):**
```python
# src/incident_router/features/builder.py
import hashlib, json
import numpy as np
from datetime import datetime, timedelta
from .text import TextFeaturizer
from .history import HistoryFeaturizer
from .logs import LogFeaturizer
from ..pii import scrub

class FeatureBuilder:
    """Single source of truth for features. Same code path in training
    (with as_of=ticket.created_at over historical stores) and serving
    (with as_of=now over live stores). This is the anti-skew design."""

    def __init__(self, text: TextFeaturizer, history: HistoryFeaturizer, logs: LogFeaturizer):
        self.text, self.history, self.logs = text, history, logs

    def build(self, ticket) -> tuple[np.ndarray, dict, dict]:
        desc = scrub(ticket.description)
        as_of = ticket.created_at

        f_text, text_meta = self.text.features(desc)                 # 384-d emb + stats
        f_hist = self.history.features(ticket.reporter_id, ticket.ci, as_of=as_of)
        f_logs, degraded = self.logs.features(ticket.log_refs, window_end=as_of)

        vec = np.concatenate([f_text, f_hist, f_logs]).astype(np.float32)
        meta = {
            "features_hash": hashlib.sha256(vec.tobytes()).hexdigest()[:16],
            "degraded": degraded,
            "similar": text_meta.get("similar", []),
        }
        names = self.text.names() + self.history.names() + self.logs.names()
        return vec, meta, dict(zip(names, vec.tolist()))
```

**Step 1.3 — As-of-time history aggregates (the leak-critical code):**
```python
# src/incident_router/features/history.py
import numpy as np

class HistoryFeaturizer:
    def __init__(self, history_repo, group_vocab: list[str]):
        self.repo = history_repo
        self.groups = group_vocab                    # fixed, versioned with the model

    def features(self, reporter_id: str, ci: str | None, as_of) -> np.ndarray:
        # EVERY query is bounded by created_at < as_of. Non-negotiable.
        rep = self.repo.reporter_group_rates(reporter_id, before=as_of, days=365)
        ci_rates = self.repo.ci_group_rates(ci, before=as_of, days=730) if ci else {}
        recent_changes = self.repo.ci_change_count(ci, before=as_of, days=7) if ci else 0

        rep_vec = np.array([rep.get(g, 0.0) for g in self.groups])
        ci_vec  = np.array([ci_rates.get(g, 0.0) for g in self.groups])
        extras  = np.array([
            self.repo.reporter_ticket_count(reporter_id, before=as_of, days=90),
            float(recent_changes),
            1.0 if ci else 0.0,
        ])
        return np.concatenate([rep_vec, ci_vec, extras])

    def names(self):
        return ([f"reporter_rate::{g}" for g in self.groups]
              + [f"ci_rate::{g}" for g in self.groups]
              + ["reporter_90d_count", "ci_changes_7d", "has_ci"])
```

**Step 1.4 — Log features:**
```python
# src/incident_router/features/logs.py
import numpy as np
from sklearn.ensemble import IsolationForest

SEVERITIES = ["FATAL", "ERROR", "WARN", "INFO"]
ERROR_CODE_BUCKETS = 64          # hashed vocab — stable across unseen codes

class LogFeaturizer:
    def __init__(self, elf_client, anomaly_model: IsolationForest | None = None):
        self.elf = elf_client
        self.anomaly = anomaly_model

    def features(self, log_refs: list[str], window_end) -> tuple[np.ndarray, bool]:
        degraded = False
        try:
            entries = self.elf.fetch(log_refs, start=window_end - timedelta(hours=2),
                                     end=window_end)     # BEFORE ticket only
        except Exception:
            entries, degraded = [], True                  # fail-open, flag degraded

        sev_counts = np.array([sum(1 for e in entries if e.severity == s) for s in SEVERITIES], float)
        services   = len({e.service for e in entries})
        codes = np.zeros(ERROR_CODE_BUCKETS)
        for e in entries:
            if e.error_code:
                codes[hash(e.error_code) % ERROR_CODE_BUCKETS] += 1
        burst = sev_counts[:2].sum() / max(len(entries), 1)        # error density
        base = np.concatenate([np.log1p(sev_counts), [services, burst], np.log1p(codes)])
        anom = [float(-self.anomaly.score_samples([base])[0])] if self.anomaly else [0.0]
        return np.concatenate([base, anom]), degraded

    def names(self):
        return ([f"log_sev_{s}" for s in SEVERITIES] + ["log_services", "log_burst"]
              + [f"log_code_b{i}" for i in range(ERROR_CODE_BUCKETS)] + ["log_anomaly"])
```

**Step 1.5 — Build the training dataset:**
```python
# training/build_dataset.py
"""For each historical ticket, run the SAME FeatureBuilder with
as_of = ticket.created_at against historical stores. Emits X.npy, y_group.npy,
y_app.npy, meta.parquet. Runtime note: batch/parallelize; cache reporter/CI
aggregates by (entity, week) to avoid O(n) DB scans per ticket."""
```

**Step 1.6 — The leak tests (these run in CI forever):**
```python
# tests/test_features_no_leak.py
def test_history_queries_bounded_by_as_of(history_repo_spy, builder, sample_ticket):
    builder.build(sample_ticket)
    for q in history_repo_spy.queries:
        assert q.before <= sample_ticket.created_at, f"LEAK: {q}"

def test_log_window_ends_at_creation(elf_spy, builder, sample_ticket):
    builder.build(sample_ticket)
    assert elf_spy.last_call.end <= sample_ticket.created_at

def test_description_is_creation_snapshot(dataset_row):
    assert dataset_row.description_source == "audit_first_value"
```

**Milestone 1 ✅:** dataset built for 6 years; leak tests green; dataset stats report written (class distribution per year — expect taxonomy drift, see Phase 2).

---

## PHASE 2 — Model Training & Evaluation (Week 2)

**Step 2.1 — Handle taxonomy drift first.** Over 6 years, teams renamed/merged/split. Build `group_mapping.yaml` (old → current) with a human owner; drop tickets whose group no longer exists and can't be mapped. Report how much data survives per class; classes with <200 examples get merged into a per-domain `OTHER_*` bucket that always routes to suggest (never auto).

**Step 2.2 — Train (time-based split, two heads, calibration):**
```python
# src/incident_router/model/train.py
import json, joblib, numpy as np, lightgbm as lgb, mlflow
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import accuracy_score, top_k_accuracy_score

def temporal_split(meta, X, y, train_end="2025-06-30", val_end="2025-12-31"):
    tr = meta.created_at <= train_end
    va = (meta.created_at > train_end) & (meta.created_at <= val_end)
    te = meta.created_at > val_end                      # most recent ≈ production reality
    return (X[tr], y[tr]), (X[va], y[va]), (X[te], y[te])

def train(X, y_group, y_app, meta, out_dir="models/candidate"):
    (Xtr, ytr), (Xva, yva), (Xte, yte) = temporal_split(meta, X, y_group)

    group_model = lgb.LGBMClassifier(
        objective="multiclass", n_estimators=2000, learning_rate=0.05,
        num_leaves=63, min_child_samples=30, subsample=0.9,
        colsample_bytree=0.8, class_weight="balanced", verbose=-1)
    group_model.fit(Xtr, ytr, eval_set=[(Xva, yva)],
                    callbacks=[lgb.early_stopping(100), lgb.log_evaluation(200)])

    # Calibrate on validation (prefit) — thresholds depend on this
    calibrated = CalibratedClassifierCV(group_model, method="isotonic", cv="prefit")
    calibrated.fit(Xva, yva)

    # App head: same recipe, with predicted-group one-hot appended (conditioning)
    # ... (identical pattern, omitted for brevity — see repo)

    proba = calibrated.predict_proba(Xte)
    report = {
        "test_top1": accuracy_score(yte, proba.argmax(1)),
        "test_top3": top_k_accuracy_score(yte, proba, k=3),
        "n_test": len(yte),
    }
    # Per-class table — the number teams will ask about
    # ... classification_report per group into report["per_group"]

    joblib.dump({"model": calibrated, "feature_names": FEATURE_NAMES,
                 "group_vocab": GROUPS, "version": VERSION}, f"{out_dir}/pipeline.joblib")
    json.dump(report, open(f"{out_dir}/eval_report.json", "w"), indent=2)

    with mlflow.start_run():
        mlflow.log_metrics({k: v for k, v in report.items() if isinstance(v, float)})
        mlflow.log_artifact(f"{out_dir}/pipeline.joblib")
    return report
```

**Step 2.3 — Simulate the policy offline (this produces the business numbers):**
```python
# src/incident_router/model/evaluate.py
def simulate_policy(proba, y_true, t_auto=0.85, t_suggest=0.60):
    conf = proba.max(1); pred = proba.argmax(1)
    auto = conf >= t_auto
    sugg = (conf >= t_suggest) & ~auto
    esc  = conf < t_suggest
    return {
        "auto_share":      float(auto.mean()),
        "auto_accuracy":   float((pred[auto] == y_true[auto]).mean()) if auto.any() else None,
        "suggest_share":   float(sugg.mean()),
        "suggest_top3_hit": float(top3_hit(proba[sugg], y_true[sugg])),
        "escalate_share":  float(esc.mean()),
    }
# Sweep t_auto in [0.7..0.95]; plot auto_share vs auto_accuracy.
# Pick the threshold meeting the org bar (≥92% auto accuracy), report the coverage.
```

**Acceptance gate for Phase 2:** auto-accuracy ≥ 92% at whatever coverage that yields (typically 40–65% initially — that's fine, coverage grows with retraining) AND every individual team in auto-mode has ≥ 88% accuracy (per-team floor; teams below the floor stay in suggest mode — encode this in `policy.yaml`).

**Milestone 2 ✅:** eval report + threshold sweep committed; per-team table reviewed with 2–3 pilot team leads.

---

## PHASE 3 — Serving (Week 3)

**Step 3.1 — API:**
```python
# src/incident_router/service/api.py
from fastapi import FastAPI, HTTPException
from redis import Redis
from rq import Queue
from ..schemas import TicketIn
from ..settings import settings

app = FastAPI(title="incident-router")
q = Queue("routing", connection=Redis.from_url(settings.redis_url))

@app.post("/route", status_code=202)
def route(ticket: TicketIn):
    # Idempotency: same ticket_id enqueued once
    if q.fetch_job(ticket.ticket_id):
        return {"status": "duplicate_ignored"}
    q.enqueue("incident_router.service.worker.process", ticket.model_dump(),
              job_id=ticket.ticket_id, retry=Retry(max=3, interval=[10, 60, 300]))
    return {"status": "queued"}

@app.post("/feedback")
def feedback(ticket_id: str, final_group: str, final_app: str | None = None):
    prediction_log.record_feedback(ticket_id, final_group, final_app)
    return {"status": "ok"}

@app.get("/health")
def health():
    return {"status": "ok", "model_version": predictor.version}
```

**Step 3.2 — Worker (the agentic core):**
```python
# src/incident_router/service/worker.py
import time
from ..schemas import TicketIn, RoutingDecision
from ..policy import decide
from ..model.predictor import Predictor
from .itsm_client import ITSMClient

predictor = Predictor.load(settings.model_uri)      # loads pipeline + SHAP explainer
itsm = ITSMClient(settings)

def process(payload: dict):
    t0 = time.monotonic()
    ticket = TicketIn(**payload)

    vec, meta, named = feature_builder.build(ticket)
    probs, top3, evidence = predictor.predict_with_evidence(vec, named, meta)

    decision = decide(ticket, probs, top3, degraded=meta["degraded"])   # policy.yaml rules

    latency = int((time.monotonic() - t0) * 1000)
    result = RoutingDecision(ticket_id=ticket.ticket_id, model_version=predictor.version,
                             decision=decision.kind, pred_group=decision.group,
                             pred_group_conf=decision.conf, pred_app=decision.app,
                             pred_app_conf=decision.app_conf, top3=top3,
                             evidence=evidence, degraded_mode=meta["degraded"],
                             latency_ms=latency)
    prediction_log.write(result)                     # log BEFORE acting (audit-first)

    if decision.kind == "auto":
        itsm.assign(ticket.ticket_id, decision.group, decision.app,
                    worknote=render_evidence(evidence, decision))
    elif decision.kind == "suggest":
        itsm.add_suggestion(ticket.ticket_id, top3, render_evidence(evidence, decision))
    else:
        itsm.route_to_triage(ticket.ticket_id, render_preanalysis(top3, evidence))
```

**Step 3.3 — Policy engine (config-driven):**
```yaml
# configs/policy.yaml
hard_rules:
  - name: security_keywords
    match: {description_regex: "(?i)(breach|phishing|ransom|cve-\\d{4})"}
    action: {decision: rule_security, route_to: SEC_OPS}
  - name: p1_never_auto
    match: {priority: P1}
    action: {max_decision: suggest}
thresholds: {t_auto: 0.85, t_suggest: 0.60}
auto_enabled_groups: [PLATFORM_DB, NETWORK_CORE, APP_PAYMENTS]   # opt-in grows over time
degraded_mode: {max_decision: suggest}
```

**Step 3.4 — Evidence rendering (adoption depends on this):**
```
🤖 Routing suggestion: PLATFORM_DB (confidence 74%)
Why: description mentions "connection pool exhausted" (strong signal for PLATFORM_DB);
reporter's last 12 tickets: 9 resolved by PLATFORM_DB; ELF shows ERROR burst on
service db-proxy in the 2h before this ticket.
Similar past tickets: INC0482113 (PLATFORM_DB), INC0511990 (PLATFORM_DB).
Also possible: APP_PAYMENTS (14%), NETWORK_CORE (6%).
[Accept PLATFORM_DB] [Pick other] [Send to triage]
```

**Milestone 3 ✅:** `docker-compose up` runs api+worker+redis+postgres locally; golden-ticket suite (60 curated tickets incl. security-rule and degraded-mode cases) passes in CI.

---

## PHASE 4 — Shadow Mode → Pilot → GA (Weeks 4–8)

| Stage | Duration | What happens | Exit criteria |
|---|---|---|---|
| **Shadow** | 2 weeks | System predicts on all live tickets, writes to log DB, takes NO action. Humans route as today | Shadow accuracy ≥ offline test accuracy − 2pts; latency P95 < 3s; zero crashes |
| **Suggest-only pilot** | 2 weeks | 3 volunteer teams see suggestions | ≥ 80% suggestion acceptance in pilot teams |
| **Auto for pilot teams** | 2 weeks | Auto-routing on for opted-in pilot teams | Auto accuracy ≥ 92%; reassignment rate ≤ human baseline |
| **GA rollout** | ongoing | Teams opt in wave by wave; weekly report per team | — |

Shadow mode is non-negotiable: it's the only honest test of the as-of-time features against live infrastructure, and it produces the per-team evidence that persuades team leads to opt in.

---

# 9. Testing Strategy

| Layer | Tests |
|---|---|
| Unit | scrubber patterns; policy rules; log parser on fixture logs; feature name/vector alignment |
| **Leak tests** | as-of bounds enforced (Phase 1.6) — these are release blockers, forever |
| Golden set | 60+ curated tickets → expected decision class; runs in CI on every PR (agentic-course Module 17 style) |
| Contract | ITSM adapter against recorded webhook fixtures (VCR-style) |
| Load | 50 tickets/min burst (outage simulation); queue drains within SLA |
| Chaos | kill ELF connection mid-run → assert degraded_mode + suggest-cap, never a crash or auto-route |

---

# 10. Deployment

```dockerfile
# deploy/Dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY pyproject.toml .
RUN pip install --no-cache-dir .
COPY src/ src/
COPY configs/ configs/
# non-root, org-standard
RUN useradd -m runner && chown -R runner /app
USER runner
CMD ["uvicorn", "incident_router.service.api:app", "--host", "0.0.0.0", "--port", "8080"]
```

```yaml
# .github/workflows/ci.yaml (essentials)
name: ci
on: [pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {python-version: "3.12"}
      - run: pip install .[dev]
      - run: ruff check . && ruff format --check .
      - run: pytest -q --maxfail=1
      - name: Golden-set gate
        run: python -m incident_router.model.evaluate --golden tests/golden --min-pass 0.95
```

K8s: 2× api replicas, 3× worker replicas (HPA on queue depth), Redis + Postgres managed services, secrets via ExternalSecrets/vault, model artifact pulled from registry at pod start with version pinned in the deployment manifest (rollback = redeploy previous manifest, < 5 min).

---

# 11. Monitoring & Operations

**Dashboards (Grafana over Postgres + Prometheus):**
1. **Flow:** tickets/hour by decision class; queue depth; latency P50/P95
2. **Quality (label-delayed):** auto-accuracy 7d rolling, per team; suggestion acceptance rate; reassignment rate vs human baseline
3. **Drift:** PSI on top-20 features weekly (agentic Module 25 pattern); prediction-distribution shift; degraded-mode rate
4. **Cost/infra:** worker CPU, embedding latency

**Alerts:**
| Alert | Threshold | Action |
|---|---|---|
| Auto-accuracy (any opted-in team, 7d) | < 88% | Auto-disable that team's auto mode (policy flag), notify owner |
| Degraded-mode rate | > 10% / 1h | Page: a feature source is down |
| Queue depth | > 500 for 10 min | Scale workers; check ITSM webhook storm |
| PSI any top feature | > 0.25 | Open retraining ticket |
| Prediction distribution shift | KL > threshold | Investigate taxonomy change / new incident type |

**Runbook (top 3 scenarios):**
1. *"Team X says routing got worse"* → dashboard 2 filtered to team → pull last 20 misses from `routing_predictions` with evidence → usually: new app/service name the model hasn't seen → add to next retrain; flip team to suggest-only meanwhile (one YAML line).
2. *"ELF is down"* → system already degraded gracefully (suggest-cap); verify degraded-rate alert fired; no action needed beyond ELF recovery.
3. *"Roll back the model"* → `kubectl apply -f deploy/k8s/previous-release.yaml` (model URI pinned per release); verify `/health` shows previous version; post-incident: eval report comparison.

---

# 12. Security & Governance

- PII scrubbed before embedding, storage, or any model call (Phase 0.3); scrub patterns owned by security team and unit-tested.
- Embedding model self-hosted → no ticket text leaves the org (ADR-3).
- ITSM service account: scoped to read tickets + write assignment/worknotes on incident table only (least privilege — agentic-course Module 18 discipline).
- Every decision auditable: prediction log row contains model version, features hash, evidence, and decision — answerable to "why did ticket X go to team Y on date Z?"
- Model documentation: eval report + per-team table + known limitations kept in repo per release (model card).
- Access: prediction log contains scrubbed text only; RBAC same as ITSM roles.

---

# 13. Project Plan Summary

| Week | Deliverable |
|---|---|
| 1 | Dataset + leak-safe FeatureBuilder + leak tests (Milestone 1) |
| 2 | Trained/calibrated models + threshold sweep + per-team review (Milestone 2) |
| 3 | Serving stack local-complete + golden CI gate (Milestone 3) |
| 4–5 | Shadow mode live; shadow report |
| 6–7 | Suggest-only pilot (3 teams); acceptance ≥ 80% |
| 8 | Auto-routing for pilot teams; GA wave plan |
| Monthly | Retrain via champion/challenger (Section 4.2) |

**Definition of Done (v1):** shadow-validated model in production; ≥ 3 teams on auto-routing at ≥ 92% accuracy; monitoring + alerts live; runbook tested in one game-day; retraining pipeline executed at least once end-to-end.
