# UC3 — Autonomous Vulnerability Remediation Agent
## Complete Implementation Guide (Org-Standard)

**Version:** 1.0 · **Status:** Implementation-ready · **Owner:** AppSec + Platform Engineering
**Goal:** On a schedule (and on demand), ingest security scan reports, locate the vulnerable code in a repository, generate a minimal safe fix, validate it (build + tests + security re-scan), and open a pull request to the target branch — with human approval as a hard, architectural gate before any merge.

> This is a true agent (agentic-course Level 4–5). The single most important design principle, stated up front: **the agent can propose but never merge.** Approval is enforced by permissions and branch protection, not by prompt instructions. Everything below is built around that guarantee.

---

# 1. Executive Summary

Security scanners produce more findings than teams can fix. This agent closes the loop for the *fixable* subset:
- **Ingests** findings from SAST/SCA/secret scanners (Semgrep, CodeQL, Snyk, Trivy, etc.) via their reports/APIs
- **Localizes** the exact vulnerable code (report line hints are often stale or imprecise) using AST analysis + semantic search
- **Fixes** using an LLM constrained by per-vulnerability-class playbooks, producing *minimal* diffs
- **Validates** in an isolated sandbox: syntax/build, existing tests, targeted new tests, linters, and a **re-scan proving the finding is gone and no new findings appeared**
- **Reviews** its own diff with an independent LLM pass against a security rubric
- **Opens a PR** to the specified branch with full evidence, requesting review from CODEOWNERS; **merge is 100% human**
- **Runs regularly** per branch via CI schedule, rate-limited to the team's review capacity, with dedup so it never re-opens a fix already pending

Scope discipline is the core safety mechanism: the agent only attempts **allowlisted, well-understood vulnerability classes with deterministic fix patterns** (e.g., SQL injection via parameterization, weak hashing, hardcoded secrets → vault refs, vulnerable dependency bumps, missing output encoding). Everything else is triaged and assigned to a human — never guessed at.

---

# 2. Requirements

## 2.1 Functional

| ID | Requirement |
|----|-------------|
| FR-1 | Ingest scan reports from ≥ 2 scanners (SARIF format preferred — normalize all to SARIF) |
| FR-2 | Deduplicate findings against (a) open agent PRs, (b) suppressed/accepted-risk registry, (c) already-fixed history |
| FR-3 | Classify each finding: `auto_fixable` (allowlisted class + confident localization) vs `human_triage` |
| FR-4 | Localize vulnerable code precisely (file, symbol, line span) even when report line is off/stale |
| FR-5 | Generate a minimal fix using the class-specific playbook; never broad refactors |
| FR-6 | Validate in an isolated, network-restricted sandbox: build/compile, run existing tests, run generated regression test, lint, and re-scan |
| FR-7 | Independent LLM security review of the diff against a rubric; must pass before PR |
| FR-8 | Open PR to a configured target branch (default: `main`; overridable per run) from a uniquely-named fix branch, requesting CODEOWNERS review |
| FR-9 | Run on schedule per repo/branch (cron) and on demand; batch findings; respect a max-open-PR cap per repo |
| FR-10 | Full audit trail: finding → localization → diff → validation results → review → PR link, per finding |
| FR-11 | Support multiple languages via pluggable per-language toolchain adapters (start: Python + JavaScript/TypeScript) |

## 2.2 Non-Functional (safety-critical)

| ID | Requirement |
|----|-------------|
| NFR-1 | **The agent's git credentials cannot merge.** PR-open + branch-push only; branch protection requires human approval + green CI for merge |
| NFR-2 | All code execution (build/tests/scan) in an ephemeral, network-restricted, resource-capped sandbox container; no org secrets mounted |
| NFR-3 | LLM never sees secrets: repo scanned for secrets and redacted before any code is sent to the model; secret-type findings handled by a deterministic (non-LLM) path |
| NFR-4 | Idempotent + rate-limited: never open duplicate PRs; cap N open PRs/repo (default 5); exponential backoff on failures |
| NFR-5 | Deterministic audit: every LLM call logged with prompt hash, model version, and output; reproducible decision record per finding |
| NFR-6 | A single kill switch disables all agent runs org-wide; per-repo enable flags |
| NFR-7 | Fail-safe: on any validation failure or low review confidence → no PR; finding routed to human with the agent's analysis attached |

## 2.3 Non-Goals (v1)
- Fixing logic/business-vulnerability classes requiring design judgment (auth bypass, complex IDOR) — triaged to humans
- Auto-merging under any condition
- Fixing across languages not covered by a toolchain adapter (routed to humans)

---

# 3. Architecture

## 3.1 High-Level Architecture

```mermaid
flowchart TB
    subgraph Triggers
        CRON[Scheduler<br/>cron per repo/branch]
        MAN[Manual trigger<br/>CLI / ChatOps]
    end

    subgraph Orchestrator["Remediation Orchestrator (Agent Runtime)"]
        INGEST[Scan Ingestor<br/>→ SARIF normalize]
        DEDUP[Dedup & Triage<br/>allowlist classifier]
        LOC[Localizer Agent<br/>AST + semantic search]
        FIX[Fix Generator Agent<br/>playbook-constrained LLM]
        REVIEW[Security Reviewer Agent<br/>independent LLM + rubric]
        PR[PR Composer<br/>branch + commit + PR]
        AUDIT[(Audit Store<br/>Postgres)]
        KILL{Kill switch /<br/>repo enable flags}
    end

    subgraph Sandbox["🔒 Ephemeral Sandbox (per finding)"]
        BUILD[Build / Compile]
        TEST[Test Runner<br/>existing + generated]
        LINT[Linters]
        RESCAN[Re-scan<br/>finding gone? new findings?]
    end

    subgraph External
        SCAN[Scanners<br/>Semgrep/CodeQL/Snyk/Trivy]
        REPO[(Git Provider<br/>GitHub/GitLab)]
        VAULT[Secret Manager]
        SUPP[(Suppression /<br/>accepted-risk registry)]
    end

    CRON --> KILL --> INGEST
    MAN --> KILL
    SCAN --> INGEST --> DEDUP
    DEDUP <--> SUPP
    DEDUP -- auto_fixable --> LOC --> FIX
    DEDUP -- human_triage --> REPO
    FIX --> Sandbox
    Sandbox --> REVIEW
    REVIEW -- pass --> PR --> REPO
    REVIEW -- fail --> REPO
    FIX -. reads redacted code .-> REPO
    PR -. bot token: push+PR only .-> REPO
    Orchestrator --> AUDIT
    VAULT -. sandbox: NO secrets .-x Sandbox
```

## 3.2 The Agent Pipeline (per finding)

```
finding → localize → fix → sandbox-validate → review → compose-PR
   │          │        │          │              │          │
  triage   AST +     playbook   build+test+    LLM+       branch+
  gate    semantic    LLM       lint+rescan    rubric     commit+PR
                                                          (human merges)
```

Each stage is a bounded step with a **stop condition**: any failure ends the pipeline for that finding and routes it to a human with everything gathered so far. No stage retries indefinitely; the agent-loop max-iteration discipline (agentic-course Module 5) applies to localization and fix-repair loops specifically.

## 3.3 Component Responsibilities

| Component | Responsibility | Key tech |
|---|---|---|
| **Scan Ingestor** | Pull/receive scanner outputs; normalize all to SARIF; extract (rule_id, severity, file, region, message, CWE) | SARIF parsers |
| **Dedup & Triage** | Fingerprint findings; drop already-open/suppressed/fixed; classify auto-fixable via allowlist + localization confidence | Rules + registry |
| **Localizer Agent** | Resolve the true vulnerable span: parse AST, match the sink pattern for the CWE, confirm with semantic search; produce a precise, minimal code context window | tree-sitter, embeddings |
| **Fix Generator Agent** | Given the class playbook + minimal context, produce a minimal unified diff; repair loop on validation feedback (bounded) | LLM (Claude/other) via provider SDK |
| **Sandbox** | Ephemeral container: apply diff, build, run existing + generated tests, lint, re-scan; return structured results; destroyed after | Docker, per-language images, no network egress except scanner DB if required (pinned) |
| **Security Reviewer Agent** | Independent LLM (different prompt/role) critiques the diff against a security + correctness rubric; PASS/REVISE/REJECT | LLM |
| **PR Composer** | Create fix branch, commit, push, open PR to target branch, request CODEOWNERS, attach evidence, apply labels | Git provider API, bot token |
| **Audit Store** | Immutable record of every finding's full journey | Postgres (append-only) |
| **Kill switch / flags** | Global stop + per-repo enablement | Config service / feature flags |

## 3.4 Architecture Decisions (safety-first)

| # | Decision | Rationale |
|---|---|---|
| ADR-1 | Bot identity has push + PR-open scopes only; branch protection mandates human approval + CI | Merge safety is structural, not behavioral. A compromised or misbehaving agent still cannot ship code |
| ADR-2 | Allowlist of vulnerability classes with deterministic fix patterns | Bounds the blast radius. LLM operates inside a narrow, well-understood envelope; unknown classes go to humans |
| ADR-3 | Localization is AST-first, LLM-second | Report line numbers drift; AST sink-matching is precise and cheap; the LLM fixes, it doesn't hunt |
| ADR-4 | Mandatory sandbox re-scan as a gate | Proves the fix actually removes the finding AND introduces no new findings — the only objective success signal |
| ADR-5 | Independent reviewer model with a different role/prompt | Generators are biased toward their own output; a separate critic (agentic-course Module 7 reflection) catches ~a third of bad fixes |
| ADR-6 | Secrets never reach the LLM; secret findings use a deterministic vault-reference rewrite | Sending code to a model is an egress; secret-bearing code must be redacted first, and secret remediation doesn't need an LLM |
| ADR-7 | One finding = one PR (batched only within a file when trivially independent) | Small reviewable PRs get approved; giant multi-fix PRs get ignored. Review capacity is the true bottleneck |
| ADR-8 | Ephemeral sandbox, no org secrets, no network egress | The agent runs untrusted-ish generated code; contain it like untrusted code |

---

# 4. Sequence Diagrams

## 4.1 Full Remediation Flow (one finding)

```mermaid
sequenceDiagram
    autonumber
    participant SCH as Scheduler
    participant ORC as Orchestrator
    participant ING as Ingestor
    participant DT as Dedup/Triage
    participant LOC as Localizer
    participant FIX as Fix Generator
    participant SBX as Sandbox
    participant REV as Reviewer
    participant PRC as PR Composer
    participant GIT as Git Provider
    participant AUD as Audit Store

    SCH->>ORC: run(repo, branch)  [kill-switch checked]
    ORC->>ING: get findings (scanners → SARIF)
    ING-->>ORC: normalized findings[]
    ORC->>DT: triage(findings)
    DT->>DT: fingerprint, dedup vs open PRs / suppressions
    DT-->>ORC: auto_fixable[], human_triage[]
    ORC->>AUD: log intake

    loop each auto_fixable (up to max_open_prs)
        ORC->>LOC: localize(finding)
        LOC->>LOC: AST sink-match + semantic confirm
        alt localization confident
            LOC-->>FIX: precise context + playbook(CWE)
            FIX->>FIX: generate minimal diff (secrets pre-redacted)
            loop repair (max 3)
                FIX->>SBX: apply diff → build+test+lint+rescan
                SBX-->>FIX: results
                alt all pass
                    FIX-->>REV: diff + validation evidence
                else fixable failure
                    FIX->>FIX: revise using sandbox feedback
                else unrecoverable
                    FIX-->>ORC: give up → human_triage
                end
            end
            REV->>REV: independent rubric critique
            alt REVIEW pass
                REV-->>PRC: approved diff + evidence
                PRC->>GIT: create branch, commit, push, open PR<br/>(bot token: NO merge) request CODEOWNERS
                GIT-->>PRC: PR url
                PRC->>AUD: log PR
            else REVIEW fail
                REV->>GIT: comment finding for humans (no PR)
                REV->>AUD: log rejection + reason
            end
        else localization unsure
            LOC-->>ORC: route to human with candidates
        end
    end
    ORC->>AUD: run summary
```

## 4.2 Scheduled Multi-Repo Run

```mermaid
sequenceDiagram
    autonumber
    participant CI as CI Scheduler (cron)
    participant ORC as Orchestrator
    participant CFG as Config (flags)
    participant GIT as Git Provider

    CI->>ORC: nightly trigger
    ORC->>CFG: list enabled repos/branches
    CFG-->>ORC: [(repoA,main),(repoB,develop),...]
    loop each enabled target
        ORC->>GIT: count open agent PRs
        alt under cap
            ORC->>ORC: run remediation flow (4.1)
        else at cap
            ORC->>ORC: skip (backpressure — humans behind on review)
        end
    end
    ORC->>ORC: emit metrics + digest to AppSec channel
```

## 4.3 Human Approval / Merge (outside the agent)

```mermaid
sequenceDiagram
    autonumber
    participant DEV as Reviewer (human)
    participant GIT as Git Provider
    participant CI as CI Pipeline

    GIT->>DEV: PR review requested (CODEOWNERS)
    DEV->>GIT: reads diff + agent evidence (validation, rescan, rubric)
    CI->>GIT: required checks run again (independent of agent sandbox)
    alt approve
        DEV->>GIT: approve
        DEV->>GIT: merge (ONLY humans can) 
    else request changes
        DEV->>GIT: comment
        Note over GIT: agent may pick up feedback next run,<br/>or human takes over
    end
```

## 4.4 Failure / Safety Flow

```mermaid
flowchart TD
    A[Any stage] --> B{Failure type}
    B -- sandbox build/test fail after max repairs --> H[No PR → human_triage<br/>+ attach diff & logs]
    B -- rescan: finding remains --> H
    B -- rescan: NEW finding introduced --> H2[No PR → human_triage<br/>flag regression risk]
    B -- reviewer REJECT --> H3[No PR → comment for humans]
    B -- localization unsure --> H4[Human triage w/ candidate spans]
    B -- secret in code path --> S[Deterministic vault-ref path<br/>never LLM]
    B -- unknown vuln class --> H5[Human triage, no fix attempt]
    B -- infra error (git/sandbox down) --> R[Backoff + retry next run<br/>idempotent, no dup PR]
```

---

# 5. Vulnerability Class Allowlist (the safety envelope)

Only these classes are auto-fix-attempted in v1. Each has a deterministic playbook. Everything else → human.

| CWE | Class | Fix pattern (playbook) | LLM role |
|---|---|---|---|
| CWE-89 | SQL Injection | Replace string-built queries with parameterized queries/prepared statements | Rewrite the query call preserving semantics |
| CWE-79 | XSS (reflected/stored) | Apply context-correct output encoding / use framework escaping | Insert encoding at sink |
| CWE-798 | Hardcoded credentials | **Deterministic (no LLM):** replace literal with vault/env reference + add to secret manager TODO | none (redaction path) |
| CWE-327 | Weak crypto/hashing | Swap weak algo (MD5/SHA1 for security) for approved (bcrypt/argon2/SHA-256 as appropriate) | Adjust call + params |
| CWE-22 | Path traversal | Add canonicalization + allowlist base-dir check | Insert guard |
| CWE-611 | XXE | Disable external entity resolution on the parser | Set safe parser flags |
| CWE-1104 / SCA | Vulnerable dependency | Bump to nearest non-vulnerable version; read changelog for breaking changes | Assess breakage, adjust call sites if trivial |
| CWE-352 | Missing CSRF protection (framework-standard) | Enable framework CSRF middleware/token | Wire standard protection |

**Adding a class is a governed change:** new playbook + golden fix examples + eval cases + AppSec sign-off. The allowlist is the contract that keeps the agent inside "well-understood, deterministic-fix" territory.

---

# 6. Repository Structure

```
vuln-remediation-agent/
├── README.md
├── pyproject.toml
├── configs/
│   ├── settings.yaml
│   ├── repos.yaml                  # enabled repos/branches, per-repo caps
│   ├── allowlist.yaml              # vuln classes + playbook refs
│   └── kill_switch.yaml            # global + per-repo flags
├── playbooks/                      # one per CWE — prompt + examples + rubric hooks
│   ├── cwe_89_sqli.md
│   ├── cwe_79_xss.md
│   ├── cwe_327_crypto.md
│   └── ...
├── src/vuln_agent/
│   ├── settings.py
│   ├── schemas.py                  # Finding, Localization, FixResult, ReviewResult, etc.
│   ├── orchestrator.py             # the agent runtime / pipeline driver
│   ├── ingest/
│   │   ├── sarif.py                # normalize all scanners → SARIF
│   │   └── scanners/               # semgrep.py, codeql.py, snyk.py, trivy.py adapters
│   ├── triage/
│   │   ├── dedup.py                # fingerprinting, open-PR + suppression checks
│   │   └── classifier.py           # allowlist + fixability
│   ├── localize/
│   │   ├── ast_locator.py          # tree-sitter sink matching per CWE
│   │   └── semantic.py             # embedding confirmation
│   ├── fix/
│   │   ├── generator.py            # playbook-constrained LLM, repair loop
│   │   ├── secret_fixer.py         # DETERMINISTIC, no LLM
│   │   └── diff.py                 # safe unified-diff apply/validate
│   ├── sandbox/
│   │   ├── runner.py               # ephemeral container lifecycle
│   │   ├── toolchains/             # python.py, node.py: build/test/lint commands
│   │   └── rescan.py               # re-run scanner, diff findings
│   ├── review/
│   │   └── reviewer.py             # independent LLM critic + rubric
│   ├── pr/
│   │   ├── composer.py             # branch/commit/PR
│   │   └── git_provider.py         # GitHub/GitLab adapter (bot token, scoped)
│   ├── audit/
│   │   └── store.py                # Postgres append-only
│   └── safety/
│       ├── kill_switch.py
│       ├── redaction.py            # secret scan + redact before LLM
│       └── rate_limit.py
├── tests/
│   ├── test_no_merge_scope.py      # assert bot token lacks merge (integration, mocked)
│   ├── test_allowlist_gate.py      # unknown class never reaches fix generator
│   ├── test_redaction.py           # secrets never in LLM payload
│   ├── test_dedup_idempotent.py    # no duplicate PRs
│   ├── test_rescan_gate.py         # PR blocked if finding remains / new appears
│   ├── golden_findings/            # curated findings → expected outcome
│   └── vuln_fixtures/              # tiny repos with planted vulns per CWE
├── deploy/
│   ├── Dockerfile                  # orchestrator image
│   ├── sandbox.Dockerfile          # locked-down execution image
│   └── k8s/ (or ci-workflows/)
└── .github/workflows/
    ├── ci.yaml
    └── scheduled-remediation.yaml  # the cron entrypoint
```

---

# 7. Step-by-Step Implementation

## PHASE 0 — Safety Foundations FIRST (Week 1)

Build the guardrails before the agent. This ordering is deliberate: an agent that writes code is dangerous until the containment exists.

**Step 0.1 — Scoped bot identity + branch protection (do this in the Git provider before writing code):**
- Create a machine user / GitHub App with **contents:write** (push) and **pull_requests:write** only. **No merge, no admin, no workflow, no secrets scopes.**
- On every target branch: require ≥1 CODEOWNERS approval + all required status checks; disallow force-push; disallow the bot from approving its own PRs.
- Verify with a test:
```python
# tests/test_no_merge_scope.py
def test_bot_cannot_merge(git_provider_mock):
    scopes = git_provider.get_token_scopes()
    assert "merge" not in scopes and "admin" not in scopes
    # And branch protection asserts human approval required
    prot = git_provider.branch_protection("main")
    assert prot.required_approving_reviews >= 1
    assert prot.dismiss_stale_reviews and not prot.allow_bot_self_approve
```

**Step 0.2 — Kill switch + repo flags:**
```python
# src/vuln_agent/safety/kill_switch.py
from ..settings import load_yaml

def agent_enabled(repo: str, branch: str) -> bool:
    cfg = load_yaml("configs/kill_switch.yaml")
    if cfg.get("global_disabled"):        # one flag stops everything
        return False
    r = cfg.get("repos", {}).get(repo, {})
    return r.get("enabled", False) and branch in r.get("branches", [])
```

**Step 0.3 — Secret redaction (runs before ANY code reaches the LLM):**
```python
# src/vuln_agent/safety/redaction.py
import re
# Reuse org secret-scanner patterns; this is defense-in-depth on top of the
# secret-finding path. If a secret is detected in code we're about to send
# to the model, we REDACT it and, if the finding IS a secret, we divert to
# the deterministic secret_fixer (no LLM).
SECRET_PATTERNS = [
    re.compile(r"(?i)(api[_-]?key|secret|token|password)\s*[:=]\s*['\"][^'\"]{8,}['\"]"),
    re.compile(r"AKIA[0-9A-Z]{16}"),                 # AWS
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
]

def contains_secret(code: str) -> bool:
    return any(p.search(code) for p in SECRET_PATTERNS)

def redact(code: str) -> str:
    out = code
    for p in SECRET_PATTERNS:
        out = p.sub("<REDACTED_SECRET>", out)
    return out
```
```python
# tests/test_redaction.py
def test_no_secret_ever_sent_to_llm(fix_generator, finding_with_secret_context):
    payloads = fix_generator.capture_llm_payloads(finding_with_secret_context)
    for p in payloads:
        assert "<REDACTED_SECRET>" in p or not contains_secret(p)
```

**Step 0.4 — Sandbox image (locked down):**
```dockerfile
# deploy/sandbox.Dockerfile
FROM python:3.12-slim
# language toolchains as needed (node, jdk...) added per adapter image variant
RUN pip install --no-cache-dir pytest ruff bandit
RUN useradd -m sandbox
USER sandbox
WORKDIR /work
# Runtime is invoked with: --network none, read-only root fs except /work,
# --memory 2g --cpus 2 --pids-limit 256, NO secrets mounted, auto-removed.
```

**Milestone 0 ✅:** bot proven unable to merge; kill switch works; redaction tests green; sandbox launches with no network. **Do not proceed until these pass.**

## PHASE 1 — Ingest, Normalize, Dedup, Triage (Week 2)

**Step 1.1 — Normalize to SARIF:**
```python
# src/vuln_agent/schemas.py
from pydantic import BaseModel
from typing import Literal

class Region(BaseModel):
    file: str
    start_line: int
    end_line: int | None = None

class Finding(BaseModel):
    fingerprint: str                 # stable across scans (see dedup)
    scanner: str
    rule_id: str
    cwe: str | None
    severity: Literal["critical","high","medium","low"]
    message: str
    region: Region
    repo: str
    branch: str
    commit: str
```

**Step 1.2 — Stable fingerprint + dedup (idempotency backbone):**
```python
# src/vuln_agent/triage/dedup.py
import hashlib

def fingerprint(f) -> str:
    # Line numbers drift; fingerprint on (repo, rule, file, enclosing symbol, code hash)
    # NOT raw line number, so a shifted-but-same vuln dedups correctly.
    basis = f"{f.repo}|{f.rule_id}|{f.region.file}|{enclosing_symbol(f)}|{normalized_snippet_hash(f)}"
    return hashlib.sha256(basis.encode()).hexdigest()[:20]

def should_process(f, audit, git, suppressions) -> bool:
    fp = fingerprint(f)
    if suppressions.is_accepted_risk(fp): return False
    if audit.has_open_pr(fp):             return False   # never duplicate
    if audit.recently_fixed(fp, days=30): return False
    return True
```

**Step 1.3 — Triage classifier (the allowlist gate):**
```python
# src/vuln_agent/triage/classifier.py
def triage(finding, allowlist) -> str:
    if finding.cwe not in allowlist.cwes:
        return "human_triage"                 # unknown class → never auto-attempt
    if not toolchain_supported(finding.region.file):
        return "human_triage"                 # language w/o adapter → human
    return "auto_fixable"
```
```python
# tests/test_allowlist_gate.py
def test_unknown_cwe_never_reaches_generator(pipeline, finding_cwe_unlisted):
    result = pipeline.run_one(finding_cwe_unlisted)
    assert result.stage_reached == "triage"
    assert result.outcome == "human_triage"
    assert not pipeline.fix_generator.was_called
```

**Milestone 1 ✅:** findings from 2 scanners normalize + dedup; idempotency test (run twice → no dup) green; allowlist gate proven.

## PHASE 2 — Localization (Week 3)

Report line hints are unreliable; localize precisely so the fix is surgical.

```python
# src/vuln_agent/localize/ast_locator.py
from tree_sitter import Parser  # tree-sitter-languages for grammars

class ASTLocator:
    """For a given CWE, find the vulnerability SINK near the reported region.
    Example (CWE-89): find call nodes whose SQL string argument is built via
    concatenation/format/f-string with a variable. Returns precise span +
    minimal enclosing function context for the fixer."""
    def locate(self, finding, source: str) -> "Localization | None":
        tree = self.parsers[lang(finding.region.file)].parse(source.encode())
        candidates = self.sink_matchers[finding.cwe](tree, source, near=finding.region)
        if not candidates:
            return None
        best = self.rank_by_proximity(candidates, finding.region)
        return Localization(
            file=finding.region.file,
            span=best.span,                       # exact node span, not report line
            enclosing_function=best.enclosing_fn_span,
            context=extract_minimal_context(source, best),   # small window for LLM
            confidence=best.confidence)
```

Semantic confirmation (cheap tie-breaker / low-confidence backstop):
```python
# src/vuln_agent/localize/semantic.py
# Embed the finding message + CWE description; embed candidate code spans;
# pick the span with highest cosine similarity when AST yields multiple.
# If AST yields nothing AND semantic top-1 is weak → confidence LOW → human.
```

Localization output confidence drives routing: **HIGH → fix; LOW → human_triage with candidate spans attached** (never guess a fix on an unclear target).

**Milestone 2 ✅:** on `vuln_fixtures/` (planted vulns per CWE), localizer hits the exact sink span ≥ 95% with correct confidence calibration (low-confidence cases actually route to human).

## PHASE 3 — Fix Generation (Weeks 3–4)

**Step 3.1 — Playbook format (constrains the LLM tightly):**
```markdown
<!-- playbooks/cwe_89_sqli.md -->
# Playbook: CWE-89 SQL Injection

## Objective
Convert a string-constructed SQL query into a parameterized query. Change ONLY
what is necessary. Preserve behavior, column order, and return handling.

## Rules
- Use the library's native parameterization (psycopg: %s + params tuple; SQLAlchemy: text() with bindparams; etc.)
- Do NOT alter surrounding logic, error handling, or formatting beyond the query call.
- Do NOT introduce new dependencies.
- Preserve the exact SQL semantics; only the interpolation mechanism changes.

## Examples
### Vulnerable
`cur.execute("SELECT * FROM users WHERE id = '" + user_id + "'")`
### Fixed
`cur.execute("SELECT * FROM users WHERE id = %s", (user_id,))`

## Output format
Return ONLY a unified diff against the provided file. No prose.
```

**Step 3.2 — Generator with bounded repair loop:**
```python
# src/vuln_agent/fix/generator.py
from ..safety.redaction import contains_secret, redact

class FixGenerator:
    def __init__(self, llm, sandbox, playbooks, max_repairs=3):
        self.llm, self.sandbox, self.playbooks, self.max_repairs = llm, sandbox, playbooks, max_repairs

    def generate(self, finding, localization) -> "FixResult":
        # Secret-bearing code never goes to the LLM
        context = localization.context
        if finding.cwe == "CWE-798" or contains_secret(context):
            return None   # handled by deterministic secret_fixer, not here

        playbook = self.playbooks[finding.cwe]
        messages = self._build_prompt(playbook, redact(context), localization)

        diff = self.llm.complete(messages)          # logged: prompt hash + model version
        for attempt in range(self.max_repairs + 1):
            result = self.sandbox.validate(finding, diff)   # PHASE 4
            if result.all_passed:
                return FixResult(diff=diff, validation=result, attempts=attempt+1)
            if not result.is_recoverable:
                break                                # e.g., diff doesn't apply → give up
            # Feed structured failure back for a targeted revision
            messages = self._revision_prompt(playbook, context, diff, result)
            diff = self.llm.complete(messages)
        return FixResult(diff=None, validation=result, gave_up=True)   # → human_triage
```

**Step 3.3 — Deterministic secret fixer (no LLM):**
```python
# src/vuln_agent/fix/secret_fixer.py
def fix_hardcoded_secret(finding, source) -> str:
    """Replace the literal with an env/vault reference, add a migration TODO,
    and register the secret name in the secret-manager onboarding queue.
    Fully deterministic — no model, no secret egress."""
    # produce diff: `API_KEY = "abc123"`  →  `API_KEY = os.environ["API_KEY"]`
    # plus a PR checklist item: "Add API_KEY to <vault path> before merge"
    ...
```

**Milestone 3 ✅:** for each allowlisted CWE, generator produces a minimal, applying diff on fixtures; secret path proven LLM-free; repair loop bounded (no infinite loops — asserted in tests).

## PHASE 4 — Sandbox Validation (Week 4)

The objective success gate. No PR without a green sandbox including re-scan.

```python
# src/vuln_agent/sandbox/runner.py
import docker, tempfile, shutil

class Sandbox:
    def validate(self, finding, diff) -> "ValidationResult":
        workdir = self._checkout_and_apply(finding, diff)   # shallow clone + git apply
        if workdir is None:
            return ValidationResult(applied=False, is_recoverable=False)

        toolchain = self.toolchains[lang(finding.region.file)]
        container = self.client.containers.run(
            image=toolchain.image, command="sleep infinity", detach=True,
            network_mode="none", mem_limit="2g", nano_cpus=2_000_000_000,
            pids_limit=256, read_only=True,
            volumes={workdir: {"bind": "/work", "mode": "rw"}},
            remove=True, user="sandbox")
        try:
            build = self._exec(container, toolchain.build_cmd)
            tests = self._exec(container, toolchain.test_cmd)
            gen_test = self._run_generated_regression_test(container, finding, toolchain)
            lint = self._exec(container, toolchain.lint_cmd)
            rescan = self.rescan.run(container, finding)      # PHASE 4.1
            return ValidationResult(
                applied=True, build_ok=build.ok, tests_ok=tests.ok,
                regression_ok=gen_test.ok, lint_ok=lint.ok,
                finding_resolved=rescan.finding_gone,
                no_new_findings=rescan.no_new,
                all_passed=all([build.ok, tests.ok, gen_test.ok, lint.ok,
                                rescan.finding_gone, rescan.no_new]),
                is_recoverable=(build.ok and not tests.ok),   # test fail → revisable
                logs=collect_logs(build, tests, gen_test, lint, rescan))
        finally:
            container.stop(timeout=5)
            shutil.rmtree(workdir, ignore_errors=True)
```

**Step 4.1 — Re-scan gate (proves the fix worked):**
```python
# src/vuln_agent/sandbox/rescan.py
class Rescan:
    def run(self, container, finding) -> "RescanResult":
        before = self.baseline_findings           # from the triggering scan
        after = self.run_scanner_in(container, scope=finding.region.file)
        gone = finding.fingerprint not in {f.fingerprint for f in after}
        new = [f for f in after if f.fingerprint not in {b.fingerprint for b in before}]
        return RescanResult(finding_gone=gone, no_new=(len(new) == 0), new_findings=new)
```
```python
# tests/test_rescan_gate.py
def test_pr_blocked_if_finding_remains(pipeline, fix_that_doesnt_resolve):
    out = pipeline.run_one(fix_that_doesnt_resolve)
    assert out.pr_opened is False and out.outcome == "human_triage"

def test_pr_blocked_if_new_finding_introduced(pipeline, fix_that_adds_vuln):
    out = pipeline.run_one(fix_that_adds_vuln)
    assert out.pr_opened is False
```

**Milestone 4 ✅:** sandbox runs fully offline; re-scan gate proven to block both "finding remains" and "new finding introduced"; resource limits enforced.

## PHASE 5 — Independent Security Review (Week 5)

```python
# src/vuln_agent/review/reviewer.py
RUBRIC = """You are an independent security reviewer. You did NOT write this fix.
Evaluate the diff for a {cwe} finding. Check:
1. Does it actually remediate the {cwe} vulnerability? (not just move it)
2. Does it change behavior beyond the security fix? (should not)
3. Any new vulnerability introduced?
4. Is it minimal and correct?
Respond JSON: {{"verdict": "PASS|REVISE|REJECT", "confidence": 0-1, "reasons": [...]}}"""

class SecurityReviewer:
    def review(self, finding, fix_result) -> "ReviewResult":
        resp = self.llm.complete_json(
            RUBRIC.format(cwe=finding.cwe),
            payload={"diff": fix_result.diff,
                     "validation": fix_result.validation.summary()})
        # Gate: PASS AND confidence >= 0.8 AND sandbox all_passed → allow PR
        allow = (resp["verdict"] == "PASS" and resp["confidence"] >= 0.8
                 and fix_result.validation.all_passed)
        return ReviewResult(allow_pr=allow, **resp)
```
Different model role than the generator (agentic-course Module 7 reflection): evaluators biased toward their own work, so the critic must be independent. A REJECT/REVISE or low confidence → no PR, comment for humans.

**Milestone 5 ✅:** reviewer catches deliberately-bad diffs in the golden set (planted subtle-wrong fixes); PASS-rate on known-good fixes ≥ 95%.

## PHASE 6 — PR Composition (Week 5–6)

```python
# src/vuln_agent/pr/composer.py
class PRComposer:
    def compose(self, finding, fix_result, review) -> str:
        branch = f"security/{finding.cwe.lower()}-{finding.fingerprint[:8]}"
        self.git.create_branch(finding.repo, base=finding.branch, name=branch)
        self.git.commit_diff(finding.repo, branch, fix_result.diff,
                             message=f"fix({finding.cwe}): remediate {finding.rule_id} in {finding.region.file}")
        pr = self.git.open_pr(
            repo=finding.repo, head=branch, base=finding.branch,   # target branch, human merges
            title=f"[Security] Fix {finding.cwe} in {finding.region.file}",
            body=self._render_body(finding, fix_result, review),
            labels=["security", "auto-generated", finding.severity],
            reviewers_from_codeowners=True)
        return pr.url

    def _render_body(self, finding, fix, review) -> str:
        return f"""## 🔒 Automated Security Fix — human review required

**Finding:** {finding.rule_id} ({finding.cwe}, {finding.severity})
**File:** `{finding.region.file}`
**Scanner:** {finding.scanner}

### What changed
{fix.diff_summary}

### Validation evidence (ran in isolated sandbox)
- ✅ Build/compile passed
- ✅ Existing tests passed
- ✅ Generated regression test passed
- ✅ Lint passed
- ✅ **Re-scan: finding no longer present**
- ✅ **Re-scan: no new findings introduced**

### Independent security review
Verdict: **{review.verdict}** (confidence {review.confidence:.0%})
{chr(10).join('- ' + r for r in review.reasons)}

---
⚠️ This PR was generated automatically. **A human must review and merge.**
Full audit trail: {self.audit_link(finding)}
"""
```

**Milestone 6 ✅:** end-to-end on a fixture repo: finding → PR appears on target branch, correctly attributed, CODEOWNERS requested, bot cannot merge (verified), evidence complete.

## PHASE 7 — Scheduling, Rate Limits, Rollout (Weeks 6–7)

**Step 7.1 — Scheduled entrypoint:**
```yaml
# .github/workflows/scheduled-remediation.yaml
name: vuln-remediation
on:
  schedule: [{cron: "0 3 * * 1-5"}]     # weekday nights
  workflow_dispatch:
    inputs:
      repo: {required: true}
      branch: {default: main}
jobs:
  remediate:
    runs-on: [self-hosted, secure]       # sandbox needs docker; run on trusted runner
    steps:
      - uses: actions/checkout@v4
      - run: pip install .
      - name: Run agent
        env:
          BOT_TOKEN: ${{ secrets.VULN_AGENT_BOT_TOKEN }}   # push+PR scope only
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
        run: python -m vuln_agent.orchestrator run --config configs/repos.yaml
```

**Step 7.2 — Rate limiting / backpressure** (respect human review capacity):
```python
# src/vuln_agent/safety/rate_limit.py
def can_open_more(repo, git, cap) -> bool:
    return git.count_open_agent_prs(repo) < cap    # default cap 5
# If humans aren't reviewing, the agent stops producing — no PR spam.
```

**Step 7.3 — Rollout ladder:**
| Stage | What | Exit criteria |
|---|---|---|
| Shadow | Run full pipeline, but PR Composer only *logs* what it would open (no real PR) | Would-be-PR quality reviewed by AppSec ≥ 90% acceptable across 2 weeks |
| Single repo, 1 CWE | Enable real PRs for one repo, SQLi only | ≥ 80% PR approval, 0 regressions merged |
| Expand CWEs | Add classes one at a time, each with golden evals | Per-class approval ≥ 80% |
| Multi-repo | Enable more repos via `repos.yaml` | Sustained approval rate; review capacity respected |

**Milestone 7 ✅:** shadow → single-repo-single-CWE live; approval rate tracked; kill switch drill performed.

---

# 8. Testing Strategy

| Layer | Tests (release-blocking ones in **bold**) |
|---|---|
| **Safety** | **bot-cannot-merge**; **branch protection present**; **kill switch halts runs**; **secrets never in LLM payload**; sandbox has no network |
| **Gates** | **allowlist gate** (unknown CWE → human); **rescan gate** (finding-remains and new-finding both block PR); **dedup idempotency** (run twice → no dup PR) |
| Localization | sink-span accuracy on `vuln_fixtures/` per CWE; low-confidence → human |
| Fix quality | golden findings → expected diff shape; repair loop bounded |
| Review | catches planted-bad diffs; passes known-good |
| Integration | end-to-end on fixture repos per CWE → PR with full evidence |
| Chaos | git provider down → backoff, no dup; sandbox OOM → clean failure → human_triage |

Golden set grows with every production miss (agentic-course Module 17 flywheel): a merged-then-reverted fix becomes a permanent eval case.

---

# 9. Monitoring & Operations

**Metrics (per repo + global):**
- Findings ingested / auto-fixable / human-triaged
- PRs opened, approval rate, time-to-merge, revert rate (**the north-star safety metric**)
- Per-CWE approval rate (drop = playbook problem)
- Sandbox pass rate, re-scan block rate, reviewer reject rate
- LLM cost per fix; repair-loop iterations distribution
- Duplicate-PR incidents (should be 0)

**Alerts:**
| Alert | Threshold | Action |
|---|---|---|
| Revert rate | > 2% | Auto-pause affected CWE (flag), AppSec review |
| Approval rate (any CWE, 2wk) | < 70% | Pause that CWE; revisit playbook |
| New-finding-introduced caught | any | Fine (gate worked) — but trend up ⇒ generator regression |
| Duplicate PR opened | ≥ 1 | Bug in dedup — page; idempotency is sacred |
| Sandbox network egress attempt | any | Security incident — investigate immediately |

**Runbook:**
1. *"A bad fix got merged"* → it passed human review, so: (a) revert via normal git, (b) add the case to golden evals, (c) pause the CWE if systemic, (d) blameless post-mortem — the human gate is the last line, and this tells you whether evidence rendering misled the reviewer.
2. *"Agent opened a wrong PR"* → close it; check reviewer verdict + sandbox logs in audit store; if the rescan passed but the fix is semantically wrong, strengthen the generated-regression-test step for that CWE.
3. *"Stop everything now"* → set `global_disabled: true` in kill_switch.yaml (takes effect next run start; in-flight runs finish their current finding then halt). For instant halt, disable the scheduled workflow + revoke bot token.
4. *"PRs piling up unreviewed"* → rate limiter already throttles; nudge reviewers; consider lowering per-repo cap.

---

# 10. Security & Governance Summary (the whole point)

- **Merge is human, always** — enforced by token scope + branch protection (ADR-1), tested (test_no_merge_scope).
- **Bounded scope** — allowlisted CWEs with deterministic playbooks only (ADR-2); unknown → human.
- **Contained execution** — ephemeral, networkless, secretless, resource-capped sandbox (ADR-8).
- **No secret egress** — redaction before LLM; secret findings fixed deterministically (ADR-6).
- **Objective success gate** — sandbox build+test+lint+**rescan** before any PR (ADR-4).
- **Independent review** — separate critic model (ADR-5) + mandatory human CODEOWNERS review.
- **Full auditability** — every finding's journey (localization, diff, validation, review, PR) immutable in the audit store; every LLM call logged with prompt hash + model version (NFR-5).
- **Kill switch + rate limits + dedup** — global stop, capacity backpressure, zero duplicate PRs (NFR-4, NFR-6).
- **Governed expansion** — adding a CWE or repo requires evals + AppSec sign-off.

---

# 11. Project Plan Summary

| Week | Deliverable |
|---|---|
| 1 | **Safety foundations**: scoped bot, branch protection, kill switch, redaction, locked sandbox (Milestone 0) |
| 2 | Ingest + SARIF normalize + dedup/idempotency + allowlist triage (Milestone 1) |
| 3 | AST + semantic localization (Milestone 2) |
| 3–4 | Playbook-constrained fix generator + deterministic secret path + bounded repair (Milestone 3) |
| 4 | Sandbox validation + rescan gate (Milestone 4) |
| 5 | Independent security reviewer (Milestone 5) |
| 5–6 | PR composer with evidence (Milestone 6) |
| 6–7 | Scheduling, rate limits, shadow → single-repo-single-CWE rollout (Milestone 7) |

**Definition of Done (v1):** one repo live for one CWE (SQLi), shadow-validated; PRs open with full evidence; **bot provably cannot merge**; sandbox contained and networkless; kill switch drilled; revert rate < 2%; audit trail complete; adding the next CWE gated on evals + sign-off.

---

# Appendix — How This Maps to the Agentic AI Course

| Course Module | Used here |
|---|---|
| M2 Prompt engineering | Playbooks, structured JSON review output |
| M4 Tool calling | Localizer, sandbox, git as agent tools |
| M5 Agent loop + stop conditions | Bounded repair loop, per-stage stop conditions |
| M7 Reflection | Independent security reviewer |
| M10 Human-in-the-loop | The entire "propose, never merge" architecture |
| M16.2 Long-horizon/idempotent | Scheduled runs, idempotent dedup, durable audit state |
| M17 Evaluation | Golden findings, per-CWE eval gates, growth flywheel |
| M18 Safety & security | Least privilege, sandboxing, injection/secret defense, kill switch — the spine of this build |
| M19 Observability/deploy | Metrics, alerts, runbook, scheduled CI deployment |
