# SynGen — Synthetic Data Generation Platform
## Complete PoC → Enterprise Implementation Package

> Generate **statistically faithful, privacy-safe synthetic data** using real AI (CTGAN).
> Raw data never leaves source systems — only statistical manifests travel.

---

## 30-Second Start

```bash
# 1. Install everything (once)
chmod +x scripts/install_all.sh && ./scripts/install_all.sh

# 2. Start backend (Terminal 1)
./scripts/start_backend.sh

# 3. Start frontend (Terminal 2)
./scripts/start_frontend.sh

# 4. Open browser
open http://localhost:3000
```

**Windows users:** Double-click `scripts/start_backend.bat` and `scripts/start_frontend.bat`

---

## What's Inside This Package

```
syngen-complete/
├── backend/               ← FastAPI + CTGAN + Real Validation
│   ├── main.py            ← API routes and orchestration
│   ├── profiler.py        ← Statistical profiler (4 demo datasets)
│   ├── generator.py       ← CTGAN AI engine (SDV)
│   ├── validator.py       ← KS test + TSTR + MIA privacy audit
│   ├── training_builder.py← Training DataFrame from manifest
│   └── requirements.txt   ← All Python deps (sdv, scipy, sklearn...)
│
├── frontend/              ← React + Vite dashboard
│   └── src/App.jsx        ← Complete UI (800 lines, single file)
│
├── docs/
│   ├── IMPLEMENTATION_GUIDE.txt  ← PyCharm + VS Code setup (detailed)
│   ├── API_REFERENCE.md          ← Every endpoint documented
│   ├── ENTERPRISE_GUIDE.md       ← How to scale to production
│   └── TROUBLESHOOTING.md        ← Fixes for common errors
│
├── architecture/
│   └── ALL_ARCHITECTURE_DIAGRAMS.txt  ← L0/L1/L2/AI/ML/Deployment
│
├── configs/
│   ├── api_tests.http       ← VS Code REST Client test suite
│   ├── pycharm_run_config.txt
│   └── .vscode/             ← VS Code launch + settings + extensions
│
└── scripts/
    ├── install_all.sh       ← One-command install (Mac/Linux)
    ├── start_backend.sh/.bat
    └── start_frontend.sh/.bat
```

---

## Architecture in One Picture

```
Source System         Platform                    Consumer
(Real PII Data)                                   (Dev/QA/ML)

┌──────────┐  stats   ┌──────────────────────┐
│  Real DB │ ────────►│  1. Profile          │
│ 10M rows │  only    │     PII detection    │
│ LOCKED   │  no raw  │     Statistical scan │
└──────────┘  data    └──────────┬───────────┘
                                 │ manifest.json
                      ┌──────────▼───────────┐
                      │  2. AI Generation    │
                      │     CTGAN / GAN      │
                      │     100 epochs       │
                      └──────────┬───────────┘
                                 │ synthetic rows
                      ┌──────────▼───────────┐
                      │  3. Validation Gate  │
                      │     KS Test          │
                      │     TSTR (ML)        │
                      │     Privacy Audit    │
                      └──────────┬───────────┘
                                 │ if PASS         ┌──────────┐
                                 └────────────────►│ Dataset  │
                                                   │ Consumer │
                                                   └──────────┘
```

---

## AI/ML Engines Used

| Step | Real Engine | Library |
|------|-------------|---------|
| Generation | CTGAN (Conditional Tabular GAN) | `sdv` |
| Generation fallback | GaussianCopula | `sdv` |
| Fidelity test | Kolmogorov-Smirnov test | `scipy` |
| ML utility | TSTR — RandomForest | `sklearn` |
| Privacy audit | Membership Inference Attack | `sklearn` |
| Privacy metrics | k-Anonymity, l-Diversity | `pandas` |
| PII replacement | Realistic fake data | `faker` |

All engines have **fallbacks** — the platform runs even without ML libraries,
just with simulated scores instead of real ones. Install libs to go live.

---

## Demo Datasets Built-In

| Dataset | Domain | Source Rows | PII Risk |
|---------|--------|-------------|----------|
| Customer Database | Retail | 250,000 | HIGH |
| Transaction History | Finance | 1,200,000 | LOW |
| HR Employee Data | HR | 8,500 | HIGH |
| Patient Records | Healthcare | 50,000 | MEDIUM/HIPAA |

---

## Enterprise Path

Each module is a drop-in swap target:

| PoC | Enterprise |
|-----|-----------|
| In-memory jobs | Celery + Redis |
| Training from manifest | Real DB sample |
| In-memory catalog | Apache Atlas / Collibra |
| Local audit log | S3 + Athena / Splunk |
| Single process | Kubernetes |
| No auth | OAuth2 + OPA |

See `docs/ENTERPRISE_GUIDE.md` for implementation code snippets.

---

## Prerequisites

- Python 3.10+  →  https://python.org
- Node.js 18+   →  https://nodejs.org
- PyCharm       →  https://jetbrains.com/pycharm (Community = free)
- VS Code       →  https://code.visualstudio.com

Full setup steps: `docs/IMPLEMENTATION_GUIDE.txt`
