# SynGen — Troubleshooting Guide
# ═══════════════════════════════════════════════════════════════════════════════

## Quick Diagnostic Checklist

Run these first before diving into specific errors:

  1. Is backend running?     curl http://localhost:8000/health
  2. Is frontend running?    Open http://localhost:3000
  3. Correct Python venv?    which python (should show .../venv/bin/python)
  4. All deps installed?     pip list | grep sdv
  5. Port conflicts?         lsof -i :8000 && lsof -i :3000

---

## Backend Issues

### "ModuleNotFoundError: No module named 'sdv'"
Cause: SDV not installed or wrong Python interpreter.

Fix:
  # Make sure venv is activated, then:
  pip install sdv

  # Verify:
  python -c "import sdv; print(sdv.__version__)"

  # In PyCharm, verify the interpreter:
  Settings → Project → Python Interpreter
  Should show: .../venv/bin/python (NOT system Python)


### "ModuleNotFoundError: No module named 'training_builder'"
Cause: Working directory is wrong — uvicorn is running from the wrong folder.

Fix:
  In PyCharm Run Config, verify:
  Working directory = /path/to/syngen-complete/backend  (NOT parent folder)

  In terminal:
  cd syngen-complete/backend   # Must be in backend/ folder
  uvicorn main:app --reload


### "OSError: [Errno 98] Address already in use: 8000"
Cause: Something else is using port 8000 (previous run not stopped).

Fix (macOS/Linux):
  lsof -ti:8000 | xargs kill -9

Fix (Windows):
  netstat -ano | findstr :8000
  taskkill /PID [the PID shown] /F

Alternative: Change port in PyCharm config:
  Parameters: main:app --reload --port 8001
  Then update API URL in frontend/src/App.jsx line 5:
  const API = "http://localhost:8001";


### Backend starts but crashes with PyTorch/CTGAN errors
Cause: Incompatible PyTorch version with SDV.

Fix:
  pip uninstall torch torchvision -y
  pip install sdv  # SDV will pull compatible PyTorch version

  If on Apple Silicon (M1/M2 Mac):
  pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
  pip install sdv


### "WARNING: SDV not installed. Falling back to statistical generator"
This is NOT an error — it means the platform is running in fallback mode.
Synthetic data will still be generated, just without CTGAN.

To activate CTGAN:
  pip install sdv scipy scikit-learn faker


### Generation job hangs at "Training CTGAN" for >5 minutes
Cause: CTGAN training on CPU is slow for first run.

Expected times (CPU, 100 epochs):
  customers (12 cols, 5000 rows):    30-90 seconds
  transactions (9 cols, 5000 rows):  20-60 seconds
  employees (8 cols, 5000 rows):     20-50 seconds

Speed fixes:
  Option 1 — Reduce training rows (in generator.py):
    n_train = min(1000, max(200, num_rows * 2))  # was 5000

  Option 2 — Reduce epochs (in generator.py):
    epochs=50  # was 100 (lower quality but much faster)

  Option 3 — Force GaussianCopula (fast, slightly lower fidelity):
    In _train_model(): change  use_ctgan = False


### "pydantic_core._pydantic_core.ValidationError"
Cause: Request body missing required fields or wrong types.

Fix: Check the API Reference doc.
  Common mistake: num_rows sent as string "1000" instead of integer 1000.


### CORS error in browser console
Cause: Frontend can't reach backend.

Verify backend CORS in main.py:
  app.add_middleware(CORSMiddleware, allow_origins=["*"], ...)

This should already allow all origins. If still failing:
  1. Check backend is actually running
  2. Check you're accessing frontend on http (not https)
  3. Try: curl -H "Origin: http://localhost:3000" http://localhost:8000/health

---

## Frontend Issues

### "npm: command not found"
Fix: Node.js is not installed or not in PATH.
  Download: https://nodejs.org (LTS version)
  After install, close and reopen terminal.


### "Cannot find module 'react'"
Cause: node_modules not installed.

Fix:
  cd syngen-complete/frontend
  npm install


### Blank white page in browser
Cause: JavaScript error in App.jsx.

Fix:
  1. Open browser DevTools (F12) → Console
  2. Look for red error messages
  3. Common cause: syntax error in JSX
  4. Check VS Code terminal for Vite errors


### "Failed to fetch" errors in browser console
Cause: Backend is not running or not reachable.

Fix:
  1. Start backend (Section 2 of Implementation Guide)
  2. Verify: curl http://localhost:8000/health
  3. Check the API URL in App.jsx line 5:
     const API = "http://localhost:8000";
     (must match your backend port)


### Frontend shows "Backend Offline" (red dot)
This is the /health endpoint failing.

Debug:
  1. Open: http://localhost:8000/health in browser directly
  2. If "connection refused": backend is not running
  3. If page loads: CORS issue — check browser console


### Hot reload not working in VS Code
Fix:
  1. Make sure you're running: npm run dev
  2. Check Vite output in VS Code terminal for errors
  3. If needed, stop and restart: Ctrl+C then npm run dev

---

## PyCharm-Specific Issues

### PyCharm can't find Python interpreter
Fix:
  File → Settings → Project: backend → Python Interpreter
  Click ⚙ → Show All → + → Add
  Select "Virtualenv Environment" → Existing → browse to:
  syngen-complete/backend/venv/bin/python


### "Run" button is greyed out
Cause: No run configuration set up.

Fix:
  Run → Edit Configurations → + → Python
  Follow steps in Section 2.4 of Implementation Guide


### PyCharm shows import errors on sdv, scipy etc.
Cause: PyCharm is using wrong interpreter (system Python, not venv).

Fix:
  1. Check bottom-right corner of PyCharm — should show Python venv
  2. If not, click it and select the venv interpreter
  3. File → Invalidate Caches → Invalidate and Restart


### Hot reload not working in PyCharm
The --reload flag should handle this automatically.
If not:
  Check that "Working directory" in Run Config is correct.
  The uvicorn --reload flag only watches .py files in the working directory.

---

## Data / ML Issues

### Validation score seems low (<0.75)
Possible causes:
  1. Too few training rows (increase n_train in generator.py)
  2. Too few CTGAN epochs (increase epochs)
  3. Dataset has unusual distribution not captured in manifest

Quick fix: Regenerate with same manifest (second run often better — same cached model)


### "k_anonymity = 1" — Privacy audit warning
Cause: With few rows and many quasi-identifiers, groups become unique.
This is EXPECTED with small synthetic datasets.

Fix for production:
  - Generate more rows (10,000+)
  - Or reduce quasi-identifier columns tracked
  - k-anonymity of 5+ is good, 10+ is excellent


### Correlation mismatch (delta > 0.15)
Cause: CTGAN with 100 epochs may not perfectly capture all correlations.
This improves with:
  1. More training data (increase n_train)
  2. More epochs (increase from 100 to 200+)
  3. Both columns being numeric (categoricals harder to correlate)

---

## Windows-Specific Issues

### "venv\Scripts\activate : cannot be loaded"
Cause: PowerShell execution policy.

Fix:
  Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

Or use Command Prompt (cmd.exe) instead of PowerShell:
  venv\Scripts\activate.bat


### Long paths fail on Windows
Cause: Windows 260-character path limit.

Fix:
  Enable long paths in Windows:
  Settings → Update & Security → For developers → Enable long paths
  OR move project to C:\syngen\ (shorter path)


### "python" not recognized on Windows
Fix: During Python installation, check "Add Python to PATH"
Or use: py -m pip install ... (Windows Python launcher)

---

## Getting More Help

1. Check FastAPI docs: https://fastapi.tiangolo.com
2. Check SDV docs: https://docs.sdv.dev
3. Check Vite docs: https://vitejs.dev
4. API interactive docs: http://localhost:8000/docs
5. Backend logs: visible in PyCharm console
6. Frontend logs: browser DevTools Console (F12)
