# SynGen API Reference
# Base URL: http://localhost:8000
# Format: All requests/responses are JSON
# ═══════════════════════════════════════════════════════════════════════════════

## GET /health
Returns platform health status.

Response:
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## GET /api/sources
Lists available data source schemas for profiling.

Response:
```json
{
  "sources": [
    {
      "id": "demo_customers",
      "name": "Customer Database",
      "type": "built-in",
      "tables": ["customers"],
      "description": "Retail customer records with PII"
    },
    {
      "id": "demo_transactions",
      "name": "Transaction History",
      "type": "built-in",
      "tables": ["transactions"],
      "description": "Financial transaction records"
    },
    {
      "id": "demo_employees",
      "name": "HR Employee Data",
      "type": "built-in",
      "tables": ["employees"],
      "description": "HR records with sensitive employee data"
    },
    {
      "id": "demo_medical",
      "name": "Patient Records",
      "type": "built-in",
      "tables": ["patients"],
      "description": "Medical patient data (HIPAA sensitive)"
    }
  ]
}
```

---

## POST /api/profile
Starts a profiling job to extract statistical manifest from a source.
**No raw data is extracted — only statistics.**

Request Body:
```json
{
  "source_type": "built-in",
  "source_config": {
    "source_id": "demo_customers"
  },
  "dataset_name": "Customer Database Q1",
  "description": "Quarterly customer snapshot"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| source_type | string | Yes | "built-in", "postgres", "mysql", "csv" |
| source_config | object | Yes | Source-specific config (see below) |
| dataset_name | string | Yes | Human-readable name for this manifest |
| description | string | No | Optional description |

source_config for built-in:
```json
{ "source_id": "demo_customers | demo_transactions | demo_employees | demo_medical" }
```

source_config for PostgreSQL (enterprise):
```json
{
  "host": "db.company.com",
  "port": 5432,
  "database": "production",
  "table": "customers",
  "schema": "public"
}
```

Response:
```json
{
  "job_id": "550e8400-e29b-41d4-a716-446655440000",
  "manifest_id": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "status": "started"
}
```

Use `GET /api/jobs/{job_id}` to poll for completion.
When complete, the job result contains the full manifest.

---

## GET /api/jobs/{job_id}
Get the status and result of any background job.

Response (running):
```json
{
  "job_id": "550e8400-e29b-41d4-a716-446655440000",
  "status": "running",
  "progress": 40,
  "message": "Scanning schema and detecting PII...",
  "result": null,
  "created_at": "2024-01-15T10:30:00.000Z",
  "type": "profile"
}
```

Response (completed — profiling job):
```json
{
  "job_id": "...",
  "status": "completed",
  "progress": 100,
  "message": "Profiling complete",
  "result": {
    "manifest_id": "7c9e6679-...",
    "dataset_name": "Customer Database Q1",
    "table": "customers",
    "row_count": 250000,
    "data_domain": "retail",
    "columns": {
      "age": {
        "type": "integer",
        "min": 18, "max": 85,
        "mean": 38.4, "std_dev": 12.1,
        "distribution": "normal",
        "nulls_pct": 0.8,
        "pii": false
      },
      "email": {
        "type": "string",
        "role": "email",
        "pii": true,
        "pii_type": "EMAIL",
        "domain_distribution": { "gmail.com": 0.42, ... }
      }
    },
    "correlations": {
      "age_vs_annual_income": 0.43
    },
    "pii_summary": {
      "pii_columns": ["first_name", "last_name", "email", "city"],
      "risk_level": "HIGH"
    }
  }
}
```

Status values: "running" | "completed" | "failed"

---

## GET /api/jobs
List all jobs (profiling and generation).

Response:
```json
{
  "jobs": [ { ...job objects... } ]
}
```

---

## GET /api/manifests
List all created statistical manifests.

Response:
```json
{
  "manifests": [
    {
      "manifest_id": "7c9e6679-...",
      "dataset_name": "Customer Database Q1",
      "table": "customers",
      "row_count": 250000,
      "data_domain": "retail",
      "risk_level": "HIGH",
      "created_at": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

---

## GET /api/manifests/{manifest_id}
Get the full manifest including all column statistics.

Response: Full manifest object (same as job.result from profiling job)

---

## POST /api/generate
Start a synthetic data generation job.

Request Body:
```json
{
  "manifest_id": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "num_rows": 1000,
  "output_format": "json",
  "requestor": "alice@company.com",
  "purpose": "development"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| manifest_id | string | Yes | ID from a completed profiling job |
| num_rows | integer | Yes | Number of synthetic rows (10 - 100000) |
| output_format | string | No | "json" (default) or "csv" |
| requestor | string | No | Who is requesting (for audit log) |
| purpose | string | No | "development", "testing", "ml-training", etc. |

Response:
```json
{
  "job_id": "...",
  "status": "started"
}
```

Poll `GET /api/jobs/{job_id}` until status = "completed".

Response when completed:
```json
{
  "status": "completed",
  "result": {
    "dataset_id": "abc12345-...",
    "manifest_id": "7c9e6679-...",
    "num_rows": 1000,
    "total_rows": 1000,
    "generated_at": "2024-01-15T10:35:00.000Z",
    "validation": {
      "overall_score": 0.87,
      "overall_status": "PASS",
      "fidelity_score": 0.91,
      "tstr_score": 0.85,
      "column_scores": {
        "age": {
          "ks_test_score": 0.94,
          "test_used": "KS test",
          "distribution_match": "PASS",
          "null_rate_match": "PASS",
          "pii_detected": false,
          "detail": "KS stat=0.0612, p=0.4821"
        }
      },
      "correlation_checks": {
        "age_vs_annual_income": {
          "expected": 0.43,
          "synthetic": 0.41,
          "delta": 0.02,
          "status": "PASS"
        }
      },
      "privacy_audit": {
        "membership_inference_auc": 0.523,
        "membership_inference_status": "PASS",
        "k_anonymity": 24,
        "k_anonymity_status": "PASS",
        "l_diversity": 7,
        "l_diversity_status": "PASS",
        "pii_columns_removed": ["first_name", "last_name", "email", "city"],
        "overall_privacy_status": "PASS"
      },
      "business_rules": {
        "row_count_match": "PASS",
        "primary_key_unique": "PASS",
        "not_null_constraints": "PASS",
        "value_range_bounds": "PASS"
      },
      "engines_used": {
        "fidelity": "scipy KS test",
        "tstr": "sklearn RandomForest",
        "privacy": "sklearn MIA classifier"
      }
    },
    "data": [ ...first 50 rows for preview... ]
  }
}
```

---

## GET /api/datasets
List all generated datasets (metadata only, no actual data rows).

Response:
```json
{
  "datasets": [
    {
      "dataset_id": "abc12345-...",
      "manifest_id": "7c9e6679-...",
      "num_rows": 1000,
      "validation_score": 0.87,
      "requestor": "alice@company.com",
      "purpose": "development",
      "generated_at": "2024-01-15T10:35:00.000Z"
    }
  ]
}
```

---

## GET /api/stats
Platform statistics and AI/ML engine status.

Response:
```json
{
  "total_manifests": 3,
  "total_datasets": 7,
  "total_rows_generated": 15000,
  "total_audit_events": 28,
  "avg_validation_score": 0.88,
  "engines": {
    "generation": "CTGAN (SDV)",
    "validation": "scipy KS test",
    "tstr": "sklearn RandomForest",
    "privacy": "sklearn MIA classifier",
    "sdv_version": "1.9.0",
    "sdv_available": true,
    "scipy_available": true,
    "sklearn_available": true
  }
}
```

---

## GET /api/model-info/{manifest_id}
Check if a trained CTGAN model is cached for a manifest.

Response:
```json
{
  "cached": true,
  "model_type": "CTGANSynthesizer",
  "sdv_available": true
}
```

---

## DELETE /api/model-cache/{manifest_id}
Clear the cached model for a manifest (forces retraining on next generation).

Response:
```json
{
  "cleared": "7c9e6679-..."
}
```

---

## GET /api/audit
Get the full audit log (most recent first).

Response:
```json
{
  "logs": [
    {
      "event_id": "EVT-000006",
      "event_type": "GENERATION_COMPLETED",
      "timestamp": "2024-01-15T10:35:42.123Z",
      "metadata": {
        "job_id": "...",
        "dataset_id": "...",
        "rows_generated": 1000,
        "validation_score": 0.87
      }
    },
    {
      "event_id": "EVT-000005",
      "event_type": "GENERATION_REQUESTED",
      "timestamp": "2024-01-15T10:35:00.000Z",
      "metadata": {
        "job_id": "...",
        "manifest_id": "...",
        "num_rows": 1000,
        "requestor": "alice@company.com",
        "purpose": "development"
      }
    }
  ]
}
```

Event types:
  PROFILE_REQUESTED
  PROFILE_COMPLETED
  GENERATION_REQUESTED
  GENERATION_COMPLETED
  GENERATION_FAILED

---

## Error Responses

All errors return:
```json
{
  "detail": "Human-readable error message"
}
```

Status codes:
  200 — Success
  404 — Resource not found (manifest_id, job_id)
  422 — Validation error (invalid request body)
  500 — Internal server error
