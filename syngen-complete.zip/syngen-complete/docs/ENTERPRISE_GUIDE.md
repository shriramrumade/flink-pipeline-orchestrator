# SynGen — Enterprise Upgrade Guide
# How to transform this PoC into a production-grade platform
# ═══════════════════════════════════════════════════════════════════════════════

## Overview

Every component in the PoC is a deliberate drop-in replacement target.
The architecture is layered so each module can be upgraded independently.

```
PoC Component          → Enterprise Replacement
──────────────────────────────────────────────────────────────────────────
asyncio BackgroundTasks → Celery + Redis (distributed job queue)
In-memory job store     → PostgreSQL / Redis
In-memory catalog       → Apache Atlas / Collibra / DataHub
In-memory audit log     → Append-only S3 + Athena / Splunk / Elastic
CTGAN 100 epochs        → CTGAN 300+ epochs + GPU cluster
Statistical TrainingBuilder → Real DB sample (5,000-50,000 rows)
Single FastAPI process  → Kubernetes deployment (3+ replicas)
Local file system       → S3/GCS (model persistence)
No auth                 → OAuth2 + OPA (Open Policy Agent)
No monitoring           → Prometheus + Grafana
Manual deploy           → GitHub Actions CI/CD
```

---

## Phase 1 — Real Data Connectors

Replace TrainingDataBuilder.build() with real DB connectors:

### PostgreSQL
```python
# requirements: psycopg2-binary sqlalchemy

import psycopg2
import pandas as pd
from sqlalchemy import create_engine

def sample_from_postgres(connection_url: str, table: str, n: int = 5000) -> pd.DataFrame:
    engine = create_engine(connection_url)
    # TABLESAMPLE is fast — doesn't scan full table
    query = f"SELECT * FROM {table} TABLESAMPLE SYSTEM(1) LIMIT {n}"
    return pd.read_sql(query, engine)
```

### Snowflake
```python
# requirements: snowflake-sqlalchemy

from sqlalchemy import create_engine

def sample_from_snowflake(account, user, password, database, schema, table, n=5000):
    url = f"snowflake://{user}:{password}@{account}/{database}/{schema}"
    engine = create_engine(url)
    df = pd.read_sql(f"SELECT * FROM {table} SAMPLE ({n} ROWS)", engine)
    return df
```

### CSV / S3
```python
import pandas as pd

def sample_from_s3(s3_uri: str, n: int = 5000) -> pd.DataFrame:
    df = pd.read_csv(s3_uri, nrows=n)  # boto3 handles s3:// URIs
    return df
```

---

## Phase 2 — Distributed Job Queue (Celery + Redis)

### Install
```
pip install celery redis flower
docker run -d -p 6379:6379 redis:latest
```

### Replace BackgroundTasks with Celery
```python
# celery_app.py
from celery import Celery

celery = Celery(
    "syngen",
    broker="redis://localhost:6379/0",
    backend="redis://localhost:6379/1"
)

# tasks.py
@celery.task(bind=True)
def run_generation_task(self, manifest_id: str, num_rows: int, job_id: str):
    self.update_state(state="PROGRESS", meta={"progress": 20})
    # ... generation logic ...
    return {"dataset_id": "...", "rows": num_rows}

# In main.py, replace background_tasks.add_task with:
task = run_generation_task.delay(manifest_id, num_rows, job_id)
```

### Monitor with Flower
```bash
celery -A tasks flower --port=5555
# Open: http://localhost:5555
```

---

## Phase 3 — Model Persistence (S3)

```python
# requirements: boto3 joblib

import boto3
import joblib
import io

S3_BUCKET = "syngen-models"
s3 = boto3.client("s3")

def save_model_to_s3(model, manifest_id: str):
    buf = io.BytesIO()
    joblib.dump(model, buf)
    buf.seek(0)
    s3.put_object(Bucket=S3_BUCKET, Key=f"models/{manifest_id}.pkl", Body=buf.read())

def load_model_from_s3(manifest_id: str):
    try:
        obj = s3.get_object(Bucket=S3_BUCKET, Key=f"models/{manifest_id}.pkl")
        return joblib.load(io.BytesIO(obj["Body"].read()))
    except s3.exceptions.NoSuchKey:
        return None
```

---

## Phase 4 — Authentication (OAuth2 + JWT)

```python
# requirements: python-jose passlib[bcrypt]

from fastapi import Depends, HTTPException, Security
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError

SECRET_KEY = os.environ["JWT_SECRET"]
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

async def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Add to protected routes:
@app.post("/api/generate")
async def generate(request: GenerationRequest, user = Depends(get_current_user)):
    ...
```

---

## Phase 5 — Metadata Catalog (Apache Atlas REST API)

```python
# Apache Atlas has a REST API — no Python SDK needed

import requests

ATLAS_URL = "http://atlas.company.com:21000"
AUTH = ("admin", "password")

def register_manifest_in_atlas(manifest: dict):
    entity = {
        "entity": {
            "typeName": "syngen_manifest",
            "attributes": {
                "qualifiedName": f"syngen.{manifest['table']}@{manifest['manifest_id']}",
                "name": manifest["dataset_name"],
                "table": manifest["table"],
                "rowCount": manifest["row_count"],
                "piiRiskLevel": manifest["pii_summary"]["risk_level"],
                "createdAt": manifest["created_at"]
            }
        }
    }
    resp = requests.post(f"{ATLAS_URL}/api/atlas/v2/entity", json=entity, auth=AUTH)
    return resp.json()
```

---

## Phase 6 — Kubernetes Deployment

### Dockerfile (backend)
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .

EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "4"]
```

### Kubernetes Deployment
```yaml
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: syngen-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: syngen-api
  template:
    spec:
      containers:
      - name: syngen-api
        image: your-registry/syngen-backend:latest
        ports:
        - containerPort: 8000
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
        env:
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: syngen-secrets
              key: redis-url
```

### Helm chart structure
```
helm/syngen/
  Chart.yaml
  values.yaml
  templates/
    deployment.yaml
    service.yaml
    ingress.yaml
    hpa.yaml         # Horizontal Pod Autoscaler
    configmap.yaml
    secret.yaml
```

---

## Phase 7 — CI/CD (GitHub Actions)

```yaml
# .github/workflows/deploy.yml
name: Deploy SynGen

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - uses: actions/setup-python@v4
      with: { python-version: "3.11" }
    - run: pip install -r backend/requirements.txt pytest
    - run: pytest backend/tests/

  build-and-deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Build Docker image
      run: docker build -t syngen-backend:${{ github.sha }} backend/
    - name: Push to registry
      run: |
        docker tag syngen-backend:${{ github.sha }} registry/syngen-backend:latest
        docker push registry/syngen-backend:latest
    - name: Deploy to Kubernetes
      run: kubectl set image deployment/syngen-api syngen-api=registry/syngen-backend:${{ github.sha }}
```

---

## Phase 8 — Monitoring (Prometheus + Grafana)

```python
# requirements: prometheus-fastapi-instrumentator

from prometheus_fastapi_instrumentator import Instrumentator

Instrumentator().instrument(app).expose(app)

# Custom metrics
from prometheus_client import Counter, Histogram

rows_generated = Counter("syngen_rows_generated_total", "Total synthetic rows generated")
generation_duration = Histogram("syngen_generation_seconds", "Generation job duration")

# Use in code:
rows_generated.inc(num_rows)
with generation_duration.time():
    result = generator.generate(manifest, num_rows)
```

Grafana dashboard panels to create:
  - Total rows generated per day (Counter)
  - Generation latency p50/p95/p99 (Histogram)
  - Validation pass/fail rate (Gauge)
  - CTGAN training time per dataset (Histogram)
  - Active generation jobs (Gauge)
  - Privacy audit scores over time (Summary)

---

## Enterprise Cost Estimate

| Component | PoC Cost | Enterprise Monthly |
|-----------|----------|-------------------|
| API servers | $0 (local) | $200-500 (3 x t3.xlarge) |
| Celery workers (CPU) | $0 | $300-600 (auto-scaling) |
| GPU workers (CTGAN) | $0 | $500-2000 (p3.2xlarge spot) |
| Redis | $0 | $50-100 (ElastiCache) |
| PostgreSQL | $0 | $100-200 (RDS) |
| S3 (model storage) | $0 | $20-50 |
| Monitoring | $0 | $50-100 (Grafana Cloud) |
| **Total** | **$0** | **~$1,200-3,500/month** |

GPU acceleration (CTGAN training) reduces training time by 10-50x,
enabling higher epoch counts (300-500) for significantly better fidelity.
