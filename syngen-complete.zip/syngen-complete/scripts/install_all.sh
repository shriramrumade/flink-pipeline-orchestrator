#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  SynGen — Install All Dependencies
#  Run this ONCE before starting the platform for the first time
# ═══════════════════════════════════════════════════════════════════════════════

set -e

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
RESET='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════════╗${RESET}"
echo -e "${CYAN}${BOLD}║   SynGen — Installing All Dependencies              ║${RESET}"
echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════╝${RESET}"
echo ""

# ── Check Python ──────────────────────────────────────────────────────────────
echo -e "${YELLOW}Checking Python...${RESET}"
if ! command -v python3 &>/dev/null; then
    echo -e "${RED}✗ Python 3 not found. Install from https://python.org${RESET}"
    exit 1
fi
PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo -e "${GREEN}✓ Python $PYTHON_VERSION found${RESET}"

# ── Check Node ────────────────────────────────────────────────────────────────
echo -e "${YELLOW}Checking Node.js...${RESET}"
if ! command -v node &>/dev/null; then
    echo -e "${RED}✗ Node.js not found. Install from https://nodejs.org${RESET}"
    exit 1
fi
echo -e "${GREEN}✓ Node.js $(node --version) found${RESET}"
echo ""

# ── Backend Dependencies ──────────────────────────────────────────────────────
echo -e "${CYAN}${BOLD}Installing Backend Dependencies...${RESET}"
echo -e "${YELLOW}(This installs PyTorch + SDV — may take 5-15 minutes)${RESET}"
echo ""

BACKEND_DIR="$SCRIPT_DIR/../backend"
cd "$BACKEND_DIR"

python3 -m venv venv
source venv/bin/activate

pip install --upgrade pip -q
pip install -r requirements.txt

echo ""
echo -e "${GREEN}Verifying backend installations:${RESET}"
python3 -c "import fastapi; print(f'  ✓ FastAPI {fastapi.__version__}')"
python3 -c "import uvicorn; print(f'  ✓ uvicorn installed')"
python3 -c "import sdv; print(f'  ✓ SDV {sdv.__version__} (CTGAN)')" 2>/dev/null || echo -e "  ${YELLOW}⚠ SDV not installed (optional — platform will use fallback)${RESET}"
python3 -c "import scipy; print(f'  ✓ scipy {scipy.__version__} (KS test)')" 2>/dev/null || echo -e "  ${YELLOW}⚠ scipy not installed${RESET}"
python3 -c "import sklearn; print(f'  ✓ scikit-learn (TSTR + Privacy)')" 2>/dev/null || echo -e "  ${YELLOW}⚠ scikit-learn not installed${RESET}"
python3 -c "import pandas; print(f'  ✓ pandas {pandas.__version__}')"
python3 -c "import faker; print(f'  ✓ Faker installed')" 2>/dev/null || echo "  ✓ Faker (optional)"

# ── Frontend Dependencies ─────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}Installing Frontend Dependencies...${RESET}"

FRONTEND_DIR="$SCRIPT_DIR/../frontend"
cd "$FRONTEND_DIR"
npm install -q
echo -e "${GREEN}  ✓ React, Vite installed${RESET}"

# ── Make scripts executable ───────────────────────────────────────────────────
chmod +x "$SCRIPT_DIR/start_backend.sh"
chmod +x "$SCRIPT_DIR/start_frontend.sh"

echo ""
echo -e "${CYAN}${BOLD}══════════════════════════════════════════════════════${RESET}"
echo -e "${GREEN}${BOLD}  ✓ Installation Complete!${RESET}"
echo -e "${CYAN}${BOLD}══════════════════════════════════════════════════════${RESET}"
echo ""
echo "Next steps:"
echo ""
echo "  Option A — Use scripts:"
echo -e "    Terminal 1: ${CYAN}./scripts/start_backend.sh${RESET}"
echo -e "    Terminal 2: ${CYAN}./scripts/start_frontend.sh${RESET}"
echo ""
echo "  Option B — Use PyCharm + VS Code:"
echo -e "    See: ${CYAN}docs/IMPLEMENTATION_GUIDE.txt${RESET}"
echo ""
echo -e "  Then open: ${CYAN}http://localhost:3000${RESET}"
echo ""
