@echo off
REM ═══════════════════════════════════════════════════════════════════════════
REM  SynGen Frontend Startup Script — Windows
REM ═══════════════════════════════════════════════════════════════════════════

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║   SynGen — Frontend Startup (Windows)       ║
echo  ╚══════════════════════════════════════════════╝
echo.

SET SCRIPT_DIR=%~dp0
SET FRONTEND_DIR=%SCRIPT_DIR%..\frontend

cd /d "%FRONTEND_DIR%"

REM Check Node.js
node --version >nul 2>&1
IF ERRORLEVEL 1 (
    echo ERROR: Node.js not found. Install from https://nodejs.org
    pause
    exit /b 1
)

REM Install deps if needed
IF NOT EXIST "node_modules" (
    echo Installing Node.js dependencies...
    npm install
)

echo Starting SynGen frontend on http://localhost:3000
echo.
echo Make sure backend is also running (start_backend.bat)
echo Press Ctrl+C to stop
echo.

npm run dev

pause
