#!/bin/bash
# SynGen Frontend Startup — macOS / Linux

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FRONTEND_DIR="$SCRIPT_DIR/../frontend"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   SynGen — Frontend Startup                 ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

cd "$FRONTEND_DIR"

if ! command -v node &>/dev/null; then
    echo "ERROR: Node.js not found. Install from https://nodejs.org"
    exit 1
fi

if [ ! -d "node_modules" ]; then
    echo "Installing Node.js dependencies..."
    npm install
fi

echo "Starting frontend on http://localhost:3000"
echo "Make sure backend is also running (start_backend.sh)"
echo "Press Ctrl+C to stop"
echo ""

npm run dev
