@echo off
REM ═══════════════════════════════════════════════════════════════════════════
REM  SynGen Backend Startup Script — Windows
REM  Double-click this file OR run from Command Prompt
REM ═══════════════════════════════════════════════════════════════════════════

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║   SynGen — Backend Startup (Windows)        ║
echo  ╚══════════════════════════════════════════════╝
echo.

REM Get the directory where this script lives
SET SCRIPT_DIR=%~dp0
SET BACKEND_DIR=%SCRIPT_DIR%..\backend

cd /d "%BACKEND_DIR%"

REM Check if venv exists
IF NOT EXIST "venv\Scripts\activate.bat" (
    echo Creating virtual environment...
    python -m venv venv
    IF ERRORLEVEL 1 (
        echo ERROR: Python not found. Install from https://python.org
        pause
        exit /b 1
    )
)

echo Activating virtual environment...
call venv\Scripts\activate.bat

REM Install/update dependencies
echo Installing dependencies...
pip install -q -r requirements.txt

echo.
echo Starting SynGen backend on http://localhost:8000
echo API Docs: http://localhost:8000/docs
echo.
echo Press Ctrl+C to stop
echo.

uvicorn main:app --reload --host 0.0.0.0 --port 8000

pause
