"""
Data Profiler — Extracts statistical manifest from source data
In PoC: uses built-in demo datasets
In Enterprise: connects to real DBs, lakes, APIs
"""

import random
from typing import Dict, Any


# ─── Built-in Demo Datasets ────────────────────────────────────────────────────

DEMO_DATASETS = {
    "demo_customers": {
        "table": "customers",
        "row_count": 250000,
        "data_domain": "retail",
        "columns": {
            "customer_id": {
                "type": "integer", "role": "primary_key",
                "min": 1, "max": 250000, "nulls_pct": 0.0,
                "pii": False, "unique_pct": 100.0
            },
            "first_name": {
                "type": "string", "role": "name",
                "avg_length": 7, "max_length": 20,
                "pii": True, "pii_type": "PERSON_NAME",
                "sample_patterns": ["Alpha", "Beta", "Gamma"]
            },
            "last_name": {
                "type": "string", "role": "name",
                "avg_length": 8, "max_length": 25,
                "pii": True, "pii_type": "PERSON_NAME"
            },
            "email": {
                "type": "string", "role": "email",
                "pii": True, "pii_type": "EMAIL",
                "domain_distribution": {
                    "gmail.com": 0.42, "yahoo.com": 0.21,
                    "outlook.com": 0.18, "other": 0.19
                }
            },
            "age": {
                "type": "integer",
                "min": 18, "max": 85, "mean": 38.4,
                "std_dev": 12.1, "distribution": "normal",
                "nulls_pct": 0.8, "pii": False
            },
            "gender": {
                "type": "categorical",
                "categories": {"Male": 0.48, "Female": 0.49, "Non-binary": 0.02, "Prefer not to say": 0.01},
                "nulls_pct": 0.5, "pii": False
            },
            "city": {
                "type": "string", "role": "location",
                "pii": True, "pii_type": "LOCATION",
                "top_values": {"New York": 0.08, "Los Angeles": 0.06, "Chicago": 0.04, "Other": 0.82}
            },
            "country": {
                "type": "categorical",
                "categories": {"US": 0.65, "UK": 0.12, "CA": 0.08, "AU": 0.06, "Other": 0.09},
                "nulls_pct": 0.0, "pii": False
            },
            "signup_date": {
                "type": "date",
                "min": "2015-01-01", "max": "2024-12-31",
                "distribution": "uniform", "pii": False
            },
            "annual_income": {
                "type": "float",
                "min": 18000, "max": 450000, "mean": 67000,
                "std_dev": 42000, "distribution": "right_skewed",
                "nulls_pct": 12.0, "pii": False,
                "percentiles": {"p25": 38000, "p50": 58000, "p75": 88000, "p90": 125000}
            },
            "is_active": {
                "type": "boolean",
                "true_pct": 0.73, "nulls_pct": 0.0, "pii": False
            },
            "loyalty_tier": {
                "type": "categorical",
                "categories": {"Bronze": 0.45, "Silver": 0.30, "Gold": 0.18, "Platinum": 0.07},
                "nulls_pct": 0.0, "pii": False
            }
        },
        "correlations": {
            "age_vs_annual_income": 0.43,
            "annual_income_vs_loyalty_tier": 0.61,
            "age_vs_loyalty_tier": 0.38
        },
        "constraints": {
            "primary_key": "customer_id",
            "not_null": ["customer_id", "email", "country"],
            "unique": ["customer_id", "email"]
        },
        "pii_summary": {
            "pii_columns": ["first_name", "last_name", "email", "city"],
            "pii_column_count": 4,
            "risk_level": "HIGH"
        }
    },

    "demo_transactions": {
        "table": "transactions",
        "row_count": 1200000,
        "data_domain": "finance",
        "columns": {
            "transaction_id": {
                "type": "string", "role": "primary_key",
                "pattern": "TXN-XXXXXXXX", "unique_pct": 100.0, "pii": False
            },
            "customer_id": {
                "type": "integer", "role": "foreign_key",
                "references": "customers.customer_id", "pii": False
            },
            "amount": {
                "type": "float",
                "min": 0.50, "max": 9999.99, "mean": 87.40,
                "std_dev": 142.0, "distribution": "right_skewed",
                "percentiles": {"p25": 18.0, "p50": 45.0, "p75": 112.0},
                "nulls_pct": 0.0, "pii": False
            },
            "currency": {
                "type": "categorical",
                "categories": {"USD": 0.70, "EUR": 0.15, "GBP": 0.08, "CAD": 0.07},
                "pii": False
            },
            "transaction_date": {
                "type": "datetime",
                "min": "2020-01-01T00:00:00", "max": "2024-12-31T23:59:59",
                "distribution": "uniform", "pii": False
            },
            "category": {
                "type": "categorical",
                "categories": {
                    "Shopping": 0.28, "Food & Dining": 0.22, "Travel": 0.15,
                    "Entertainment": 0.12, "Health": 0.10, "Other": 0.13
                },
                "pii": False
            },
            "merchant_name": {
                "type": "string", "role": "business_name",
                "pii": False, "avg_length": 15
            },
            "is_fraud": {
                "type": "boolean",
                "true_pct": 0.0023, "nulls_pct": 0.0, "pii": False
            },
            "channel": {
                "type": "categorical",
                "categories": {"online": 0.58, "in-store": 0.35, "mobile": 0.07},
                "pii": False
            }
        },
        "correlations": {
            "amount_vs_category": 0.34,
            "is_fraud_vs_amount": 0.28,
            "channel_vs_amount": 0.19
        },
        "constraints": {
            "primary_key": "transaction_id",
            "foreign_keys": [{"column": "customer_id", "references": "customers.customer_id"}],
            "not_null": ["transaction_id", "customer_id", "amount", "transaction_date"]
        },
        "pii_summary": {
            "pii_columns": [],
            "pii_column_count": 0,
            "risk_level": "LOW"
        }
    },

    "demo_employees": {
        "table": "employees",
        "row_count": 8500,
        "data_domain": "hr",
        "columns": {
            "employee_id": {
                "type": "integer", "role": "primary_key",
                "min": 1000, "max": 9999, "pii": False
            },
            "full_name": {
                "type": "string", "pii": True, "pii_type": "PERSON_NAME",
                "avg_length": 14
            },
            "email": {
                "type": "string", "pii": True, "pii_type": "EMAIL",
                "pattern": "****@company.com"
            },
            "department": {
                "type": "categorical",
                "categories": {
                    "Engineering": 0.28, "Sales": 0.22, "Marketing": 0.12,
                    "HR": 0.08, "Finance": 0.10, "Operations": 0.20
                },
                "pii": False
            },
            "salary": {
                "type": "float",
                "min": 35000, "max": 320000, "mean": 95000,
                "std_dev": 48000, "distribution": "right_skewed",
                "pii": False
            },
            "hire_date": {
                "type": "date",
                "min": "2010-01-01", "max": "2024-12-31",
                "pii": False
            },
            "performance_rating": {
                "type": "categorical",
                "categories": {"1-Poor": 0.05, "2-Below": 0.12, "3-Meets": 0.45, "4-Exceeds": 0.30, "5-Outstanding": 0.08},
                "pii": False
            },
            "is_manager": {
                "type": "boolean", "true_pct": 0.18, "pii": False
            }
        },
        "correlations": {
            "salary_vs_performance_rating": 0.52,
            "salary_vs_is_manager": 0.67,
            "hire_date_vs_salary": 0.41
        },
        "constraints": {
            "primary_key": "employee_id",
            "not_null": ["employee_id", "full_name", "department", "salary"]
        },
        "pii_summary": {
            "pii_columns": ["full_name", "email"],
            "pii_column_count": 2,
            "risk_level": "HIGH"
        }
    },

    "demo_medical": {
        "table": "patients",
        "row_count": 50000,
        "data_domain": "healthcare",
        "columns": {
            "patient_id": {
                "type": "string", "role": "primary_key",
                "pattern": "PAT-XXXXXXXX", "pii": False
            },
            "age": {
                "type": "integer",
                "min": 0, "max": 99, "mean": 45.2,
                "std_dev": 22.1, "distribution": "bimodal",
                "pii": False
            },
            "gender": {
                "type": "categorical",
                "categories": {"Male": 0.48, "Female": 0.50, "Other": 0.02},
                "pii": False
            },
            "diagnosis_code": {
                "type": "categorical",
                "categories": {
                    "J45": 0.12, "E11": 0.18, "I10": 0.22,
                    "M54": 0.09, "F32": 0.11, "Other": 0.28
                },
                "pii": False
            },
            "admission_date": {
                "type": "date", "min": "2018-01-01", "max": "2024-12-31",
                "pii": False
            },
            "length_of_stay_days": {
                "type": "integer",
                "min": 1, "max": 120, "mean": 4.2,
                "std_dev": 7.8, "distribution": "exponential",
                "pii": False
            },
            "readmitted_30_days": {
                "type": "boolean", "true_pct": 0.143, "pii": False
            }
        },
        "correlations": {
            "age_vs_length_of_stay": 0.31,
            "diagnosis_vs_readmission": 0.44
        },
        "constraints": {
            "primary_key": "patient_id",
            "not_null": ["patient_id", "age", "diagnosis_code"]
        },
        "pii_summary": {
            "pii_columns": [],
            "pii_column_count": 0,
            "risk_level": "MEDIUM",
            "note": "No direct PII but HIPAA-sensitive quasi-identifiers present"
        }
    }
}


class DataProfiler:
    def profile(self, source_id: str) -> dict:
        """
        In PoC: returns pre-built manifest for demo datasets.
        In Enterprise: connects to real source and computes statistics.
        """
        if source_id not in DEMO_DATASETS:
            raise ValueError(f"Unknown source: {source_id}")

        manifest = DEMO_DATASETS[source_id].copy()

        # Add profiling metadata
        manifest["profiling_metadata"] = {
            "profiler_version": "1.0.0",
            "profiling_method": "statistical_sampling",
            "sample_size": min(manifest["row_count"], 100000),
            "confidence_level": 0.95,
            "raw_data_accessed": False,
            "note": "Only statistical properties extracted. No raw data copied."
        }

        return manifest
