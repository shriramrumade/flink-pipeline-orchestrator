"""
Synthetic Data Generation Platform - PoC Backend
FastAPI application serving as the core API layer
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import uuid
import json
import time
from datetime import datetime

# Import our modules
from profiler import DataProfiler
from generator import SyntheticDataGenerator
from validator import DataValidator
from catalog import DataCatalog
from audit import AuditLogger

app = FastAPI(
    title="Synthetic Data Generation Platform",
    description="Enterprise-grade synthetic data generation PoC",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize services
profiler = DataProfiler()
generator = SyntheticDataGenerator()
validator = DataValidator()
catalog = DataCatalog()
audit = AuditLogger()

# In-memory job store for PoC (use Redis/DB in enterprise)
jobs: Dict[str, Any] = {}


# ─── Request / Response Models ────────────────────────────────────────────────

class ProfileRequest(BaseModel):
    source_type: str          # csv | json | postgres | mysql
    source_config: Dict[str, Any]
    dataset_name: str
    description: Optional[str] = ""

class GenerationRequest(BaseModel):
    manifest_id: str
    num_rows: int = 1000
    output_format: str = "json"   # json | csv
    requestor: str = "demo_user"
    purpose: str = "development"

class JobStatus(BaseModel):
    job_id: str
    status: str
    progress: int
    message: str
    result: Optional[Any] = None
    created_at: str


# ─── Health ────────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "healthy", "version": "1.0.0", "timestamp": datetime.utcnow().isoformat()}


# ─── Data Sources ──────────────────────────────────────────────────────────────

@app.get("/api/sources")
def list_sources():
    """Return built-in demo data sources"""
    return {
        "sources": [
            {
                "id": "demo_customers",
                "name": "Customer Database",
                "type": "built-in",
                "tables": ["customers"],
                "description": "Retail customer records with PII"
            },
            {
                "id": "demo_transactions",
                "name": "Transaction History",
                "type": "built-in",
                "tables": ["transactions"],
                "description": "Financial transaction records"
            },
            {
                "id": "demo_employees",
                "name": "HR Employee Data",
                "type": "built-in",
                "tables": ["employees"],
                "description": "HR records with sensitive employee data"
            },
            {
                "id": "demo_medical",
                "name": "Patient Records",
                "type": "built-in",
                "tables": ["patients"],
                "description": "Medical patient data (HIPAA sensitive)"
            }
        ]
    }


# ─── Profiling ─────────────────────────────────────────────────────────────────

@app.post("/api/profile")
async def create_profile(request: ProfileRequest, background_tasks: BackgroundTasks):
    """Profile a data source and return statistical manifest"""
    job_id = str(uuid.uuid4())
    manifest_id = str(uuid.uuid4())

    jobs[job_id] = {
        "job_id": job_id,
        "status": "running",
        "progress": 0,
        "message": "Starting profiling...",
        "result": None,
        "created_at": datetime.utcnow().isoformat(),
        "type": "profile"
    }

    audit.log("PROFILE_REQUESTED", {
        "job_id": job_id,
        "dataset": request.dataset_name,
        "source_type": request.source_type,
        "requestor": "demo_user"
    })

    background_tasks.add_task(
        run_profiling_job, job_id, manifest_id, request
    )

    return {"job_id": job_id, "manifest_id": manifest_id, "status": "started"}


async def run_profiling_job(job_id: str, manifest_id: str, request: ProfileRequest):
    try:
        jobs[job_id]["progress"] = 20
        jobs[job_id]["message"] = "Connecting to source..."
        time.sleep(0.5)

        jobs[job_id]["progress"] = 40
        jobs[job_id]["message"] = "Scanning schema and detecting PII..."
        time.sleep(0.5)

        manifest = profiler.profile(request.source_config.get("source_id", "demo_customers"))

        jobs[job_id]["progress"] = 70
        jobs[job_id]["message"] = "Computing statistical distributions..."
        time.sleep(0.5)

        manifest["manifest_id"] = manifest_id
        manifest["dataset_name"] = request.dataset_name
        manifest["description"] = request.description
        manifest["created_at"] = datetime.utcnow().isoformat()

        catalog.save_manifest(manifest_id, manifest)

        jobs[job_id]["progress"] = 100
        jobs[job_id]["status"] = "completed"
        jobs[job_id]["message"] = "Profiling complete"
        jobs[job_id]["result"] = manifest

        audit.log("PROFILE_COMPLETED", {"job_id": job_id, "manifest_id": manifest_id})

    except Exception as e:
        jobs[job_id]["status"] = "failed"
        jobs[job_id]["message"] = str(e)


# ─── Manifests ─────────────────────────────────────────────────────────────────

@app.get("/api/manifests")
def list_manifests():
    return {"manifests": catalog.list_manifests()}

@app.get("/api/manifests/{manifest_id}")
def get_manifest(manifest_id: str):
    manifest = catalog.get_manifest(manifest_id)
    if not manifest:
        raise HTTPException(status_code=404, detail="Manifest not found")
    return manifest


# ─── Generation ────────────────────────────────────────────────────────────────

@app.post("/api/generate")
async def generate_data(request: GenerationRequest, background_tasks: BackgroundTasks):
    """Generate synthetic data from a manifest"""
    manifest = catalog.get_manifest(request.manifest_id)
    if not manifest:
        raise HTTPException(status_code=404, detail="Manifest not found")

    job_id = str(uuid.uuid4())
    jobs[job_id] = {
        "job_id": job_id,
        "status": "running",
        "progress": 0,
        "message": "Initializing generation...",
        "result": None,
        "created_at": datetime.utcnow().isoformat(),
        "type": "generate"
    }

    audit.log("GENERATION_REQUESTED", {
        "job_id": job_id,
        "manifest_id": request.manifest_id,
        "num_rows": request.num_rows,
        "requestor": request.requestor,
        "purpose": request.purpose
    })

    background_tasks.add_task(
        run_generation_job, job_id, manifest, request
    )

    return {"job_id": job_id, "status": "started"}


async def run_generation_job(job_id: str, manifest: dict, request: GenerationRequest):
    try:
        jobs[job_id]["progress"] = 15
        jobs[job_id]["message"] = "Selecting AI model (CTGAN / GaussianCopula)..."
        time.sleep(0.4)

        jobs[job_id]["progress"] = 28
        jobs[job_id]["message"] = "Building training DataFrame from manifest (no raw data used)..."
        time.sleep(0.5)

        jobs[job_id]["progress"] = 42
        jobs[job_id]["message"] = "Training CTGAN — Generator and Discriminator networks competing (100 epochs)..."
        time.sleep(1.0)

        jobs[job_id]["progress"] = 58
        jobs[job_id]["message"] = f"Sampling {request.num_rows} synthetic rows from trained model..."
        time.sleep(0.4)

        synthetic_data = generator.generate(manifest, request.num_rows)

        jobs[job_id]["progress"] = 65
        jobs[job_id]["message"] = "Running validation and privacy audit..."
        time.sleep(0.5)

        validation_result = validator.validate(manifest, synthetic_data)

        jobs[job_id]["progress"] = 85
        jobs[job_id]["message"] = "Finalizing dataset..."
        time.sleep(0.3)

        dataset_id = str(uuid.uuid4())
        result = {
            "dataset_id": dataset_id,
            "manifest_id": request.manifest_id,
            "num_rows": len(synthetic_data),
            "validation": validation_result,
            "data": synthetic_data[:50],       # Return first 50 rows for preview
            "total_rows": len(synthetic_data),
            "generated_at": datetime.utcnow().isoformat()
        }

        catalog.save_dataset(dataset_id, {
            "dataset_id": dataset_id,
            "manifest_id": request.manifest_id,
            "num_rows": len(synthetic_data),
            "validation_score": validation_result["overall_score"],
            "requestor": request.requestor,
            "purpose": request.purpose,
            "generated_at": datetime.utcnow().isoformat()
        })

        jobs[job_id]["progress"] = 100
        jobs[job_id]["status"] = "completed"
        jobs[job_id]["message"] = "Generation complete"
        jobs[job_id]["result"] = result

        audit.log("GENERATION_COMPLETED", {
            "job_id": job_id,
            "dataset_id": dataset_id,
            "rows_generated": len(synthetic_data),
            "validation_score": validation_result["overall_score"]
        })

    except Exception as e:
        jobs[job_id]["status"] = "failed"
        jobs[job_id]["message"] = str(e)
        audit.log("GENERATION_FAILED", {"job_id": job_id, "error": str(e)})


# ─── Jobs ──────────────────────────────────────────────────────────────────────

@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    return jobs[job_id]

@app.get("/api/jobs")
def list_jobs():
    return {"jobs": list(jobs.values())}


# ─── Datasets ─────────────────────────────────────────────────────────────────

@app.get("/api/datasets")
def list_datasets():
    return {"datasets": catalog.list_datasets()}


# ─── Audit ─────────────────────────────────────────────────────────────────────

@app.get("/api/audit")
def get_audit_log():
    return {"logs": audit.get_logs()}


# ─── Stats / Dashboard ────────────────────────────────────────────────────────

@app.get("/api/stats")
def get_stats():
    datasets  = catalog.list_datasets()
    manifests = catalog.list_manifests()
    logs      = audit.get_logs()

    # Detect which engines are actually available
    try:
        import sdv
        sdv_version = sdv.__version__
        sdv_available = True
    except ImportError:
        sdv_version = None
        sdv_available = False

    try:
        import scipy
        scipy_available = True
    except ImportError:
        scipy_available = False

    try:
        import sklearn
        sklearn_available = True
    except ImportError:
        sklearn_available = False

    return {
        "total_manifests": len(manifests),
        "total_datasets": len(datasets),
        "total_rows_generated": sum(d.get("num_rows", 0) for d in datasets),
        "total_audit_events": len(logs),
        "avg_validation_score": round(
            sum(d.get("validation_score", 0) for d in datasets) / max(len(datasets), 1), 2
        ),
        "engines": {
            "generation": "CTGAN (SDV)" if sdv_available else "Statistical Sampler (fallback)",
            "validation": "scipy KS test" if scipy_available else "Simulated (install scipy)",
            "tstr":       "sklearn RandomForest" if sklearn_available else "Simulated (install scikit-learn)",
            "privacy":    "sklearn MIA classifier" if sklearn_available else "Simulated (install scikit-learn)",
            "sdv_version": sdv_version,
            "sdv_available": sdv_available,
            "scipy_available": scipy_available,
            "sklearn_available": sklearn_available
        }
    }


@app.get("/api/model-info/{manifest_id}")
def get_model_info(manifest_id: str):
    """Returns whether a trained CTGAN model is cached for a manifest."""
    return generator.get_model_info(manifest_id)


@app.delete("/api/model-cache/{manifest_id}")
def clear_model_cache(manifest_id: str):
    """Force retrain on next generation call."""
    generator.clear_cache(manifest_id)
    return {"cleared": manifest_id}
