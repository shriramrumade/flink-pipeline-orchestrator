"""
Real AI Generation Engine — CTGAN + SDV
────────────────────────────────────────
Replaces the statistical sampler with a real trained GAN.

Architecture:
  Manifest → TrainingDataBuilder → training_df
  training_df → CTGANSynthesizer.fit() → trained model
  trained model → .sample(n) → raw synthetic DataFrame
  raw DataFrame → PII post-processor → final List[dict]

Model selection logic:
  Tabular data           → CTGAN  (Conditional Tabular GAN)
  Small dataset (<500r)  → GaussianCopulaSynthesizer (faster, lighter)
  Future: time-series    → PARSynthesizer (in SDV)
  Future: text columns   → LLM (separate module)

Model caching:
  Trained models are cached in memory (keyed by manifest_id).
  Enterprise: persist to disk/S3 with joblib, reload on restart.
"""

import os
import random
import string
import logging
from typing import List, Dict, Any, Optional

import pandas as pd
import numpy as np

# ── SDV imports ────────────────────────────────────────────────────────────────
try:
    from sdv.single_table import CTGANSynthesizer, GaussianCopulaSynthesizer
    from sdv.metadata import SingleTableMetadata
    SDV_AVAILABLE = True
except ImportError:
    SDV_AVAILABLE = False
    logging.warning("SDV not installed. Run: pip install sdv. Falling back to statistical generator.")

from training_builder import TrainingDataBuilder

logger = logging.getLogger(__name__)

# ── PII replacement pools ──────────────────────────────────────────────────────
try:
    from faker import Faker
    _faker = Faker()
    FAKER_AVAILABLE = True
except ImportError:
    FAKER_AVAILABLE = False
    _faker = None

FIRST_NAMES = ["James","Mary","John","Patricia","Robert","Jennifer","Michael",
               "Linda","William","Barbara","David","Elizabeth","Richard","Susan",
               "Joseph","Jessica","Thomas","Sarah","Charles","Karen","Christopher"]
LAST_NAMES  = ["Smith","Johnson","Williams","Brown","Jones","Garcia","Miller",
               "Davis","Rodriguez","Martinez","Wilson","Anderson","Taylor","Moore",
               "Jackson","Martin","Lee","Perez","Thompson","White","Harris"]
CITIES      = ["New York","Los Angeles","Chicago","Houston","Phoenix",
               "Philadelphia","San Antonio","San Diego","Dallas","San Jose",
               "Austin","Seattle","Denver","Nashville","Boston","Atlanta"]
MERCHANTS   = ["Amazon","Walmart","Target","Best Buy","Whole Foods","Starbucks",
               "McDonald's","Apple Store","Nike","Home Depot","Costco","CVS",
               "Walgreens","Delta Airlines","Netflix","Spotify","Uber","DoorDash"]


# ══════════════════════════════════════════════════════════════════════════════
# MAIN GENERATOR CLASS
# ══════════════════════════════════════════════════════════════════════════════

class SyntheticDataGenerator:
    """
    AI-powered synthetic data generator.
    Uses CTGAN (via SDV) when available; falls back to statistical sampling.
    """

    def __init__(self):
        self._model_cache: Dict[str, Any] = {}   # manifest_id → trained model
        self._training_builder = TrainingDataBuilder()
        self._use_ctgan = SDV_AVAILABLE

    def generate(self, manifest: dict, num_rows: int) -> List[Dict[str, Any]]:
        manifest_id = manifest.get("manifest_id", "unknown")
        table       = manifest.get("table", "unknown")
        logger.info(f"Generating {num_rows} rows for table={table} using {'CTGAN' if self._use_ctgan else 'statistical sampler'}")

        if self._use_ctgan:
            return self._generate_with_ctgan(manifest, num_rows, manifest_id)
        else:
            return self._generate_statistical(manifest, num_rows)

    # ─── CTGAN Path ───────────────────────────────────────────────────────────

    def _generate_with_ctgan(self, manifest: dict, num_rows: int, manifest_id: str) -> List[Dict[str, Any]]:
        model = self._model_cache.get(manifest_id)

        if model is None:
            logger.info(f"No cached model for {manifest_id}. Building training data and fitting CTGAN...")
            n_train = min(5000, max(500, num_rows * 3))
            training_df = self._training_builder.build(manifest, n_rows=n_train)
            logger.info(f"Training DataFrame: {training_df.shape[0]} rows x {training_df.shape[1]} cols")
            metadata = self._build_sdv_metadata(manifest, training_df)
            model = self._train_model(training_df, metadata, manifest)
            self._model_cache[manifest_id] = model
            logger.info(f"Model trained and cached for manifest {manifest_id}")

        logger.info(f"Sampling {num_rows} rows from trained model...")
        try:
            synthetic_df = model.sample(num_rows=num_rows)
        except Exception as e:
            logger.error(f"CTGAN sampling failed: {e}. Falling back to statistical generator.")
            return self._generate_statistical(manifest, num_rows)

        synthetic_df = self._replace_pii_columns(synthetic_df, manifest)
        result = synthetic_df.where(pd.notna(synthetic_df), None).to_dict(orient="records")
        return [self._clean_row(row) for row in result]

    def _build_sdv_metadata(self, manifest: dict, df: pd.DataFrame) -> "SingleTableMetadata":
        metadata = SingleTableMetadata()
        cols = manifest.get("columns", {})

        for col_name in df.columns:
            props = cols.get(col_name, {})
            col_type = props.get("type", "string")
            role = props.get("role", "")

            if role == "primary_key":
                metadata.add_column(col_name, sdtype="id")
                metadata.set_primary_key(col_name)
            elif col_type in ("integer", "float"):
                metadata.add_column(col_name, sdtype="numerical")
            elif col_type == "boolean":
                metadata.add_column(col_name, sdtype="boolean")
            elif col_type == "categorical":
                metadata.add_column(col_name, sdtype="categorical")
            elif col_type in ("date", "datetime"):
                metadata.add_column(col_name, sdtype="datetime", datetime_format="%Y-%m-%d")
            else:
                metadata.add_column(col_name, sdtype="categorical")

        return metadata

    def _train_model(self, df: pd.DataFrame, metadata: "SingleTableMetadata", manifest: dict):
        row_count     = manifest.get("row_count", 0)
        n_correlations = len(manifest.get("correlations", {}))
        use_ctgan = row_count > 5000 or n_correlations >= 2

        if use_ctgan:
            logger.info("Selecting CTGANSynthesizer")
            model = CTGANSynthesizer(
                metadata,
                epochs=100,              # PoC: 100  |  Enterprise: 300-500
                batch_size=500,
                generator_dim=(256, 256),
                discriminator_dim=(256, 256),
                generator_lr=2e-4,
                discriminator_lr=2e-4,
                pac=10,
                cuda=False,
                verbose=False
            )
        else:
            logger.info("Selecting GaussianCopulaSynthesizer (small/fast)")
            model = GaussianCopulaSynthesizer(
                metadata,
                enforce_min_max_values=True,
                enforce_rounding=True
            )

        model.fit(df)
        return model

    # ─── PII Post-Processor ────────────────────────────────────────────────────

    def _replace_pii_columns(self, df: pd.DataFrame, manifest: dict) -> pd.DataFrame:
        cols = manifest.get("columns", {})
        n = len(df)

        for col_name, props in cols.items():
            if col_name not in df.columns:
                continue
            role     = props.get("role", "")
            pii_type = props.get("pii_type", "")

            if pii_type == "EMAIL" or role == "email":
                df[col_name] = [self._fake_email() for _ in range(n)]
            elif pii_type == "PERSON_NAME" or role == "name":
                if "first" in col_name.lower():
                    df[col_name] = [random.choice(FIRST_NAMES) for _ in range(n)]
                elif "last" in col_name.lower():
                    df[col_name] = [random.choice(LAST_NAMES) for _ in range(n)]
                else:
                    df[col_name] = [f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}" for _ in range(n)]
            elif pii_type == "LOCATION" or role == "location":
                df[col_name] = [random.choice(CITIES) for _ in range(n)]

        if "merchant_name" in df.columns:
            df["merchant_name"] = [random.choice(MERCHANTS) for _ in range(n)]
        if "transaction_id" in df.columns:
            df["transaction_id"] = [f"TXN-{self._rand_hex(8)}" for _ in range(n)]
        if "patient_id" in df.columns:
            df["patient_id"] = [f"PAT-{self._rand_hex(8)}" for _ in range(n)]

        return df

    # ─── Statistical Fallback ─────────────────────────────────────────────────

    def _generate_statistical(self, manifest: dict, num_rows: int) -> List[Dict[str, Any]]:
        logger.warning("Using statistical fallback generator (SDV not installed)")
        df = self._training_builder.build(manifest, n_rows=num_rows)
        df = self._replace_pii_columns(df, manifest)
        return [self._clean_row(row) for row in df.where(pd.notna(df), None).to_dict(orient="records")]

    # ─── Helpers ──────────────────────────────────────────────────────────────

    def _fake_email(self) -> str:
        if FAKER_AVAILABLE:
            return _faker.email()
        domains = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com"]
        user = ''.join(random.choices(string.ascii_lowercase, k=random.randint(6, 10)))
        num  = str(random.randint(1, 99)) if random.random() < 0.4 else ""
        return f"{user}{num}@{random.choice(domains)}"

    def _rand_hex(self, n: int) -> str:
        return ''.join(random.choices("0123456789ABCDEF", k=n))

    def _clean_row(self, row: dict) -> dict:
        clean = {}
        for k, v in row.items():
            if v is None:
                clean[k] = None
            elif isinstance(v, float) and np.isnan(v):
                clean[k] = None
            elif isinstance(v, (np.integer,)):
                clean[k] = int(v)
            elif isinstance(v, (np.floating,)):
                clean[k] = round(float(v), 2)
            elif isinstance(v, (np.bool_,)):
                clean[k] = bool(v)
            else:
                clean[k] = v
        return clean

    def get_model_info(self, manifest_id: str) -> dict:
        if manifest_id not in self._model_cache:
            return {"cached": False}
        return {"cached": True, "model_type": type(self._model_cache[manifest_id]).__name__, "sdv_available": SDV_AVAILABLE}

    def clear_cache(self, manifest_id: str = None):
        if manifest_id:
            self._model_cache.pop(manifest_id, None)
        else:
            self._model_cache.clear()
