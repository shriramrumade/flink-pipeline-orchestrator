"""
Training Data Builder
─────────────────────
CTGAN needs a real pandas DataFrame to train on.
In production: this is a SAMPLE of real data (e.g. 5,000 rows).
In our PoC:    we reconstruct a representative training set from
               the manifest's statistical properties.

This module sits between the manifest and CTGAN:
  Manifest → TrainingDataBuilder → DataFrame → CTGAN.fit()
"""

import pandas as pd
import numpy as np
import random
import math
import string
from datetime import datetime, timedelta
from typing import Dict, Any


class TrainingDataBuilder:
    """
    Builds a representative training DataFrame from a statistical manifest.

    WHY: CTGAN.fit() requires a DataFrame. In production you pass in
    a real data sample. Here we reconstruct a statistically faithful
    sample from the manifest so the full PoC works without real data.

    Enterprise swap: Replace build() with:
        df = pd.read_sql("SELECT * FROM table TABLESAMPLE(5000 ROWS)", conn)
    """

    def build(self, manifest: dict, n_rows: int = 5000) -> pd.DataFrame:
        """Build training DataFrame from manifest. Returns pandas DataFrame."""
        table = manifest.get("table", "unknown")
        cols = manifest.get("columns", {})

        rows = []
        for i in range(n_rows):
            row = {}
            for col_name, props in cols.items():
                row[col_name] = self._sample_column(col_name, props, i)
            rows.append(row)

        df = pd.DataFrame(rows)

        # Apply post-generation correlations
        df = self._apply_correlations(df, manifest)

        # Cast types correctly for CTGAN
        df = self._cast_types(df, cols)

        return df

    # ─── Per-column sampling ──────────────────────────────────────────────────

    def _sample_column(self, name: str, props: dict, idx: int) -> Any:
        col_type = props.get("type", "string")
        role = props.get("role", "")
        pii = props.get("pii", False)
        null_pct = props.get("nulls_pct", 0.0)

        # Inject nulls
        if null_pct > 0 and random.random() < (null_pct / 100):
            return None

        if role == "primary_key":
            return idx + 1

        if col_type == "integer":
            return self._sample_int(props)

        if col_type == "float":
            return self._sample_float(props)

        if col_type == "boolean":
            return bool(random.random() < props.get("true_pct", 0.5))

        if col_type == "categorical":
            return self._sample_categorical(props.get("categories", {}))

        if col_type in ("date", "datetime"):
            return self._sample_date(props)

        if col_type == "string":
            if role == "email":
                return self._fake_email()
            if role == "name":
                return self._fake_name()
            if role == "primary_key":
                return f"ID-{idx+1:08d}"
            if "pattern" in props:
                pat = props["pattern"]
                return pat.replace("X", lambda: random.choice(string.ascii_uppercase + string.digits))
            return f"value_{random.randint(1, 9999)}"

        return None

    def _sample_int(self, props: dict) -> int:
        dist = props.get("distribution", "uniform")
        lo, hi = props.get("min", 0), props.get("max", 100)
        mean = props.get("mean", (lo + hi) / 2)
        std = props.get("std_dev", (hi - lo) / 6)
        if dist == "normal":
            v = int(round(np.random.normal(mean, std)))
        elif dist == "right_skewed":
            v = int(round(np.random.lognormal(math.log(max(mean, 1)) * 0.85, std / max(mean, 1) * 0.6)))
        elif dist == "exponential":
            v = int(round(np.random.exponential(mean)))
        else:
            v = random.randint(lo, hi)
        return max(lo, min(hi, v))

    def _sample_float(self, props: dict) -> float:
        dist = props.get("distribution", "uniform")
        lo, hi = props.get("min", 0.0), props.get("max", 1000.0)
        mean = props.get("mean", (lo + hi) / 2)
        std = props.get("std_dev", (hi - lo) / 6)
        if dist == "normal":
            v = np.random.normal(mean, std)
        elif dist == "right_skewed":
            v = np.random.lognormal(math.log(max(mean, 1)) * 0.85, std / max(mean, 1) * 0.6)
        else:
            v = random.uniform(lo, hi)
        return round(max(lo, min(hi, float(v))), 2)

    def _sample_categorical(self, categories: dict) -> str:
        if not categories:
            return "unknown"
        keys = list(categories.keys())
        weights = list(categories.values())
        total = sum(weights)
        weights = [w / total for w in weights]
        return random.choices(keys, weights=weights, k=1)[0]

    def _sample_date(self, props: dict) -> str:
        fmt = "%Y-%m-%d"
        min_d = props.get("min", "2015-01-01")[:10]
        max_d = props.get("max", "2024-12-31")[:10]
        try:
            d1 = datetime.strptime(min_d, fmt)
            d2 = datetime.strptime(max_d, fmt)
            delta = max((d2 - d1).days, 1)
            return (d1 + timedelta(days=random.randint(0, delta))).strftime(fmt)
        except Exception:
            return "2020-01-01"

    def _fake_email(self) -> str:
        domains = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com"]
        weights = [0.45, 0.22, 0.18, 0.15]
        user = ''.join(random.choices(string.ascii_lowercase, k=random.randint(5, 10)))
        num = str(random.randint(1, 99)) if random.random() < 0.4 else ""
        return f"{user}{num}@{random.choices(domains, weights=weights, k=1)[0]}"

    def _fake_name(self) -> str:
        first = random.choice(["James","Mary","John","Patricia","Robert","Jennifer",
                               "Michael","Linda","William","Barbara","David","Elizabeth"])
        last  = random.choice(["Smith","Johnson","Williams","Brown","Jones","Garcia",
                               "Miller","Davis","Rodriguez","Martinez","Wilson","Anderson"])
        return f"{first} {last}"

    # ─── Post-generation correlation enforcement ──────────────────────────────

    def _apply_correlations(self, df: pd.DataFrame, manifest: dict) -> pd.DataFrame:
        """
        Enforce key correlations CTGAN may not fully capture from a small seed.
        In production CTGAN learns correlations from real data — this is only
        needed when building training data from a manifest.
        """
        table = manifest.get("table", "")

        if table == "customers" and "annual_income" in df.columns and "loyalty_tier" in df.columns:
            if df["annual_income"].max() > df["annual_income"].min():
                pct = (df["annual_income"] - df["annual_income"].min()) / (
                    df["annual_income"].max() - df["annual_income"].min()
                )
                df["loyalty_tier"] = pd.cut(
                    pct, bins=[0, 0.35, 0.65, 0.85, 1.0],
                    labels=["Bronze", "Silver", "Gold", "Platinum"]
                ).astype(str)

        if table == "employees" and "salary" in df.columns and "is_manager" in df.columns:
            manager_mask = df["is_manager"] == True
            df.loc[manager_mask, "salary"] = (df.loc[manager_mask, "salary"] * 1.35).clip(upper=320000)

        if table == "transactions" and "is_fraud" in df.columns and "amount" in df.columns:
            fraud_mask = df["is_fraud"] == True
            df.loc[fraud_mask, "amount"] = df.loc[fraud_mask, "amount"].apply(
                lambda _: round(random.uniform(300, 9999), 2)
            )

        return df

    # ─── Type casting for CTGAN ───────────────────────────────────────────────

    def _cast_types(self, df: pd.DataFrame, cols: dict) -> pd.DataFrame:
        """Cast columns to types CTGAN expects."""
        for col_name, props in cols.items():
            if col_name not in df.columns:
                continue
            col_type = props.get("type", "string")
            try:
                if col_type == "integer":
                    df[col_name] = pd.to_numeric(df[col_name], errors="coerce").astype("Int64")
                elif col_type == "float":
                    df[col_name] = pd.to_numeric(df[col_name], errors="coerce").astype(float)
                elif col_type == "boolean":
                    df[col_name] = df[col_name].astype(bool)
                elif col_type == "categorical":
                    df[col_name] = df[col_name].astype(str)
                else:
                    df[col_name] = df[col_name].astype(str)
            except Exception:
                pass  # Leave column as-is if cast fails
        return df
