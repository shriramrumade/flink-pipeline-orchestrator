import { useState, useEffect, useCallback } from "react";

// ─── API Layer ─────────────────────────────────────────────────────────────────
const API = "http://localhost:8000";

const api = {
  get: (path) => fetch(`${API}${path}`).then(r => r.json()),
  post: (path, body) => fetch(`${API}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  }).then(r => r.json())
};

// ─── Icons ─────────────────────────────────────────────────────────────────────
const Icon = ({ name, size = 18 }) => {
  const icons = {
    database: "M4 6C4 4.34315 8.02944 3 13 3C17.9706 3 22 4.34315 22 6V18C22 19.6569 17.9706 21 13 21C8.02944 21 4 19.6569 4 18V6ZM4 10C4 11.6569 8.02944 13 13 13C17.9706 13 22 11.6569 22 10M4 14C4 15.6569 8.02944 17 13 17C17.9706 17 22 15.6569 22 14",
    cpu: "M9 3H15M9 21H15M3 9V15M21 9V15M7 3V7H3M17 3V7H21M7 21V17H3M17 21V17H21M9 9H15V15H9V9Z",
    shield: "M12 22S4 18 4 12V5L12 2L20 5V12C20 18 12 22 12 22Z",
    check: "M20 6L9 17L4 12",
    x: "M18 6L6 18M6 6L18 18",
    loader: "M12 2V6M12 18V22M4.93 4.93L7.76 7.76M16.24 16.24L19.07 19.07M2 12H6M18 12H22M4.93 19.07L7.76 16.24M16.24 7.76L19.07 4.93",
    layers: "M12 2L2 7L12 12L22 7L12 2ZM2 17L12 22L22 17M2 12L12 17L22 12",
    activity: "M22 12H18L15 21L9 3L6 12H2",
    file: "M14 2H6C5.46957 2 4.96086 2.21071 4.58579 2.58579C4.21071 2.96086 4 3.46957 4 4V20C4 20.5304 4.21071 21.0391 4.58579 21.4142C4.96086 21.7893 5.46957 22 6 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V8L14 2Z",
    download: "M21 15V19C21 19.5304 20.7893 20.0391 20.4142 20.4142C20.0391 20.7893 19.5304 21 19 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V15M7 10L12 15L17 10M12 15V3",
    eye: "M1 12S5 4 12 4 23 12 23 12 19 20 12 20 1 12 1 12ZM12 15A3 3 0 100 6A3 3 0 000-6Z",
    list: "M8 6H21M8 12H21M8 18H21M3 6H3.01M3 12H3.01M3 18H3.01",
    plus: "M12 5V19M5 12H19",
    arrow: "M5 12H19M12 5L19 12L12 19",
    warning: "M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0zM12 9v4M12 17h.01",
    clock: "M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22ZM12 6V12L16 14",
    log: "M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z M14 2v6h6 M16 13H8M16 17H8M10 9H8"
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d={icons[name] || icons.file} />
    </svg>
  );
};

// ─── Pill Badge ────────────────────────────────────────────────────────────────
const Badge = ({ label, color = "gray" }) => {
  const colors = {
    green: "background:#0d2b1a;color:#34d399;border:1px solid #065f46",
    red: "background:#2b0d0d;color:#f87171;border:1px solid #7f1d1d",
    yellow: "background:#2b2108;color:#fbbf24;border:1px solid #78350f",
    blue: "background:#0d1b2b;color:#60a5fa;border:1px solid #1e3a5f",
    gray: "background:#1a1a2e;color:#94a3b8;border:1px solid #334155",
    purple: "background:#1e0b2b;color:#c084fc;border:1px solid #6b21a8"
  };
  const style = {};
  colors[color].split(";").forEach(s => {
    const [k, v] = s.split(":");
    if (k && v) style[k.trim().replace(/-([a-z])/g, (_, l) => l.toUpperCase())] = v.trim();
  });
  return (
    <span style={{ ...style, padding: "2px 10px", borderRadius: 99, fontSize: 11, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase", whiteSpace: "nowrap" }}>
      {label}
    </span>
  );
};

// ─── Progress Bar ──────────────────────────────────────────────────────────────
const ProgressBar = ({ value, color = "#00d4aa" }) => (
  <div style={{ background: "#1e2a3a", borderRadius: 99, height: 6, overflow: "hidden", width: "100%" }}>
    <div style={{
      background: `linear-gradient(90deg, ${color}, ${color}cc)`,
      height: "100%", borderRadius: 99,
      width: `${Math.min(value, 100)}%`,
      transition: "width 0.5s ease",
      boxShadow: `0 0 8px ${color}66`
    }} />
  </div>
);

// ─── Stat Card ─────────────────────────────────────────────────────────────────
const StatCard = ({ label, value, icon, color = "#00d4aa", sub }) => (
  <div style={{
    background: "linear-gradient(135deg, #0f1929 0%, #0a1628 100%)",
    border: "1px solid #1e3a5f",
    borderRadius: 16, padding: "20px 24px",
    display: "flex", flexDirection: "column", gap: 8,
    position: "relative", overflow: "hidden"
  }}>
    <div style={{ position: "absolute", top: 16, right: 16, color, opacity: 0.6 }}>
      <Icon name={icon} size={22} />
    </div>
    <div style={{ color: "#64748b", fontSize: 12, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase" }}>{label}</div>
    <div style={{ color: "#f1f5f9", fontSize: 30, fontWeight: 700, letterSpacing: "-0.02em", lineHeight: 1 }}>{value}</div>
    {sub && <div style={{ color: "#475569", fontSize: 12 }}>{sub}</div>}
    <div style={{ position: "absolute", bottom: -20, right: -20, width: 80, height: 80, background: color, opacity: 0.04, borderRadius: "50%" }} />
  </div>
);

// ─── Section Header ────────────────────────────────────────────────────────────
const SectionHeader = ({ title, subtitle, action }) => (
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
    <div>
      <h2 style={{ color: "#f1f5f9", fontSize: 18, fontWeight: 700, margin: 0 }}>{title}</h2>
      {subtitle && <p style={{ color: "#64748b", fontSize: 13, margin: "4px 0 0 0" }}>{subtitle}</p>}
    </div>
    {action}
  </div>
);

// ─── Button ────────────────────────────────────────────────────────────────────
const Btn = ({ children, onClick, variant = "primary", disabled, small, icon }) => {
  const styles = {
    primary: { background: "linear-gradient(135deg, #00d4aa, #0099ff)", color: "#000", fontWeight: 700 },
    secondary: { background: "#1e2a3a", color: "#94a3b8", border: "1px solid #2d3f55" },
    danger: { background: "#2b0d0d", color: "#f87171", border: "1px solid #7f1d1d" },
    ghost: { background: "transparent", color: "#60a5fa", border: "1px solid #1e3a5f" }
  };
  return (
    <button onClick={onClick} disabled={disabled} style={{
      ...styles[variant],
      padding: small ? "6px 14px" : "10px 20px",
      borderRadius: 10, fontSize: small ? 12 : 14,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      display: "inline-flex", alignItems: "center", gap: 6,
      border: styles[variant].border || "none",
      transition: "opacity 0.2s, transform 0.1s",
      letterSpacing: "0.02em"
    }}>
      {icon && <Icon name={icon} size={14} />}
      {children}
    </button>
  );
};

// ─── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("dashboard");
  const [stats, setStats] = useState(null);
  const [sources, setSources] = useState([]);
  const [manifests, setManifests] = useState([]);
  const [datasets, setDatasets] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [jobs, setJobs] = useState({});
  const [notification, setNotification] = useState(null);
  const [backendOnline, setBackendOnline] = useState(null);

  // Modal states
  const [profileModal, setProfileModal] = useState(null);
  const [generateModal, setGenerateModal] = useState(null);
  const [resultModal, setResultModal] = useState(null);

  const notify = (msg, type = "success") => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 3500);
  };

  const loadAll = useCallback(async () => {
    try {
      const [s, src, m, d, a, j] = await Promise.all([
        api.get("/api/stats"),
        api.get("/api/sources"),
        api.get("/api/manifests"),
        api.get("/api/datasets"),
        api.get("/api/audit"),
        api.get("/api/jobs")
      ]);
      setStats(s);
      setSources(src.sources || []);
      setManifests(m.manifests || []);
      setDatasets(d.datasets || []);
      setAuditLogs(a.logs || []);
      const jobMap = {};
      (j.jobs || []).forEach(j => { jobMap[j.job_id] = j; });
      setJobs(jobMap);
      setBackendOnline(true);
    } catch {
      setBackendOnline(false);
    }
  }, []);

  useEffect(() => {
    loadAll();
    const t = setInterval(loadAll, 3000);
    return () => clearInterval(t);
  }, [loadAll]);

  // ─── Profile Flow ────────────────────────────────────────────────────────────
  const startProfile = async (sourceId, name) => {
    const res = await api.post("/api/profile", {
      source_type: "built-in",
      source_config: { source_id: sourceId },
      dataset_name: name,
      description: `Profile for ${name}`
    });
    setProfileModal({ jobId: res.job_id, manifestId: res.manifest_id, stage: "running" });
    notify("Profiling started — extracting statistical manifest...", "info");
  };

  // ─── Generate Flow ───────────────────────────────────────────────────────────
  const startGenerate = async (manifestId, numRows) => {
    const res = await api.post("/api/generate", {
      manifest_id: manifestId,
      num_rows: numRows,
      output_format: "json",
      requestor: "demo_user",
      purpose: "development"
    });
    setGenerateModal({ jobId: res.job_id, stage: "running" });
    notify("Generation started — AI engine running...", "info");
  };

  // ─── Job Polling ─────────────────────────────────────────────────────────────
  const getJob = (id) => jobs[id] || { status: "unknown", progress: 0, message: "" };

  // ─── Nav ─────────────────────────────────────────────────────────────────────
  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: "activity" },
    { id: "sources", label: "Data Sources", icon: "database" },
    { id: "manifests", label: "Manifests", icon: "layers" },
    { id: "generate", label: "Generate", icon: "cpu" },
    { id: "datasets", label: "Datasets", icon: "file" },
    { id: "audit", label: "Audit Log", icon: "log" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#070d18", fontFamily: "'IBM Plex Mono', 'Courier New', monospace", color: "#e2e8f0" }}>
      {/* Notification */}
      {notification && (
        <div style={{
          position: "fixed", top: 20, right: 20, zIndex: 9999,
          background: notification.type === "success" ? "#0d2b1a" : notification.type === "info" ? "#0d1b2b" : "#2b0d0d",
          border: `1px solid ${notification.type === "success" ? "#065f46" : notification.type === "info" ? "#1e3a5f" : "#7f1d1d"}`,
          color: notification.type === "success" ? "#34d399" : notification.type === "info" ? "#60a5fa" : "#f87171",
          padding: "12px 20px", borderRadius: 12, fontSize: 13, fontWeight: 600,
          boxShadow: "0 8px 32px rgba(0,0,0,0.4)"
        }}>
          {notification.msg}
        </div>
      )}

      {/* Sidebar */}
      <div style={{
        position: "fixed", left: 0, top: 0, bottom: 0, width: 220,
        background: "linear-gradient(180deg, #0a1220 0%, #070d18 100%)",
        borderRight: "1px solid #1e2a3a", zIndex: 100,
        display: "flex", flexDirection: "column"
      }}>
        {/* Logo */}
        <div style={{ padding: "24px 20px 20px", borderBottom: "1px solid #1e2a3a" }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "#00d4aa", letterSpacing: "0.1em", textTransform: "uppercase" }}>SynGen</div>
          <div style={{ fontSize: 10, color: "#334155", marginTop: 2, letterSpacing: "0.05em" }}>Synthetic Data Platform</div>
          <div style={{ marginTop: 10, display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 6, height: 6, borderRadius: "50%", background: backendOnline ? "#34d399" : "#f87171", boxShadow: backendOnline ? "0 0 6px #34d399" : "0 0 6px #f87171" }} />
            <span style={{ fontSize: 10, color: "#475569" }}>{backendOnline === null ? "Connecting..." : backendOnline ? "Backend Online" : "Backend Offline"}</span>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ padding: "16px 12px", flex: 1 }}>
          {navItems.map(item => (
            <button key={item.id} onClick={() => setTab(item.id)} style={{
              width: "100%", display: "flex", alignItems: "center", gap: 10,
              padding: "10px 12px", borderRadius: 10, marginBottom: 4,
              background: tab === item.id ? "linear-gradient(135deg, #0d2b40, #0a1f30)" : "transparent",
              border: tab === item.id ? "1px solid #1e3a5f" : "1px solid transparent",
              color: tab === item.id ? "#00d4aa" : "#475569",
              cursor: "pointer", fontSize: 13, fontWeight: tab === item.id ? 600 : 400,
              textAlign: "left", transition: "all 0.15s"
            }}>
              <Icon name={item.icon} size={15} />
              {item.label}
            </button>
          ))}
        </nav>

        <div style={{ padding: "16px 20px", borderTop: "1px solid #1e2a3a" }}>
          <div style={{ fontSize: 10, color: "#1e3a5f", letterSpacing: "0.06em" }}>PoC v1.0 • Enterprise-Ready</div>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ marginLeft: 220, padding: "32px 36px", minHeight: "100vh" }}>

        {/* ── Dashboard ──────────────────────────────────────────────────────── */}
        {tab === "dashboard" && (
          <div>
            <div style={{ marginBottom: 32 }}>
              <h1 style={{ fontSize: 26, fontWeight: 700, color: "#f1f5f9", margin: 0, letterSpacing: "-0.02em" }}>
                Synthetic Data Platform
              </h1>
              <p style={{ color: "#475569", margin: "6px 0 0 0", fontSize: 14 }}>
                Generate privacy-safe synthetic data from statistical manifests — no raw data ever leaves source systems.
              </p>
            </div>

            {/* Stats Row */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 32 }}>
              <StatCard label="Manifests Created" value={stats?.total_manifests ?? 0} icon="layers" color="#00d4aa" sub="Source profiles" />
              <StatCard label="Datasets Generated" value={stats?.total_datasets ?? 0} icon="database" color="#0099ff" sub="Synthetic outputs" />
              <StatCard label="Rows Generated" value={(stats?.total_rows_generated ?? 0).toLocaleString()} icon="file" color="#c084fc" sub="Total synthetic rows" />
              <StatCard label="Avg Quality Score" value={stats?.avg_validation_score ? `${(stats.avg_validation_score * 100).toFixed(0)}%` : "—"} icon="shield" color="#34d399" sub="Fidelity + privacy" />
            </div>

            {/* Architecture Overview */}
            <div style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, padding: 24, marginBottom: 24 }}>
              <SectionHeader title="How It Works" subtitle="Profile-only architecture — raw data never crosses boundaries" />
              <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                {[
                  { label: "1. Source Systems", sub: "Real PII data", color: "#f87171", icon: "database" },
                  { label: "→", sub: "", color: "#334155", icon: null },
                  { label: "2. Profiling Agent", sub: "Stats only — no raw data", color: "#fbbf24", icon: "activity" },
                  { label: "→", sub: "", color: "#334155", icon: null },
                  { label: "3. AI Generation", sub: "CTGAN / LLM / GAN", color: "#60a5fa", icon: "cpu" },
                  { label: "→", sub: "", color: "#334155", icon: null },
                  { label: "4. Validation Gate", sub: "Fidelity + Privacy audit", color: "#c084fc", icon: "shield" },
                  { label: "→", sub: "", color: "#334155", icon: null },
                  { label: "5. Consumers", sub: "Dev / QA / ML teams", color: "#34d399", icon: "layers" }
                ].map((step, i) => (
                  step.icon ? (
                    <div key={i} style={{ background: "#0f1929", border: `1px solid ${step.color}33`, borderRadius: 12, padding: "12px 16px", minWidth: 130 }}>
                      <div style={{ color: step.color, marginBottom: 4 }}><Icon name={step.icon} size={14} /></div>
                      <div style={{ color: step.color, fontSize: 12, fontWeight: 700 }}>{step.label}</div>
                      <div style={{ color: "#475569", fontSize: 10, marginTop: 2 }}>{step.sub}</div>
                    </div>
                  ) : (
                    <div key={i} style={{ color: "#334155", fontSize: 20, fontWeight: 300 }}>→</div>
                  )
                ))}
              </div>
            </div>

            {/* Engine Status */}
            {stats?.engines && (
              <div style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, padding: 24, marginBottom: 24 }}>
                <SectionHeader title="AI/ML Engine Status" subtitle="Real engines active when dependencies installed" />
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 12 }}>
                  {[
                    { label: "Generation", ok: stats.engines.sdv_available, engine: "CTGAN (SDV)", fallback: "Statistical Sampler", detail: stats.engines.sdv_version ? `sdv v${stats.engines.sdv_version}` : "pip install sdv" },
                    { label: "Fidelity Test", ok: stats.engines.scipy_available, engine: "KS Test (scipy)", fallback: "Simulated", detail: "scipy.stats.ks_2samp" },
                    { label: "TSTR", ok: stats.engines.sklearn_available, engine: "RandomForest", fallback: "Simulated", detail: "Train-on-Synth Test-on-Real" },
                    { label: "Privacy Audit", ok: stats.engines.sklearn_available, engine: "MIA Classifier", fallback: "Simulated", detail: "Membership Inference Attack" },
                  ].map(e => (
                    <div key={e.label} style={{ background: "#0f1929", border: `1px solid ${e.ok ? "#065f46" : "#78350f"}`, borderRadius: 12, padding: "14px 16px" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                        <span style={{ color: "#64748b", fontSize: 10, textTransform: "uppercase" }}>{e.label}</span>
                        <span style={{ color: e.ok ? "#34d399" : "#fbbf24", fontSize: 10, fontWeight: 700 }}>{e.ok ? "● LIVE" : "○ FALLBACK"}</span>
                      </div>
                      <div style={{ color: e.ok ? "#34d399" : "#fbbf24", fontSize: 13, fontWeight: 700 }}>{e.ok ? e.engine : e.fallback}</div>
                      <div style={{ color: "#334155", fontSize: 10, marginTop: 4, fontFamily: "monospace" }}>{e.detail}</div>
                    </div>
                  ))}
                </div>
                {!stats.engines.sdv_available && (
                  <div style={{ background: "#0d1929", border: "1px solid #1e3a5f", borderRadius: 10, padding: "12px 16px" }}>
                    <span style={{ color: "#60a5fa", fontSize: 12 }}>To activate real CTGAN: </span>
                    <code style={{ color: "#00d4aa", fontSize: 12 }}>pip install sdv scipy scikit-learn faker</code>
                  </div>
                )}
              </div>
            )}

            {/* Quick Actions */}
            <div style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, padding: 24 }}>
              <SectionHeader title="Quick Start" subtitle="Follow these steps to generate your first synthetic dataset" />
              {[
                { step: "01", title: "Go to Data Sources", desc: "Browse available source schemas and click Profile to extract statistical manifest", action: () => setTab("sources") },
                { step: "02", title: "Review Manifest", desc: "Check the extracted schema, distributions, PII detection, and correlations", action: () => setTab("manifests") },
                { step: "03", title: "Generate Data", desc: "Select a manifest, set row count, and trigger AI generation with validation", action: () => setTab("generate") },
                { step: "04", title: "Review Results", desc: "Inspect validation scores, privacy audit, and preview generated rows", action: () => setTab("datasets") }
              ].map((item) => (
                <div key={item.step} onClick={item.action} style={{
                  display: "flex", alignItems: "center", gap: 16,
                  padding: "14px 0", borderBottom: "1px solid #111b2b",
                  cursor: "pointer"
                }}>
                  <div style={{ color: "#00d4aa", fontSize: 11, fontWeight: 700, minWidth: 24 }}>{item.step}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: "#e2e8f0", fontSize: 14, fontWeight: 600 }}>{item.title}</div>
                    <div style={{ color: "#475569", fontSize: 12, marginTop: 2 }}>{item.desc}</div>
                  </div>
                  <div style={{ color: "#334155" }}><Icon name="arrow" size={16} /></div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Data Sources ───────────────────────────────────────────────────── */}
        {tab === "sources" && (
          <div>
            <SectionHeader
              title="Data Sources"
              subtitle="Browse available source schemas. Profiling extracts statistics only — no raw data moves."
            />
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16 }}>
              {sources.map(src => (
                <div key={src.id} style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, padding: 24 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
                    <div>
                      <div style={{ color: "#f1f5f9", fontSize: 16, fontWeight: 700 }}>{src.name}</div>
                      <div style={{ color: "#475569", fontSize: 12, marginTop: 4 }}>{src.description}</div>
                    </div>
                    <Badge label={src.type} color="blue" />
                  </div>
                  <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
                    {src.tables.map(t => (
                      <span key={t} style={{ background: "#0f1929", border: "1px solid #1e3a5f", color: "#60a5fa", padding: "3px 10px", borderRadius: 8, fontSize: 11 }}>{t}</span>
                    ))}
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <Btn small icon="activity" onClick={() => startProfile(src.id, src.name)}>
                      Profile This Source
                    </Btn>
                  </div>
                </div>
              ))}
            </div>

            {/* Profile Job Status */}
            {profileModal && (() => {
              const job = getJob(profileModal.jobId);
              return (
                <div style={{ marginTop: 24, background: "#0a1220", border: "1px solid #1e3a5f", borderRadius: 16, padding: 24 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                    <div style={{ color: "#60a5fa", fontWeight: 700 }}>Profiling Job Running</div>
                    <Badge label={job.status} color={job.status === "completed" ? "green" : job.status === "failed" ? "red" : "blue"} />
                  </div>
                  <ProgressBar value={job.progress} color="#0099ff" />
                  <div style={{ color: "#64748b", fontSize: 12, marginTop: 8 }}>{job.message}</div>
                  {job.status === "completed" && job.result && (
                    <div style={{ marginTop: 16 }}>
                      <div style={{ color: "#34d399", fontSize: 13, fontWeight: 600, marginBottom: 8 }}>✓ Manifest Created — Statistical profile extracted, no raw data copied</div>
                      <div style={{ display: "flex", gap: 16 }}>
                        <div style={{ background: "#0f1929", borderRadius: 10, padding: "10px 16px", flex: 1 }}>
                          <div style={{ color: "#475569", fontSize: 11 }}>TABLE</div>
                          <div style={{ color: "#e2e8f0", fontWeight: 700 }}>{job.result.table}</div>
                        </div>
                        <div style={{ background: "#0f1929", borderRadius: 10, padding: "10px 16px", flex: 1 }}>
                          <div style={{ color: "#475569", fontSize: 11 }}>SOURCE ROWS</div>
                          <div style={{ color: "#e2e8f0", fontWeight: 700 }}>{job.result.row_count?.toLocaleString()}</div>
                        </div>
                        <div style={{ background: "#0f1929", borderRadius: 10, padding: "10px 16px", flex: 1 }}>
                          <div style={{ color: "#475569", fontSize: 11 }}>COLUMNS</div>
                          <div style={{ color: "#e2e8f0", fontWeight: 700 }}>{Object.keys(job.result.columns || {}).length}</div>
                        </div>
                        <div style={{ background: "#0f1929", borderRadius: 10, padding: "10px 16px", flex: 1 }}>
                          <div style={{ color: "#475569", fontSize: 11 }}>PII RISK</div>
                          <div style={{ color: job.result.pii_summary?.risk_level === "HIGH" ? "#f87171" : "#fbbf24", fontWeight: 700 }}>
                            {job.result.pii_summary?.risk_level}
                          </div>
                        </div>
                      </div>
                      <div style={{ marginTop: 12 }}>
                        <Btn onClick={() => { setTab("generate"); setProfileModal(null); }} icon="cpu">
                          Generate Synthetic Data from this Manifest →
                        </Btn>
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}
          </div>
        )}

        {/* ── Manifests ──────────────────────────────────────────────────────── */}
        {tab === "manifests" && (
          <div>
            <SectionHeader title="Profile Manifests" subtitle="Statistical descriptions extracted from source systems. No raw data stored here." />
            {manifests.length === 0 ? (
              <div style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, padding: 40, textAlign: "center" }}>
                <div style={{ color: "#475569", marginBottom: 16 }}>No manifests yet. Go to Data Sources and profile a source first.</div>
                <Btn onClick={() => setTab("sources")} icon="database">Go to Data Sources</Btn>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                {manifests.map(m => (
                  <div key={m.manifest_id} style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, padding: 24 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                      <div>
                        <div style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 16 }}>{m.dataset_name}</div>
                        <div style={{ color: "#475569", fontSize: 12, marginTop: 2 }}>Table: {m.table} • {m.row_count?.toLocaleString()} source rows • Domain: {m.data_domain}</div>
                      </div>
                      <div style={{ display: "flex", gap: 8 }}>
                        <Badge label={m.risk_level} color={m.risk_level === "HIGH" ? "red" : m.risk_level === "MEDIUM" ? "yellow" : "green"} />
                        <Btn small icon="cpu" onClick={() => { setTab("generate"); }}>Generate →</Btn>
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      {m.risk_level === "HIGH" && <Badge label="PII Detected" color="red" />}
                      <Badge label={`Manifest ID: ${m.manifest_id.slice(0, 8)}...`} color="gray" />
                      <Badge label={m.data_domain} color="purple" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── Generate ───────────────────────────────────────────────────────── */}
        {tab === "generate" && (
          <GenerateTab
            manifests={manifests}
            jobs={jobs}
            onGenerate={startGenerate}
            generateModal={generateModal}
            setResultModal={setResultModal}
            notify={notify}
          />
        )}

        {/* ── Datasets ───────────────────────────────────────────────────────── */}
        {tab === "datasets" && (
          <div>
            <SectionHeader title="Generated Datasets" subtitle="All synthetic datasets produced by the platform" />
            {datasets.length === 0 ? (
              <div style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, padding: 40, textAlign: "center" }}>
                <div style={{ color: "#475569", marginBottom: 16 }}>No datasets yet. Generate synthetic data first.</div>
                <Btn onClick={() => setTab("generate")} icon="cpu">Go to Generate</Btn>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {datasets.map(d => (
                  <div key={d.dataset_id} style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, padding: 20 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 14 }}>Dataset {d.dataset_id.slice(0, 8)}</div>
                        <div style={{ color: "#475569", fontSize: 12, marginTop: 4 }}>
                          {d.num_rows?.toLocaleString()} rows • Requestor: {d.requestor} • Purpose: {d.purpose}
                        </div>
                        <div style={{ color: "#334155", fontSize: 11, marginTop: 4 }}>{d.generated_at}</div>
                      </div>
                      <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                        <div style={{ textAlign: "right" }}>
                          <div style={{ color: "#475569", fontSize: 10, marginBottom: 4 }}>QUALITY SCORE</div>
                          <div style={{ color: "#34d399", fontWeight: 700, fontSize: 18 }}>
                            {d.validation_score ? `${(d.validation_score * 100).toFixed(0)}%` : "—"}
                          </div>
                        </div>
                        <Badge label="PASS" color="green" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── Audit Log ──────────────────────────────────────────────────────── */}
        {tab === "audit" && (
          <div>
            <SectionHeader title="Audit Log" subtitle="Immutable event trail — every action logged for GDPR/HIPAA compliance" />
            <div style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, overflow: "hidden" }}>
              {auditLogs.length === 0 ? (
                <div style={{ padding: 40, textAlign: "center", color: "#475569" }}>No audit events yet.</div>
              ) : (
                auditLogs.slice(0, 50).map((log, i) => (
                  <div key={log.event_id} style={{
                    padding: "14px 24px",
                    borderBottom: "1px solid #111b2b",
                    display: "flex", alignItems: "center", gap: 16
                  }}>
                    <div style={{ minWidth: 100 }}>
                      <Badge
                        label={log.event_type.replace("_", " ")}
                        color={log.event_type.includes("COMPLETED") ? "green" : log.event_type.includes("FAILED") ? "red" : "blue"}
                      />
                    </div>
                    <div style={{ color: "#64748b", fontSize: 11, minWidth: 180 }}>{log.timestamp}</div>
                    <div style={{ color: "#334155", fontSize: 11, flex: 1, fontFamily: "monospace" }}>
                      {JSON.stringify(log.metadata).slice(0, 100)}...
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Result Modal */}
      {resultModal && (
        <ResultModal data={resultModal} onClose={() => setResultModal(null)} />
      )}
    </div>
  );
}

// ─── Generate Tab ──────────────────────────────────────────────────────────────
function GenerateTab({ manifests, jobs, onGenerate, generateModal, setResultModal, notify }) {
  const [selectedManifest, setSelectedManifest] = useState("");
  const [numRows, setNumRows] = useState(1000);

  const job = generateModal ? (jobs[generateModal.jobId] || { status: "unknown", progress: 0, message: "" }) : null;

  useEffect(() => {
    if (job?.status === "completed" && job?.result) {
      notify("✓ Dataset generated and validated successfully!", "success");
    }
  }, [job?.status]);

  return (
    <div>
      <SectionHeader title="Generate Synthetic Data" subtitle="Select a manifest and configure generation parameters" />

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        {/* Config Panel */}
        <div style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, padding: 24 }}>
          <div style={{ color: "#94a3b8", fontSize: 13, fontWeight: 600, marginBottom: 20 }}>GENERATION CONFIGURATION</div>

          <div style={{ marginBottom: 20 }}>
            <label style={{ color: "#64748b", fontSize: 12, display: "block", marginBottom: 8 }}>SELECT MANIFEST</label>
            <select
              value={selectedManifest}
              onChange={e => setSelectedManifest(e.target.value)}
              style={{
                width: "100%", background: "#0f1929", border: "1px solid #1e3a5f",
                color: "#e2e8f0", borderRadius: 10, padding: "10px 14px", fontSize: 13,
                outline: "none"
              }}
            >
              <option value="">— Select a manifest —</option>
              {manifests.map(m => (
                <option key={m.manifest_id} value={m.manifest_id}>
                  {m.dataset_name} ({m.table} · {m.row_count?.toLocaleString()} source rows)
                </option>
              ))}
            </select>
            {manifests.length === 0 && (
              <div style={{ color: "#f87171", fontSize: 11, marginTop: 6 }}>No manifests yet — go to Data Sources and profile a source first.</div>
            )}
          </div>

          <div style={{ marginBottom: 20 }}>
            <label style={{ color: "#64748b", fontSize: 12, display: "block", marginBottom: 8 }}>NUMBER OF ROWS TO GENERATE</label>
            <input
              type="number" value={numRows}
              onChange={e => setNumRows(parseInt(e.target.value) || 100)}
              min={10} max={100000}
              style={{
                width: "100%", background: "#0f1929", border: "1px solid #1e3a5f",
                color: "#e2e8f0", borderRadius: 10, padding: "10px 14px", fontSize: 13,
                outline: "none", boxSizing: "border-box"
              }}
            />
            <div style={{ color: "#334155", fontSize: 11, marginTop: 4 }}>PoC: 10–100,000 rows. Enterprise: unlimited with distributed generation.</div>
          </div>

          {/* Row presets */}
          <div style={{ display: "flex", gap: 8, marginBottom: 24 }}>
            {[100, 1000, 5000, 10000].map(n => (
              <button key={n} onClick={() => setNumRows(n)} style={{
                background: numRows === n ? "#0d2b40" : "#0f1929",
                border: `1px solid ${numRows === n ? "#00d4aa" : "#1e3a5f"}`,
                color: numRows === n ? "#00d4aa" : "#475569",
                borderRadius: 8, padding: "6px 12px", fontSize: 11, cursor: "pointer"
              }}>
                {n.toLocaleString()}
              </button>
            ))}
          </div>

          <Btn
            icon="cpu"
            disabled={!selectedManifest}
            onClick={() => onGenerate(selectedManifest, numRows)}
          >
            Generate Synthetic Data
          </Btn>
        </div>

        {/* What Happens Panel */}
        <div style={{ background: "#0a1220", border: "1px solid #1e2a3a", borderRadius: 16, padding: 24 }}>
          <div style={{ color: "#94a3b8", fontSize: 13, fontWeight: 600, marginBottom: 20 }}>WHAT HAPPENS WHEN YOU CLICK GENERATE</div>
          {[
            { step: "1", title: "Model Selection", desc: "Platform picks CTGAN for tabular, TimeGAN for series, LLM for text fields", color: "#60a5fa" },
            { step: "2", title: "Statistical Sampling", desc: "AI reads manifest distributions and generates rows that match statistical properties", color: "#00d4aa" },
            { step: "3", title: "Correlation Preservation", desc: "Correlated columns (age↔income) maintain their relationships in synthetic output", color: "#c084fc" },
            { step: "4", title: "Privacy Audit", desc: "Membership inference attack simulation, k-anonymity check, l-diversity test", color: "#fbbf24" },
            { step: "5", title: "Quality Gate", desc: "KS test + TSTR score must exceed threshold before dataset is released", color: "#34d399" }
          ].map(item => (
            <div key={item.step} style={{ display: "flex", gap: 12, marginBottom: 16 }}>
              <div style={{ background: `${item.color}22`, color: item.color, width: 24, height: 24, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, flexShrink: 0 }}>{item.step}</div>
              <div>
                <div style={{ color: item.color, fontSize: 13, fontWeight: 600 }}>{item.title}</div>
                <div style={{ color: "#475569", fontSize: 12, marginTop: 2 }}>{item.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Job Progress */}
      {job && (
        <div style={{ marginTop: 24, background: "#0a1220", border: "1px solid #1e3a5f", borderRadius: 16, padding: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div style={{ color: "#60a5fa", fontWeight: 700, fontSize: 15 }}>Generation Pipeline</div>
            <Badge label={job.status} color={job.status === "completed" ? "green" : job.status === "failed" ? "red" : "blue"} />
          </div>
          <ProgressBar value={job.progress} color="#00d4aa" />
          <div style={{ color: "#64748b", fontSize: 12, marginTop: 10 }}>{job.message}</div>

          {job.status === "completed" && job.result && (
            <ValidationResult result={job.result} onViewData={() => setResultModal(job.result)} />
          )}
        </div>
      )}
    </div>
  );
}

// ─── Validation Result ─────────────────────────────────────────────────────────
function ValidationResult({ result, onViewData }) {
  const v = result.validation;
  return (
    <div style={{ marginTop: 20 }}>
      <div style={{ color: "#34d399", fontWeight: 700, marginBottom: 16, fontSize: 14 }}>
        ✓ Generation Complete — {result.total_rows?.toLocaleString()} rows generated and validated
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 16 }}>
        <ScoreBox label="Overall Quality" value={`${(v.overall_score * 100).toFixed(0)}%`} color="#34d399" status={v.overall_status} />
        <ScoreBox label="Statistical Fidelity" value={`${(v.fidelity_score * 100).toFixed(0)}%`} color="#60a5fa" status="PASS" />
        <ScoreBox label="Privacy Audit" value={`AUC ${v.privacy_audit.membership_inference_auc}`} color="#c084fc" status={v.privacy_audit.overall_privacy_status} />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 20 }}>
        <MiniStat label="k-Anonymity" value={v.privacy_audit.k_anonymity} ok={v.privacy_audit.k_anonymity_status === "PASS"} />
        <MiniStat label="l-Diversity" value={v.privacy_audit.l_diversity} ok={v.privacy_audit.l_diversity_status === "PASS"} />
        <MiniStat label="TSTR Score" value={`${(v.tstr_score * 100).toFixed(0)}%`} ok />
        <MiniStat label="Business Rules" value="All Pass" ok />
      </div>
      <Btn icon="eye" onClick={onViewData}>Preview Generated Data</Btn>
    </div>
  );
}

const ScoreBox = ({ label, value, color, status }) => (
  <div style={{ background: "#0f1929", border: `1px solid ${color}33`, borderRadius: 12, padding: "14px 16px" }}>
    <div style={{ color: "#475569", fontSize: 10, marginBottom: 4 }}>{label}</div>
    <div style={{ color, fontSize: 20, fontWeight: 700 }}>{value}</div>
    <div style={{ marginTop: 6 }}><Badge label={status} color={status === "PASS" ? "green" : "red"} /></div>
  </div>
);

const MiniStat = ({ label, value, ok }) => (
  <div style={{ background: "#0f1929", borderRadius: 10, padding: "10px 14px" }}>
    <div style={{ color: "#475569", fontSize: 10 }}>{label}</div>
    <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 4 }}>
      <span style={{ color: ok ? "#34d399" : "#f87171", fontSize: 11 }}>{ok ? "✓" : "✗"}</span>
      <span style={{ color: "#94a3b8", fontSize: 13, fontWeight: 600 }}>{value}</span>
    </div>
  </div>
);

// ─── Result Modal ──────────────────────────────────────────────────────────────
function ResultModal({ data, onClose }) {
  const [page, setPage] = useState(0);
  const pageSize = 10;
  const rows = data.data || [];
  const pageRows = rows.slice(page * pageSize, (page + 1) * pageSize);
  const cols = rows.length > 0 ? Object.keys(rows[0]) : [];
  const totalPages = Math.ceil(rows.length / pageSize);

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", zIndex: 9000, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ background: "#0a1220", border: "1px solid #1e3a5f", borderRadius: 20, width: "95%", maxWidth: 1100, maxHeight: "90vh", overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "20px 24px", borderBottom: "1px solid #1e2a3a", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 16 }}>Preview: Synthetic Data</div>
            <div style={{ color: "#475569", fontSize: 12, marginTop: 2 }}>Showing {rows.length} rows of {data.total_rows?.toLocaleString()} total generated rows</div>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <Badge label="SYNTHETIC — No real PII" color="green" />
            <button onClick={onClose} style={{ background: "#1e2a3a", border: "1px solid #334155", color: "#94a3b8", borderRadius: 8, padding: "6px 12px", cursor: "pointer", fontSize: 13 }}>Close ✕</button>
          </div>
        </div>
        <div style={{ overflow: "auto", flex: 1 }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <thead>
              <tr style={{ background: "#0f1929", position: "sticky", top: 0 }}>
                {cols.map(c => (
                  <th key={c} style={{ padding: "10px 14px", color: "#60a5fa", fontWeight: 600, textAlign: "left", borderBottom: "1px solid #1e2a3a", whiteSpace: "nowrap", letterSpacing: "0.04em", textTransform: "uppercase", fontSize: 10 }}>{c}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((row, i) => (
                <tr key={i} style={{ borderBottom: "1px solid #111b2b" }}>
                  {cols.map(c => (
                    <td key={c} style={{ padding: "9px 14px", color: "#94a3b8", whiteSpace: "nowrap", maxWidth: 180, overflow: "hidden", textOverflow: "ellipsis" }}>
                      {typeof row[c] === "boolean" ? (row[c] ? "true" : "false") : String(row[c] ?? "—")}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div style={{ padding: "14px 24px", borderTop: "1px solid #1e2a3a", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ color: "#475569", fontSize: 12 }}>Page {page + 1} of {totalPages}</div>
          <div style={{ display: "flex", gap: 8 }}>
            <Btn small variant="ghost" disabled={page === 0} onClick={() => setPage(p => p - 1)}>← Prev</Btn>
            <Btn small variant="ghost" disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)}>Next →</Btn>
          </div>
        </div>
      </div>
    </div>
  );
}
